const { chromium } = require('playwright');
const OUT = process.argv[2];
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.g|ERR_|Failed to load resource/.test(m.text())) errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('PAGEERROR ' + e.message));
  await page.goto('http://localhost:8765/preview.html');
  await page.waitForSelector('text=Seus campeonatos');
  await page.screenshot({ path: OUT + '/01-painel.png' });
  console.log('mode:', await page.locator('.sidebar .xs').first().textContent());

  // abrir Copa
  await page.click('text=Copa Bairro Esperança (Demonstração) >> xpath=ancestor::article >> text=Gerenciar');
  await page.waitForSelector('text=Links públicos');
  await page.screenshot({ path: OUT + '/02-overview.png', fullPage: true });
  // equipes
  await page.click('nav.tabs >> text=Equipes');
  await page.waitForSelector('text=Aprovar');
  await page.screenshot({ path: OUT + '/03-equipes.png' });
  while (await page.locator('button:has-text("Aprovar")').count()) { await page.locator('button:has-text("Aprovar")').first().click(); await page.waitForTimeout(150); }
  // partidas -> sorteio
  await page.click('nav.tabs >> text=Partidas');
  await page.waitForSelector('text=Sorteio e geração');
  await page.screenshot({ path: OUT + '/04-sorteio.png' });
  await page.click('button:has-text("Sortear e gerar partidas")');
  await page.click('.modal-foot >> text=Sortear e gerar partidas');
  await page.waitForSelector('text=Rodada 1');
  // registrar todos os jogos dos grupos
  let guard = 0;
  while (await page.locator('button:has-text("Registrar resultado")').count() && guard++ < 30) {
    await page.locator('button:has-text("Registrar resultado")').first().click();
    await page.fill('#m-hs', String(1 + (guard % 3)));
    await page.fill('#m-as', String(guard % 2));
    if (guard === 1) { await page.click('button:has-text("Gol")'); await page.screenshot({ path: OUT + '/05-modal.png' }); }
    await page.click('.modal-foot >> text=Salvar resultado');
    await page.waitForTimeout(250);
    if (await page.locator('.modal').count()) { console.log('modal ficou aberto:', await page.locator('.banner.bad').allTextContents()); await page.keyboard.press('Escape'); }
  }
  console.log('jogos registrados:', guard - 1);
  await page.click('button:has-text("Gerar eliminatórias")');
  await page.waitForSelector('text=Semifinal');
  await page.click('.seg >> text=Chaveamento');
  await page.screenshot({ path: OUT + '/06-chave.png' });
  await page.click('nav.tabs >> text=Classificação');
  await page.waitForSelector('text=Grupo A');
  await page.screenshot({ path: OUT + '/07-classificacao.png', fullPage: true });
  await page.click('nav.tabs >> text=Estatísticas');
  await page.waitForSelector('text=Melhor ataque');
  await page.screenshot({ path: OUT + '/08-stats.png', fullPage: true });

  // público
  await page.click('text=Ver página pública');
  await page.waitForSelector('text=Página pública simulada');
  await page.screenshot({ path: OUT + '/09-publica.png' });

  // inscrição pública do vôlei
  await page.click('text=Voltar ao painel');
  await page.click('.side-link >> text=Campeonatos');
  await page.click('text=Torneio Relâmpago de Futsal (Demonstração) >> xpath=ancestor::article >> text=Gerenciar');
  await page.waitForSelector('text=Links públicos');
  await page.click('button:has-text("Abrir formulário")');
  await page.waitForSelector('text=Inscrições indisponíveis');
  await page.screenshot({ path: OUT + '/10-inscricao-fechada.png' });
  await page.click('text=Voltar ao painel');
  await page.click('.side-link >> text=Novo campeonato');
  await page.waitForSelector('text=Informações gerais');
  await page.fill('#c-name', 'Liga Teste E2E');
  await page.screenshot({ path: OUT + '/11-wizard.png', fullPage: true });
  for (let i = 0; i < 4; i++) await page.click('button:has-text("Continuar")');
  await page.waitForSelector('text=Revisão');
  await page.click('button:has-text("Criar campeonato")');
  await page.waitForSelector('text=Links públicos');
  await page.click('button:has-text("Abrir formulário")');
  await page.waitForSelector('text=Dados da equipe');
  await page.fill('#tf-name', 'Equipe Teste'); await page.fill('#tf-manager', 'Fulano Silva'); await page.fill('#tf-email', 'a@b.co');
  for (let i = 0; i < 5; i++) await page.fill(`#pn-${i}`, `Jogador ${i}`).catch(() => {});
  await page.screenshot({ path: OUT + '/12-inscricao.png', fullPage: true });
  await page.click('button:has-text("Enviar inscrição")');
  await page.waitForSelector('text=Solicitação recebida');
  await page.click('button:has-text("Ver no painel")');
  await page.waitForSelector('text=Equipe Teste');
  console.log('errors:', JSON.stringify(errors));
  // mobile
  const m = await browser.newContext({ viewport: { width: 390, height: 800 } });
  const mp = await m.newPage();
  await mp.goto('http://localhost:8765/preview.html');
  await mp.waitForSelector('text=Seus campeonatos');
  await mp.screenshot({ path: OUT + '/13-mobile.png' });
  const w = await mp.evaluate(() => document.documentElement.scrollWidth);
  console.log('mobile scrollWidth', w);
  await browser.close();
})().catch((e) => { console.error('FAIL', e.message); process.exit(1); });
