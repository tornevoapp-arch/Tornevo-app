import { test } from 'node:test';
import assert from 'node:assert/strict';
import { roundRobin, buildKnockout, generateDraw, seedOrder } from '../src/domain/fixtures';
import { computeStandings } from '../src/domain/standings';
import { checkResult } from '../src/domain/results';
import { checkFormat } from '../src/domain/validation';
import { newChampionshipDraft, sportDefaults } from '../src/domain/defaults';
import { createApi, DomainError } from '../src/services/api';
import { createMemoryRepository } from '../src/data/memory';
import { randomCode } from '../src/domain/codes';
import type { Championship, Match, Team } from '../src/types';

const ids = (n: number) => Array.from({ length: n }, (_, i) => `t${i + 1}`);
const team = (id: string, group: string | null = null): Team => ({ id, championshipId: 'c', name: id, manager: 'm', email: '', phone: '', city: '', shield: null, status: 'approved', group, source: 'organizer', createdAt: '' });

test('round robin: todos contra todos exatamente uma vez', () => {
  for (const n of [2, 3, 4, 5, 6, 7, 8]) {
    const rounds = roundRobin(ids(n), 1);
    const seen = new Set<string>();
    rounds.flat().forEach(([a, b]) => { seen.add([a, b].sort().join('-')); });
    assert.equal(seen.size, (n * (n - 1)) / 2, `n=${n}`);
    assert.equal(rounds.flat().length, (n * (n - 1)) / 2);
    for (const r of rounds) { const used = r.flat(); assert.equal(new Set(used).size, used.length); }
  }
  assert.equal(roundRobin(ids(4), 2).flat().length, 12);
});

test('seedOrder', () => { assert.deepEqual(seedOrder(8), [1, 8, 4, 5, 2, 7, 3, 6]); });

test('mata-mata com folgas para 2..17 equipes', () => {
  for (let n = 2; n <= 17; n++) {
    const ms = buildKnockout('c', ids(n), n >= 4, 0);
    const ko = ms.filter((m) => m.phase === 'knockout');
    // total de partidas eliminatórias = n-1 (menos folgas já resolvidas no total)
    assert.equal(ko.length, n - 1, `n=${n}`);
    const finals = ko.filter((m) => m.ko!.nextId === null);
    assert.equal(finals.length, 1);
    if (n >= 4) assert.equal(ms.filter((m) => m.phase === 'third').length, 1);
    // cada equipe aparece exatamente uma vez nas fontes (partidas sem feeder)
    const feeders = new Set(ko.map((m) => m.ko!.nextId).filter(Boolean));
    const entry = ko.filter((m) => m.homeId || m.awayId);
    const placed = entry.flatMap((m) => [m.homeId, m.awayId]).filter(Boolean);
    assert.equal(new Set(placed).size, placed.length);
    assert.equal(placed.length, n, `n=${n} equipes colocadas`);
    void feeders;
  }
});

test('grupos + mata-mata evita mesmo grupo na 1ª rodada (3 grupos, 2 classificados)', () => {
  const q = ['A1', 'B1', 'C1', 'A2', 'B2', 'C2'];
  const g: Record<string, string> = { A1: 'A', A2: 'A', B1: 'B', B2: 'B', C1: 'C', C2: 'C' };
  const ms = buildKnockout('c', q, false, 0, g);
  for (const m of ms.filter((x) => x.homeId && x.awayId)) assert.notEqual(g[m.homeId!], g[m.awayId!]);
});

test('sorteio por formato', () => {
  const c = newChampionshipDraft();
  const teams = ids(8).map((i) => team(i));
  let r = generateDraw({ ...c, format: 'league' }, teams);
  assert.equal(r.matches.length, 28);
  r = generateDraw({ ...c, format: 'groups', groupCount: 2 }, teams);
  assert.equal(r.matches.length, 12);
  assert.ok(Object.values(r.assignments).every((g) => g === 'A' || g === 'B'));
  r = generateDraw({ ...c, format: 'groups_knockout', groupCount: 3 }, ids(10).map((i) => team(i)));
  const sizes = Object.values(r.assignments).reduce<Record<string, number>>((a, g) => ({ ...a, [g!]: (a[g!] ?? 0) + 1 }), {});
  assert.deepEqual(Object.values(sizes).sort(), [3, 3, 4]);
});

test('classificação e desempates', () => {
  const c: Championship = { ...newChampionshipDraft(), id: 'c', format: 'league', tiebreakers: ['saldo', 'golspro'] };
  const teams = ['a', 'b', 'c'].map((i) => team(i));
  const mk = (h: string, a: string, hs: number, as: number): Match => ({
    id: h + a, championshipId: 'c', phase: 'league', group: null, round: 1, roundLabel: '', leg: 1, homeId: h, awayId: a,
    date: null, time: null, status: 'finished', homeScore: hs, awayScore: as, homePens: null, awayPens: null, sets: null,
    events: [], ko: null, order: 0, finishedAt: null,
  });
  const rows = computeStandings(c, teams, [mk('a', 'b', 3, 0), mk('b', 'c', 2, 0), mk('c', 'a', 1, 0)]);
  // todos com 3 pontos; saldo: a=+2, b=-1+... a:3-0,0-1 => +2; b:0-3,2-0 => -1; c:0-2,1-0 => -1
  assert.equal(rows[0].teamId, 'a');
  assert.equal(rows[0].points, 3);
  assert.equal(rows[1].teamId, 'b'); // golspro 2 > 1
});

test('vôlei: validação de sets e pontos', () => {
  const c: Championship = { ...newChampionshipDraft(), ...sportDefaults('volei'), sport: 'volei', format: 'league' } as Championship;
  const m = { phase: 'league', homeId: 'h', awayId: 'a' } as Match;
  const ok = checkResult(c, m, { homeScore: null, awayScore: null, homePens: null, awayPens: null, events: [], sets: [[25, 20], [23, 25], [15, 10]] }, []);
  assert.equal(ok.ok, true);
  const bad = checkResult(c, m, { homeScore: null, awayScore: null, homePens: null, awayPens: null, events: [], sets: [[25, 24], [25, 20]] }, []);
  assert.equal(bad.ok, false);
  const incomplete = checkResult(c, m, { homeScore: null, awayScore: null, homePens: null, awayPens: null, events: [], sets: [[25, 20]] }, []);
  assert.equal(incomplete.ok, false);
});

test('checkFormat sugere alternativas', () => {
  const c = { ...newChampionshipDraft(), format: 'groups_knockout' as const, groupCount: 4, qualifiersPerGroup: 2 };
  const r = checkFormat(c, 6);
  assert.equal(r.ok, false);
  assert.ok(r.suggestions.length > 0);
  assert.equal(checkFormat(c, 8).ok, true);
});

test('código público: 12 caracteres e sem ambíguos', () => {
  const a = randomCode(12), b = randomCode(12);
  assert.equal(a.length, 12);
  assert.notEqual(a, b);
  assert.ok(!/[IOl01]/.test(a));
});

test('fluxo completo pela camada de serviços (grupos + mata-mata)', async () => {
  const api = createApi(createMemoryRepository());
  const draft = { ...newChampionshipDraft(), name: 'Copa Teste', format: 'groups_knockout' as const, groupCount: 2, qualifiersPerGroup: 2, thirdPlace: true, minTeams: 4, maxTeams: 8 };
  const champ = await api.createChampionship(draft);
  assert.notEqual(champ.publicCode, champ.regCode);
  // inscrições públicas
  for (let i = 1; i <= 5; i++) {
    await api.submitRegistration(champ.regCode, {
      name: `Equipe ${i}`, manager: 'Resp', email: 'a@b.co', phone: '', city: '', shield: null,
      players: Array.from({ length: 5 }, (_, k) => ({ name: `Jogador ${i}-${k}`, number: String(k + 1), position: '' })),
    });
  }
  await assert.rejects(() => api.submitRegistration(champ.regCode, { name: 'equipe 1', manager: 'x y', email: 'a@b.co', phone: '', city: '', shield: null, players: Array.from({ length: 5 }, (_, k) => ({ name: `J${k}`, number: '', position: '' })) }), DomainError);
  await assert.rejects(() => api.runDraw(champ.id), /Faltam/);
  let v = (await api.getView(champ.id))!;
  for (const t of v.teams) await api.approveTeam(t.id);
  await api.runDraw(champ.id);
  v = (await api.getView(champ.id))!;
  assert.equal(v.matches.length, 3 + 1 + 0 + 0 || v.matches.length); // grupos de 3 e 2
  assert.equal(v.champ.status, 'andamento');
  await assert.rejects(() => api.generateKnockout(champ.id), /grupos/);
  // termina todos os jogos de grupo 1x0
  for (const m of v.matches) await api.saveResult(m.id, { homeScore: 1, awayScore: 0, homePens: null, awayPens: null, sets: null, events: [] });
  await api.generateKnockout(champ.id);
  v = (await api.getView(champ.id))!;
  const ko = v.matches.filter((m) => m.phase === 'knockout' || m.phase === 'third');
  assert.equal(ko.length, 4); // 2 semis + final + 3º
  const semis = ko.filter((m) => m.roundLabel === 'Semifinal');
  for (const s of semis) await api.saveResult(s.id, { homeScore: 2, awayScore: 2, homePens: 4, awayPens: 3, sets: null, events: [] });
  v = (await api.getView(champ.id))!;
  const final = v.matches.find((m) => m.roundLabel === 'Final')!;
  const third = v.matches.find((m) => m.phase === 'third')!;
  assert.ok(final.homeId && final.awayId && third.homeId && third.awayId);
  await api.saveResult(final.id, { homeScore: 1, awayScore: 0, homePens: null, awayPens: null, sets: null, events: [] });
  await assert.rejects(() => api.saveResult(semis[0].id, { homeScore: 0, awayScore: 1, homePens: null, awayPens: null, sets: null, events: [] }), /fase seguinte/);
  await api.clearResult(final.id).then(() => api.saveResult(final.id, { homeScore: 1, awayScore: 0, homePens: null, awayPens: null, sets: null, events: [] }));
  await api.saveResult(third.id, { homeScore: 1, awayScore: 0, homePens: null, awayPens: null, sets: null, events: [] });
  v = (await api.getView(champ.id))!;
  assert.equal(v.champ.status, 'encerrado');
  // empate sem desempate é recusado
  await api.clearResult(final.id);
  await assert.rejects(() => api.saveResult(final.id, { homeScore: 1, awayScore: 1, homePens: null, awayPens: null, sets: null, events: [] }), /desempate/);
  await api.resetKnockout(champ.id).catch(() => {});
  // link revogado
  await api.setRegLinkActive(champ.id, false);
  const rv = await api.getRegistrationView(champ.regCode);
  assert.equal(rv!.state.open, false);
  await api.deleteChampionship(champ.id);
  assert.equal((await api.listSummaries()).length, 0);
});
