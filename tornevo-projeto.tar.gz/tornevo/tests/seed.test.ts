import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApi } from '../src/services/api';
import { createMemoryRepository } from '../src/data/memory';
import { ensureSeeded } from '../src/data/seed';
import { computeStandings } from '../src/domain/standings';

test('dados de demonstração são criados com as regras reais', async () => {
  const api = createApi(createMemoryRepository());
  await ensureSeeded(api);
  const s = await api.listSummaries();
  assert.equal(s.length, 3);
  const copa = s.find((x) => x.champ.name.startsWith('Copa'))!;
  assert.equal(copa.approved, 6);
  assert.equal(copa.pending, 2);
  assert.equal(copa.champ.drawDone, false);
  const vol = s.find((x) => x.champ.sport === 'volei')!;
  assert.equal(vol.matches, 15);
  assert.equal(vol.finished, 6);
  const v = (await api.getView(vol.champ.id))!;
  const rows = computeStandings(v.champ, v.teams, v.matches);
  assert.equal(rows.reduce((a, r) => a + r.played, 0), 12);
  const d = await api.getDashboard();
  assert.ok(d.upcoming.length > 0 && d.recent.length > 0);
  await ensureSeeded(api); // idempotente
  assert.equal((await api.listSummaries()).length, 3);
});
