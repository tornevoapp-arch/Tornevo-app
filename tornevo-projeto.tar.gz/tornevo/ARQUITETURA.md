# Tornevo: arquitetura para produção

Este documento descreve como trocar a camada local da demonstração por serviços reais (autenticação, banco, armazenamento de imagens e Vercel) sem reescrever a interface.

## 1. Como o protótipo está organizado

```
src/
  config.ts            URL pública (tornevo.app) e limites. Em produção vem de variável de ambiente.
  types.ts             Modelos: Championship, Team, Player, Match...
  domain/              Regras puras, sem acesso a armazenamento
    fixtures.ts        round-robin, grupos, chaveamento com folgas, calendário automático
    standings.ts       pontos, desempates (incl. confronto direto), vôlei por sets
    stats.ts           artilharia, assistências, cartões, suspensões
    results.ts         validação de placar, sets, desempate, eventos
    validation.ts      campeonato, formato x nº de equipes, inscrição
    registration.ts    inscrições abertas/fechadas e motivo
    codes.ts           códigos públicos e embaralhamento criptográfico
  data/
    repository.ts      INTERFACE de armazenamento (o contrato)
    indexeddb.ts       implementação local da demonstração
    memory.ts          fallback quando o navegador não permite IndexedDB
    seed.ts            dados de exemplo (usam as regras reais)
  services/api.ts      Casos de uso: createChampionship, submitRegistration, runDraw, saveResult...
  ui/                  React + TypeScript. Só chama services/api.ts
tests/                 Regras de negócio e fluxo completo
```

Regra de ouro: a interface nunca toca IndexedDB. Ela chama `api.*`. Para ir a produção, troque o que está atrás de `api`.

## 2. O que fica e o que muda

| Camada | Na demonstração | Em produção |
|---|---|---|
| Interface (`ui/`) | React, roteador em memória | React + React Router com os mesmos caminhos (`/painel`, `/torneio/:codigo`...) |
| Domínio (`domain/`) | Roda no navegador | Continua no navegador para exibir; **as regras que garantem consistência também rodam no servidor** (ver seção 5) |
| Serviços (`services/api.ts`) | Usa `Repository` local | Mesma assinatura, implementada com Supabase (ou HTTP) |
| Armazenamento | IndexedDB | Postgres (Supabase) |
| Escudos | data URL reduzida | Supabase Storage |
| Login | não existe | Supabase Auth |

## 3. Supabase: modelo de dados

Tabelas (todas com `id uuid primary key default gen_random_uuid()` e `created_at`):

- `profiles(id → auth.users, name)`
- `championships(owner_id → auth.users, name, description, sport, custom_sport, category, city, venue, start_date, end_date, reg_open_date, reg_close_date, reg_notes, max_teams, min_teams, min_players, max_players, contact_rule, require_city, format, group_count, qualifiers_per_group, third_place, legs, points_win, points_draw, points_loss, tiebreakers text[], periods, period_minutes, sets_to_win, set_points, tiebreak_set_points, stats jsonb, yellow_limit, status, draw_done, knockout_generated, public_code text unique, reg_code text unique, reg_link_active)`
- `championship_members(championship_id, user_id, role)`: já prepara colaboradores. No MVP só o dono.
- `teams(championship_id, name, manager, email, phone, city, shield_path, status, group_name, source)` com índice único parcial em `(championship_id, lower(name))` onde `status <> 'rejected'`.
- `players(team_id, championship_id, name, number, position)` com único `(team_id, number)`.
- `matches(championship_id, phase, group_name, round, round_label, leg, home_id, away_id, date, time, status, home_score, away_score, home_pens, away_pens, sets jsonb, ko jsonb, sort_order, finished_at)`.
- `match_events(match_id, type, team_id, player_id, assist_player_id, minute)`: na demonstração os eventos ficam dentro da partida; em produção vale normalizar para consultas de artilharia.

`public_code` e `reg_code` têm `unique` e `check (public_code <> reg_code)`. O servidor gera com `encode(gen_random_bytes(...))` ou função equivalente com alfabeto sem caracteres ambíguos e tenta de novo em caso de colisão.

## 4. Segurança (Row Level Security)

Ative RLS em todas as tabelas. Políticas:

- `championships`: dono (`owner_id = auth.uid()`) tem `select/insert/update/delete`.
- `teams`, `players`, `matches`, `match_events`: acesso se `exists (select 1 from championships c where c.id = championship_id and c.owner_id = auth.uid())`.
- **Visitantes não leem tabelas direto.** As páginas públicas usam funções `security definer`:
  - `get_public_tournament(code text)`: retorna campeonato, equipes **aprovadas** (sem e-mail, telefone ou responsável), jogadores, partidas.
  - `get_registration_info(code text)`: dados mostrados no formulário e vagas restantes.
  - `submit_registration(code text, payload jsonb)`: valida link ativo, status, datas, capacidade, elenco e nome duplicado; grava equipe `pending` e jogadores numa transação.
- Códigos inválidos ou revogados retornam `null`, e a interface mostra a página amigável que já existe (`InvalidLink`).
- Mudar o ID na URL não dá acesso: a política RLS nega.

Chaves: o navegador usa só `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`. A `service_role` nunca vai ao front nem ao repositório.

## 5. Regras que precisam rodar no servidor

A demonstração confia no navegador. Em produção, mova para Postgres (funções `plpgsql`) ou Edge Functions:

1. **Capacidade** na aprovação (`approved < max_teams`), com lock da linha do campeonato para evitar corrida.
2. **Sorteio** (`run_draw`): embaralhar com `random()` do servidor, gerar grupos e partidas na mesma transação e marcar `draw_done`.
3. **Resultado** (`save_result`): validar placar/sets, avançar vencedor no chaveamento e bloquear mudança que contradiga fase já jogada.
4. **Geração de eliminatórias** e **refazer sorteio**.
5. Unicidade de códigos e regeneração de links.

O código de `domain/` serve de especificação e de suíte de testes: porte as funções para SQL/TypeScript no servidor e rode os mesmos casos de `tests/`. Uma alternativa mais barata: Edge Functions em TypeScript que **importam `domain/` diretamente**, reaproveitando as regras sem reescrever.

## 6. Autenticação

- Supabase Auth com e-mail e senha: cadastro (`signUp`), login, logout, recuperação (`resetPasswordForEmail`) e sessão persistida pelo SDK.
- Rotas `/painel/*` ficam atrás de um guarda: sem sessão, redireciona para `/entrar`.
- Crie as telas `/entrar`, `/criar-conta`, `/recuperar-senha` (não existem na demonstração de propósito).
- Exclusão de conta: Edge Function com `service_role` que apaga os dados do usuário e depois o usuário.
- Ative confirmação de e-mail e configure a URL do site em Auth → URL Configuration.

## 7. Armazenamento de imagens

- Bucket público `shields` para escudos e `covers` para capas (leitura pública, escrita por RLS).
- Caminho: `{championship_id}/{team_id}.jpg`. Guarde só o caminho em `teams.shield_path`.
- Reaproveite `ui/image.ts` (reduz para 160×160 no navegador) e valide tipo e tamanho também na política do bucket (`allowed_mime_types`, `file_size_limit`).
- Inscrição pública sem login: envie a imagem por uma Edge Function que valida o `reg_code`, ou aceite o upload apenas via URL assinada gerada em `submit_registration`.

## 8. Proteção contra spam na inscrição pública

- CAPTCHA (Cloudflare Turnstile ou hCaptcha) verificado na Edge Function de envio.
- Limite por IP e por link (ex.: 5 envios por hora), usando uma tabela de contagem ou o rate limit da plataforma.
- Campo oculto (honeypot) e bloqueio de duplicidade (nome da equipe + contato) já têm lógica de nome duplicado em `api.ts`.
- Botão de envio desabilitado durante o envio (já existe).

## 9. Implantação na Vercel

1. Repositório no GitHub com este projeto migrado para Vite (`npm create vite`, mantendo `src/`). Instale `react-router-dom` e `@types/react`; apague `src/shims.d.ts`.
2. Variáveis de ambiente na Vercel: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_PUBLIC_BASE_URL` (ex.: `https://tornevo.app`; o domínio de preview da Vercel funciona antes da compra). Troque a constante de `src/config.ts` por `import.meta.env.VITE_PUBLIC_BASE_URL`.
3. `vercel.json` para as rotas do app não darem 404 ao atualizar a página:
   ```json
   { "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }] }
   ```
4. Domínio: adicione `tornevo.app` em Settings → Domains e aponte o DNS. Um único domínio serve todas as rotas, sem subdomínio por campeonato.
5. Copie `.env.example` (somente nomes de variáveis, valores fictícios) e nunca versione `.env`.

## 10. Passo a passo da migração

1. Criar projeto Supabase, aplicar o SQL das tabelas, RLS e funções.
2. Gerar tipos do banco (`supabase gen types typescript`).
3. Criar `services/api.supabase.ts` com **as mesmas funções de `createApi`** (mesmos nomes, parâmetros e retornos), chamando tabelas/RPCs. Manter `subscribe` usando Realtime ou refetch.
4. Em `ui/App.tsx`, trocar `createApi(await openRepository())` pela nova implementação. A interface não muda.
5. Adicionar telas e guarda de autenticação.
6. Mover as regras da seção 5 para o servidor e reaplicar os testes de `tests/`.
7. Configurar Storage, CAPTCHA e limites.
8. Remover o modo demonstração: `config.demoMode = false`, tirar `DemoPill`, a página `/sobre` e os dados de `seed.ts`.
9. Testar com dois usuários: um não pode ver, editar nem excluir campeonato do outro (inclusive alterando IDs na URL).

## 11. Pontos de atenção

- Os códigos e o sorteio da demonstração rodam no navegador e **não são seguros nem auditáveis**. Isso muda no servidor.
- O armazenamento local é por navegador: outro aparelho não vê os dados. Não há sincronização.
- Textos de `/privacidade` e `/termos` ainda precisam ser redigidos (idealmente com revisão jurídica e atenção à LGPD, já que há dados de pessoas e, possivelmente, menores).
- Funcionalidades do prompt original fora desta versão: capa e escudo do campeonato, foto individual de jogador, compartilhamento por WhatsApp, recuperação de senha, exclusão de conta.
