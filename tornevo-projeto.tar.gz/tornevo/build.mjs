// Gera dist/index.html (arquivo único: JS + CSS embutidos) para o preview.
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const result = await build({
  entryPoints: ['src/main.tsx'],
  bundle: true, minify: true, write: false, format: 'iife', target: 'es2020',
  jsx: 'automatic', loader: { '.css': 'css' }, outdir: 'dist/tmp',
  define: { 'process.env.NODE_ENV': '"production"' },
  legalComments: 'none',
});
const js = result.outputFiles.find((f) => f.path.endsWith('.js')).text.replace(/<\/script/gi, '<\\/script');
const css = result.outputFiles.find((f) => f.path.endsWith('.css')).text;

const head = `<title>Tornevo</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700&family=Hanken+Grotesk:wght@400;500;600;700;800&display=swap">
<style>${css}</style>`;
const body = `<div id="root"></div>\n<script>${js}</script>`;

mkdirSync('dist', { recursive: true });
writeFileSync('dist/index.html', `${head}\n${body}\n`);
writeFileSync('dist/preview.html', `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">${head}</head><body>${body}</body></html>`);
console.log('ok', (js.length / 1024).toFixed(0) + 'KB js', (css.length / 1024).toFixed(0) + 'KB css');
