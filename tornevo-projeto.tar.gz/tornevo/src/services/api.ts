import type { Championship, Match, Player, Team, ChampStatus } from '../types';
import type { Repository } from '../data/repository';
import { randomCode, randomId } from '../domain/codes';
import { config } from '../config';
import { checkFormat, validateChampionship, validateRegistration, type Errors, type RegistrationInput } from '../domain/validation';
import { generateDraw, autoSchedule, type ScheduleOptions } from '../domain/fixtures';
import { checkResult, isKnockout, winnerOf, type ResultInput } from '../domain/results';
import { generateKnockoutFromGroups, groupStageComplete, isFinished } from '../domain/tournament';
import { registrationState, type RegState } from '../domain/registration';
import { todayISO } from '../domain/format';

export class DomainError extends Error {
  fields?: Errors;
  constructor(message: string, fields?: Errors) {
    super(message);
    this.fields = fields;
  }
}

export interface ChampionshipView {
  champ: Championship;
  teams: Team[];
  players: Player[];
  matches: Match[];
}

export interface Summary {
  champ: Championship;
  approved: number;
  pending: number;
  matches: number;
  finished: number;
}

export interface PublicTeam { id: string; name: string; shield: string | null; city: string; group: string | null }
export interface PublicView {
  champ: Championship;
  teams: Team[]; // só equipes aprovadas; contatos removidos
  players: Player[];
  matches: Match[];
}
export interface RegistrationView { champ: Championship; approved: number; state: RegState }

export interface TeamInput extends RegistrationInput { shield: string | null }

const LOCKED_AFTER_DRAW: Array<keyof Championship> = ['sport', 'format', 'groupCount', 'qualifiersPerGroup', 'thirdPlace', 'legs'];

export function createApi(repo: Repository) {
  const listeners = new Set<() => void>();
  const emit = () => listeners.forEach((l) => l());
  const now = () => new Date().toISOString();

  async function uniqueCode(field: 'publicCode' | 'regCode'): Promise<string> {
    const all = await repo.list<Championship>('championships');
    const used = new Set(all.flatMap((c) => [c.publicCode, c.regCode]));
    for (let i = 0; i < 20; i++) {
      const code = randomCode(config.publicCodeLength);
      if (!used.has(code)) return code;
    }
    throw new DomainError(`Não foi possível gerar um código único para ${field}. Tente de novo.`);
  }

  async function mustChamp(id: string): Promise<Championship> {
    const c = await repo.get<Championship>('championships', id);
    if (!c) throw new DomainError('Campeonato não encontrado.');
    return c;
  }

  async function view(id: string): Promise<ChampionshipView | undefined> {
    const champ = await repo.get<Championship>('championships', id);
    if (!champ) return undefined;
    const [teams, players, matches] = await Promise.all([
      repo.listByChampionship<Team>('teams', id),
      repo.listByChampionship<Player>('players', id),
      repo.listByChampionship<Match>('matches', id),
    ]);
    teams.sort((a, b) => a.createdAt.localeCompare(b.createdAt) || a.name.localeCompare(b.name, 'pt-BR'));
    matches.sort((a, b) => a.order - b.order);
    return { champ, teams, players, matches };
  }

  async function syncStatus(champId: string) {
    const v = await view(champId);
    if (!v) return;
    const finished = isFinished(v.champ, v.matches);
    let status: ChampStatus = v.champ.status;
    if (finished && status === 'andamento') status = 'encerrado';
    if (!finished && status === 'encerrado') status = 'andamento';
    if (status !== v.champ.status) await repo.put('championships', { ...v.champ, status, updatedAt: now() });
  }

  const approvedCount = (teams: Team[]) => teams.filter((t) => t.status === 'approved').length;

  async function createTeamWithPlayers(c: Championship, input: TeamInput, status: Team['status'], source: Team['source']): Promise<Team> {
    const errors = validateRegistration(c, input);
    if (Object.keys(errors).length) throw new DomainError('Revise os campos destacados.', errors);
    if (input.shield && input.shield.length > config.maxShieldBytes * 1.4) throw new DomainError('O escudo é grande demais.', { shield: 'Use uma imagem menor.' });
    const existing = await repo.listByChampionship<Team>('teams', c.id);
    const dup = existing.find((t) => t.status !== 'rejected' && t.name.trim().toLowerCase() === input.name.trim().toLowerCase());
    if (dup) throw new DomainError('Já existe uma equipe com esse nome neste campeonato.', { name: 'Já existe uma equipe com esse nome.' });
    const team: Team = {
      id: randomId(), championshipId: c.id, name: input.name.trim(), manager: input.manager.trim(),
      email: input.email.trim(), phone: input.phone.trim(), city: input.city.trim(), shield: input.shield,
      status, group: null, source, createdAt: now(),
    };
    const players: Player[] = input.players
      .filter((p) => p.name.trim())
      .map((p) => ({
        id: randomId(), teamId: team.id, championshipId: c.id, name: p.name.trim(),
        number: p.number.trim() ? Number(p.number) : null, position: p.position.trim(),
      }));
    await repo.put('teams', team);
    await repo.putMany('players', players);
    return team;
  }

  const api = {
    storageMode: repo.mode,
    subscribe(fn: () => void) { listeners.add(fn); return () => { listeners.delete(fn); }; },

    // ---------- campeonatos ----------
    async listSummaries(): Promise<Summary[]> {
      const [champs, teams, matches] = await Promise.all([
        repo.list<Championship>('championships'), repo.list<Team>('teams'), repo.list<Match>('matches'),
      ]);
      return champs
        .map((champ) => {
          const t = teams.filter((x) => x.championshipId === champ.id);
          const m = matches.filter((x) => x.championshipId === champ.id);
          return {
            champ, approved: t.filter((x) => x.status === 'approved').length, pending: t.filter((x) => x.status === 'pending').length,
            matches: m.length, finished: m.filter((x) => x.status === 'finished').length,
          };
        })
        .sort((a, b) => b.champ.createdAt.localeCompare(a.champ.createdAt));
    },

    async getView(id: string) { return view(id); },

    async createChampionship(input: Championship): Promise<Championship> {
      const errors = validateChampionship(input);
      const fc = checkFormat(input, input.minTeams);
      if (!fc.ok) errors.teams = fc.problems.join(' ');
      if (Object.keys(errors).length) throw new DomainError('Revise os campos destacados.', errors);
      const champ: Championship = {
        ...input,
        id: randomId(), name: input.name.trim(), description: input.description.trim(),
        publicCode: await uniqueCode('publicCode'), regCode: '', regLinkActive: true,
        drawDone: false, knockoutGenerated: false, createdAt: now(), updatedAt: now(),
      };
      champ.regCode = await uniqueCode('regCode');
      while (champ.regCode === champ.publicCode) champ.regCode = await uniqueCode('regCode');
      await repo.put('championships', champ);
      emit();
      return champ;
    },

    async updateChampionship(id: string, patch: Partial<Championship>): Promise<Championship> {
      const cur = await mustChamp(id);
      const next: Championship = { ...cur, ...patch, id: cur.id, publicCode: cur.publicCode, regCode: cur.regCode, drawDone: cur.drawDone, knockoutGenerated: cur.knockoutGenerated };
      if (cur.drawDone) {
        for (const k of LOCKED_AFTER_DRAW) {
          if (next[k] !== cur[k]) throw new DomainError('Depois do sorteio não dá para mudar modalidade e formato. Refaça o sorteio antes.', { [k as string]: 'Bloqueado após o sorteio.' });
        }
      }
      const errors = validateChampionship(next);
      const teams = await repo.listByChampionship<Team>('teams', id);
      if (!cur.drawDone) {
        const fc = checkFormat(next, next.minTeams);
        if (!fc.ok) errors.teams = fc.problems.join(' ');
      }
      if (next.maxTeams < approvedCount(teams)) errors.maxTeams = `Já há ${approvedCount(teams)} equipes aprovadas.`;
      if (Object.keys(errors).length) throw new DomainError('Revise os campos destacados.', errors);
      next.updatedAt = now();
      await repo.put('championships', next);
      emit();
      return next;
    },

    async setStatus(id: string, status: 'preparacao' | 'inscricoes') {
      const c = await mustChamp(id);
      if (c.drawDone) throw new DomainError('O campeonato já começou.');
      await repo.put('championships', { ...c, status, updatedAt: now() });
      emit();
    },

    async deleteChampionship(id: string) {
      const [teams, players, matches] = await Promise.all([
        repo.listByChampionship<Team>('teams', id), repo.listByChampionship<Player>('players', id), repo.listByChampionship<Match>('matches', id),
      ]);
      await repo.removeMany('matches', matches.map((m) => m.id));
      await repo.removeMany('players', players.map((p) => p.id));
      await repo.removeMany('teams', teams.map((t) => t.id));
      await repo.remove('championships', id);
      emit();
    },

    async regenerateCode(id: string, which: 'publicCode' | 'regCode') {
      const c = await mustChamp(id);
      const code = await uniqueCode(which);
      await repo.put('championships', { ...c, [which]: code, ...(which === 'regCode' ? { regLinkActive: true } : {}), updatedAt: now() });
      emit();
      return code;
    },

    async setRegLinkActive(id: string, active: boolean) {
      const c = await mustChamp(id);
      await repo.put('championships', { ...c, regLinkActive: active, updatedAt: now() });
      emit();
    },

    // ---------- equipes e jogadores ----------
    async submitRegistration(regCode: string, input: TeamInput): Promise<Team> {
      const champs = await repo.list<Championship>('championships');
      const c = champs.find((x) => x.regCode === regCode);
      if (!c) throw new DomainError('Este link de inscrição não é válido.');
      const teams = await repo.listByChampionship<Team>('teams', c.id);
      const st = registrationState(c, approvedCount(teams), todayISO());
      if (!st.open) throw new DomainError(st.reason ?? 'Inscrições fechadas.');
      const team = await createTeamWithPlayers(c, input, 'pending', 'public');
      emit();
      return team;
    },

    async addTeam(champId: string, input: TeamInput): Promise<Team> {
      const c = await mustChamp(champId);
      if (c.drawDone) throw new DomainError('O sorteio já foi feito. Refaça o sorteio para incluir novas equipes.');
      const teams = await repo.listByChampionship<Team>('teams', champId);
      if (approvedCount(teams) >= c.maxTeams) throw new DomainError(`O limite de ${c.maxTeams} equipes já foi atingido.`);
      const team = await createTeamWithPlayers(c, input, 'approved', 'organizer');
      emit();
      return team;
    },

    async updateTeam(teamId: string, patch: { name: string; manager: string; email: string; phone: string; city: string; shield: string | null }) {
      const t = await repo.get<Team>('teams', teamId);
      if (!t) throw new DomainError('Equipe não encontrada.');
      const errors: Errors = {};
      if (patch.name.trim().length < 2) errors.name = 'Informe o nome da equipe.';
      if (patch.manager.trim().length < 2) errors.manager = 'Informe o responsável.';
      const others = await repo.listByChampionship<Team>('teams', t.championshipId);
      if (others.some((o) => o.id !== t.id && o.status !== 'rejected' && o.name.trim().toLowerCase() === patch.name.trim().toLowerCase())) errors.name = 'Já existe uma equipe com esse nome.';
      if (Object.keys(errors).length) throw new DomainError('Revise os campos destacados.', errors);
      await repo.put('teams', { ...t, ...patch, name: patch.name.trim(), manager: patch.manager.trim() });
      emit();
    },

    async approveTeam(teamId: string) {
      const t = await repo.get<Team>('teams', teamId);
      if (!t) throw new DomainError('Equipe não encontrada.');
      const c = await mustChamp(t.championshipId);
      if (c.drawDone) throw new DomainError('O sorteio já foi feito. Refaça o sorteio para aprovar novas equipes.');
      const teams = await repo.listByChampionship<Team>('teams', c.id);
      if (approvedCount(teams) >= c.maxTeams) throw new DomainError(`O limite de ${c.maxTeams} equipes já foi atingido.`);
      await repo.put('teams', { ...t, status: 'approved' });
      emit();
    },

    async rejectTeam(teamId: string) {
      const t = await repo.get<Team>('teams', teamId);
      if (!t) throw new DomainError('Equipe não encontrada.');
      const c = await mustChamp(t.championshipId);
      if (c.drawDone && t.status === 'approved') throw new DomainError('A equipe já está no sorteio. Refaça o sorteio antes de recusá-la.');
      await repo.put('teams', { ...t, status: 'rejected' });
      emit();
    },

    async restoreTeam(teamId: string) {
      const t = await repo.get<Team>('teams', teamId);
      if (!t) throw new DomainError('Equipe não encontrada.');
      await repo.put('teams', { ...t, status: 'pending' });
      emit();
    },

    async deleteTeam(teamId: string) {
      const t = await repo.get<Team>('teams', teamId);
      if (!t) return;
      const c = await mustChamp(t.championshipId);
      if (c.drawDone && t.status === 'approved') throw new DomainError('A equipe já está no sorteio. Refaça o sorteio antes de excluí-la.');
      const players = await repo.listByChampionship<Player>('players', c.id);
      await repo.removeMany('players', players.filter((p) => p.teamId === teamId).map((p) => p.id));
      await repo.remove('teams', teamId);
      emit();
    },

    async savePlayer(teamId: string, input: { id?: string; name: string; number: string; position: string }) {
      const t = await repo.get<Team>('teams', teamId);
      if (!t) throw new DomainError('Equipe não encontrada.');
      const c = await mustChamp(t.championshipId);
      const all = (await repo.listByChampionship<Player>('players', c.id)).filter((p) => p.teamId === teamId);
      const errors: Errors = {};
      if (input.name.trim().length < 2) errors.name = 'Informe o nome.';
      let number: number | null = null;
      if (input.number.trim()) {
        number = Number(input.number);
        if (!Number.isInteger(number) || number < 0 || number > 999) errors.number = 'Número de 0 a 999.';
        else if (all.some((p) => p.id !== input.id && p.number === number)) errors.number = 'Número já usado na equipe.';
      }
      if (!input.id && c.maxPlayers != null && all.length >= c.maxPlayers) errors.name = `O limite é de ${c.maxPlayers} jogadores.`;
      if (Object.keys(errors).length) throw new DomainError('Revise os campos destacados.', errors);
      const player: Player = { id: input.id ?? randomId(), teamId, championshipId: c.id, name: input.name.trim(), number, position: input.position.trim() };
      await repo.put('players', player);
      emit();
    },

    async deletePlayer(playerId: string) {
      const p = await repo.get<Player>('players', playerId);
      if (!p) return;
      const matches = await repo.listByChampionship<Match>('matches', p.championshipId);
      if (matches.some((m) => m.events.some((e) => e.playerId === playerId || e.assistPlayerId === playerId))) {
        throw new DomainError('Este jogador tem gols ou cartões registrados e não pode ser removido.');
      }
      await repo.remove('players', playerId);
      emit();
    },

    // ---------- sorteio e partidas ----------
    async runDraw(champId: string) {
      const v = await view(champId);
      if (!v) throw new DomainError('Campeonato não encontrado.');
      const { champ } = v;
      if (champ.drawDone) throw new DomainError('O sorteio já foi feito.');
      const approved = v.teams.filter((t) => t.status === 'approved');
      if (approved.length < Math.max(2, champ.minTeams)) {
        throw new DomainError(`Faltam equipes aprovadas: há ${approved.length} e o mínimo é ${Math.max(2, champ.minTeams)}.`);
      }
      const fc = checkFormat(champ, approved.length);
      if (!fc.ok) throw new DomainError(fc.problems.join(' '));
      const { assignments, matches } = generateDraw(champ, approved);
      await repo.putMany('teams', approved.map((t) => ({ ...t, group: assignments[t.id] ?? null })));
      await repo.putMany('matches', matches);
      await repo.put('championships', {
        ...champ, drawDone: true, status: 'andamento', knockoutGenerated: champ.format === 'knockout', updatedAt: now(),
      });
      emit();
    },

    async resetDraw(champId: string) {
      const v = await view(champId);
      if (!v) return;
      await repo.removeMany('matches', v.matches.map((m) => m.id));
      await repo.putMany('teams', v.teams.map((t) => ({ ...t, group: null })));
      await repo.put('championships', { ...v.champ, drawDone: false, knockoutGenerated: false, status: 'inscricoes', updatedAt: now() });
      emit();
    },

    async generateKnockout(champId: string) {
      const v = await view(champId);
      if (!v) return;
      if (v.champ.format !== 'groups_knockout') throw new DomainError('Este formato não tem eliminatórias depois dos grupos.');
      if (v.champ.knockoutGenerated) throw new DomainError('As eliminatórias já foram geradas.');
      if (!groupStageComplete(v.matches)) throw new DomainError('Termine todas as partidas dos grupos antes de gerar as eliminatórias.');
      const approved = v.teams.filter((t) => t.status === 'approved');
      const ko = generateKnockoutFromGroups(v.champ, approved, v.matches);
      if (ko.length === 0) throw new DomainError('Não há equipes suficientes classificadas.');
      await repo.putMany('matches', ko);
      await repo.put('championships', { ...v.champ, knockoutGenerated: true, updatedAt: now() });
      emit();
    },

    async resetKnockout(champId: string) {
      const v = await view(champId);
      if (!v) return;
      const ko = v.matches.filter((m) => isKnockout(m));
      if (ko.some((m) => m.status === 'finished')) throw new DomainError('Já há resultados nas eliminatórias. Limpe-os antes.');
      await repo.removeMany('matches', ko.map((m) => m.id));
      await repo.put('championships', { ...v.champ, knockoutGenerated: false, updatedAt: now() });
      emit();
    },

    async autoSchedule(champId: string, o: ScheduleOptions) {
      const v = await view(champId);
      if (!v) return 0;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(o.startDate)) throw new DomainError('Informe a data inicial.');
      if (!/^\d{2}:\d{2}$/.test(o.startTime)) throw new DomainError('Informe o horário inicial.');
      if (!(o.intervalMinutes >= 5 && o.intervalMinutes <= 600)) throw new DomainError('O intervalo deve ficar entre 5 e 600 minutos.');
      if (!(o.perDay >= 1 && o.perDay <= 30)) throw new DomainError('Use de 1 a 30 jogos por dia.');
      const plan = autoSchedule(v.matches, o);
      const changed = v.matches.filter((m) => plan.has(m.id)).map((m) => ({ ...m, ...plan.get(m.id)! }));
      await repo.putMany('matches', changed);
      emit();
      return changed.length;
    },

    async updateSchedule(matchId: string, date: string | null, time: string | null) {
      const m = await repo.get<Match>('matches', matchId);
      if (!m) throw new DomainError('Partida não encontrada.');
      if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new DomainError('Data inválida.');
      if (time && !/^\d{2}:\d{2}$/.test(time)) throw new DomainError('Horário inválido.');
      await repo.put('matches', { ...m, date: date || null, time: time || null });
      emit();
    },

    async saveResult(matchId: string, input: ResultInput) {
      const m = await repo.get<Match>('matches', matchId);
      if (!m) throw new DomainError('Partida não encontrada.');
      const v = await view(m.championshipId);
      if (!v) throw new DomainError('Campeonato não encontrado.');
      if (!m.homeId || !m.awayId) throw new DomainError('As duas equipes ainda não foram definidas.');
      if (v.champ.knockoutGenerated && m.phase === 'group') throw new DomainError('As eliminatórias já foram geradas. Apague-as antes de mudar resultados dos grupos.');
      const check = checkResult(v.champ, m, input, v.players);
      if (check.ok === false) throw new DomainError(check.errors.join(' '));
      const next: Match = { ...m, ...check.value, status: 'finished', finishedAt: now() };
      const w = winnerOf(next);

      if (m.ko) {
        const downstream = await Promise.all([m.ko.nextId, m.ko.loserNextId].filter(Boolean).map((id) => repo.get<Match>('matches', id as string)));
        const blocked = downstream.find((d) => d && d.status === 'finished');
        const prevWinner = winnerOf(m);
        if (blocked && prevWinner && prevWinner !== w) {
          throw new DomainError('Mudar o vencedor exige limpar antes o resultado da fase seguinte.');
        }
        const winnerId = w === 'home' ? m.homeId : m.awayId;
        const loserId = w === 'home' ? m.awayId : m.homeId;
        const setSlot = async (id: string | null, slot: 'home' | 'away' | null, team: string | null) => {
          if (!id || !slot) return;
          const d = await repo.get<Match>('matches', id);
          if (d) await repo.put('matches', { ...d, [slot === 'home' ? 'homeId' : 'awayId']: team });
        };
        await setSlot(m.ko.nextId, m.ko.nextSlot, winnerId);
        await setSlot(m.ko.loserNextId, m.ko.loserNextSlot, loserId);
      }
      await repo.put('matches', next);
      await syncStatus(m.championshipId);
      emit();
    },

    async clearResult(matchId: string) {
      const m = await repo.get<Match>('matches', matchId);
      if (!m) return;
      if (m.ko) {
        const targets = [[m.ko.nextId, m.ko.nextSlot], [m.ko.loserNextId, m.ko.loserNextSlot]] as const;
        for (const [id] of targets) {
          if (!id) continue;
          const d = await repo.get<Match>('matches', id);
          if (d && d.status === 'finished') throw new DomainError('Limpe antes o resultado da fase seguinte.');
        }
        for (const [id, slot] of targets) {
          if (!id || !slot) continue;
          const d = await repo.get<Match>('matches', id);
          if (d) await repo.put('matches', { ...d, [slot === 'home' ? 'homeId' : 'awayId']: null });
        }
      }
      const c = await repo.get<Championship>('championships', m.championshipId);
      if (c?.knockoutGenerated && m.phase === 'group' && c.format === 'groups_knockout') throw new DomainError('As eliminatórias já foram geradas. Apague-as antes de mudar resultados dos grupos.');
      await repo.put('matches', { ...m, status: 'scheduled', homeScore: null, awayScore: null, homePens: null, awayPens: null, sets: null, events: [], finishedAt: null });
      await syncStatus(m.championshipId);
      emit();
    },

    // ---------- painel e páginas públicas ----------
    async getDashboard() {
      const [champs, teams, matches] = await Promise.all([
        repo.list<Championship>('championships'), repo.list<Team>('teams'), repo.list<Match>('matches'),
      ]);
      const champById = new Map(champs.map((c) => [c.id, c]));
      const teamById = new Map(teams.map((t) => [t.id, t]));
      const decorate = (m: Match) => ({ match: m, champ: champById.get(m.championshipId)!, home: m.homeId ? teamById.get(m.homeId) ?? null : null, away: m.awayId ? teamById.get(m.awayId) ?? null : null });
      const upcoming = matches
        .filter((m) => m.status === 'scheduled' && m.homeId && m.awayId && champById.has(m.championshipId))
        .sort((a, b) => (a.date ?? '9999').localeCompare(b.date ?? '9999') || (a.time ?? '').localeCompare(b.time ?? '') || a.order - b.order)
        .slice(0, 5).map(decorate);
      const recent = matches
        .filter((m) => m.status === 'finished' && champById.has(m.championshipId))
        .sort((a, b) => (b.finishedAt ?? '').localeCompare(a.finishedAt ?? ''))
        .slice(0, 5).map(decorate);
      const summaries = await api.listSummaries();
      return { summaries, upcoming, recent };
    },

    async getPublicView(publicCode: string): Promise<PublicView | null> {
      const champs = await repo.list<Championship>('championships');
      const c = champs.find((x) => x.publicCode === publicCode);
      if (!c) return null;
      const v = await view(c.id);
      if (!v) return null;
      const teams = v.teams.filter((t) => t.status === 'approved').map((t) => ({ ...t, email: '', phone: '', manager: '' }));
      return { champ: v.champ, teams, players: v.players.filter((p) => teams.some((t) => t.id === p.teamId)), matches: v.matches };
    },

    async getRegistrationView(regCode: string): Promise<RegistrationView | null> {
      const champs = await repo.list<Championship>('championships');
      const c = champs.find((x) => x.regCode === regCode);
      if (!c) return null;
      const teams = await repo.listByChampionship<Team>('teams', c.id);
      const approved = approvedCount(teams);
      return { champ: c, approved, state: registrationState(c, approved, todayISO()) };
    },

    // ---------- demonstração ----------
    repo,
    async wipe() { await repo.clear(); emit(); },
    notify: emit,
  };
  return api;
}

export type Api = ReturnType<typeof createApi>;
