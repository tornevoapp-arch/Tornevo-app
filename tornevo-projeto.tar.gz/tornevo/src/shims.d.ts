// Sem @types/react neste ambiente de build offline. Em um projeto real, instale @types/react e apague este arquivo.
declare module 'react' {
  export type ReactNode = any;
  export type MouseEvent = any;
  export type Dispatch<T> = (v: T | ((p: T) => T)) => void;
  export function useState<T>(init: T | (() => T)): [T, Dispatch<T>];
  export function useEffect(fn: () => void | (() => void), deps?: unknown[]): void;
  export function useMemo<T>(fn: () => T, deps: unknown[]): T;
  export function useCallback<T>(fn: T, deps: unknown[]): T;
  export function useRef<T = any>(init?: T): { current: T };
  export function createContext<T>(v: T): any;
  export function useContext<T = any>(c: any): T;
  export function useReducer(...a: any[]): any;
  export function StrictMode(p: any): any;
}
declare module 'react-dom/client' {
  export function createRoot(el: any): { render(n: any): void };
}
declare module 'react/jsx-runtime';
declare namespace React {
  type ButtonHTMLAttributes<T> = any;
  type FormEvent = any;
}
declare namespace JSX {
  interface IntrinsicAttributes { key?: any }
  interface IntrinsicElements { [k: string]: any }
}
declare module '*.css';
