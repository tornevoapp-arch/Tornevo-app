export type SportId = 'futebol' | 'futsal' | 'volei' | 'basquete' | 'esports' | 'outra';
export type FormatId = 'knockout' | 'groups' | 'groups_knockout' | 'league';
export type ChampStatus = 'preparacao' | 'inscricoes' | 'andamento' | 'encerrado';
export type TiebreakId = 'vitorias' | 'saldo' | 'golspro' | 'confronto' | 'fairplay' | 'saldoPontos';
export type ContactRule = 'email' | 'phone' | 'either';
export type TeamStatus = 'pending' | 'approved' | 'rejected';
export type Phase = 'league' | 'group' | 'knockout' | 'third';

export interface StatsConfig {
  yellow: boolean;
  red: boolean;
  scorers: boolean;
  assists: boolean;
  suspensions: boolean;
}

export interface Championship {
  id: string;
  isDemo: boolean;
  name: string;
  description: string;
  sport: SportId;
  customSport: string;
  category: string;
  city: string;
  venue: string;
  startDate: string; // YYYY-MM-DD
  endDate: string;
  // inscrições
  regOpenDate: string;
  regCloseDate: string;
  regNotes: string;
  maxTeams: number;
  minTeams: number;
  minPlayers: number | null;
  maxPlayers: number | null;
  contactRule: ContactRule;
  requireCity: boolean;
  // formato
  format: FormatId;
  groupCount: number;
  qualifiersPerGroup: number;
  thirdPlace: boolean;
  legs: 1 | 2;
  pointsWin: number;
  pointsDraw: number;
  pointsLoss: number;
  tiebreakers: TiebreakId[];
  // partida
  periods: number;
  periodMinutes: number;
  setsToWin: number;
  setPoints: number;
  tiebreakSetPoints: number;
  stats: StatsConfig;
  yellowLimit: number;
  // estado
  status: ChampStatus;
  drawDone: boolean;
  knockoutGenerated: boolean;
  publicCode: string;
  regCode: string;
  regLinkActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Team {
  id: string;
  championshipId: string;
  name: string;
  manager: string;
  email: string;
  phone: string;
  city: string;
  shield: string | null; // data URL (demo). Em produção: URL do Storage.
  status: TeamStatus;
  group: string | null;
  source: 'public' | 'organizer';
  createdAt: string;
}

export interface Player {
  id: string;
  teamId: string;
  championshipId: string;
  name: string;
  number: number | null;
  position: string;
}

export type EventType = 'goal' | 'yellow' | 'red';

export interface MatchEvent {
  id: string;
  type: EventType;
  teamId: string;
  playerId: string | null;
  assistPlayerId: string | null;
  minute: number | null;
}

export interface KoLink {
  round: number; // 1 = primeira rodada eliminatória
  index: number;
  nextId: string | null;
  nextSlot: 'home' | 'away' | null;
  loserNextId: string | null;
  loserNextSlot: 'home' | 'away' | null;
}

export interface Match {
  id: string;
  championshipId: string;
  phase: Phase;
  group: string | null;
  round: number;
  roundLabel: string;
  leg: 1 | 2;
  homeId: string | null;
  awayId: string | null;
  date: string | null;
  time: string | null;
  status: 'scheduled' | 'finished';
  homeScore: number | null;
  awayScore: number | null;
  homePens: number | null;
  awayPens: number | null;
  sets: Array<[number, number]> | null;
  events: MatchEvent[];
  ko: KoLink | null;
  order: number;
  finishedAt: string | null;
}

export type StoreName = 'championships' | 'teams' | 'players' | 'matches';
