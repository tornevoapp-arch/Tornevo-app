import { useState } from 'react';
import type { Championship, FormatId, SportId, TiebreakId } from '../types';
import { Badge, Banner, Button, Field, Toggle, useUi } from './kit';
import { Icon } from './icons';
import { SPORT_LIST, SPORTS, sportName, tiebreakOptions } from '../domain/sports';
import { sportDefaults } from '../domain/defaults';
import { FORMAT_HINT, FORMAT_LABEL, STEP_FIELDS, checkFormat, groupSizes, validateChampionship, type Errors } from '../domain/validation';
import { fmtDate } from '../domain/format';
import { DomainError } from '../services/api';

const STEPS = [
  { n: 1, t: 'Geral' }, { n: 2, t: 'Equipes' }, { n: 3, t: 'Formato' }, { n: 4, t: 'Regras' }, { n: 5, t: 'Revisão' },
];

function Num({ id, value, onChange, min, max, err, disabled, placeholder }: { id: string; value: number | null; onChange: (n: number | null) => void; min?: number; max?: number; err?: boolean; disabled?: boolean; placeholder?: string }) {
  return (
    <input id={id} type="number" inputMode="numeric" className={`input num${err ? ' err' : ''}`} min={min} max={max} disabled={disabled} placeholder={placeholder}
      value={value ?? ''} onChange={(e) => onChange(e.target.value === '' ? null : Number(e.target.value))} />
  );
}

export function ChampForm({ initial, mode, locked = false, approvedCount = 0, onSave }: {
  initial: Championship; mode: 'create' | 'edit'; locked?: boolean; approvedCount?: number;
  onSave: (c: Championship) => Promise<void>;
}) {
  const { toast } = useUi();
  const [d, setD] = useState<Championship>(initial);
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState(false);
  const sp = SPORTS[d.sport];
  const set = (patch: Partial<Championship>) => { setD((s) => ({ ...s, ...patch })); };
  const lastStep = mode === 'create' ? 5 : 4;

  const setSport = (s: SportId) => {
    if (locked) return;
    const defaults = sportDefaults(s);
    set({ sport: s, ...defaults });
  };

  const allErrors = (): Errors => {
    const e = validateChampionship(d);
    if (!locked) { const fc = checkFormat(d, d.minTeams); if (!fc.ok) e.teams = fc.problems.join(' '); }
    return e;
  };
  const errorStep = (e: Errors) => {
    for (const n of [1, 2, 3, 4]) if (STEP_FIELDS[n].some((k) => e[k])) return n;
    return null;
  };

  const next = () => {
    const e = allErrors();
    const here = Object.fromEntries(Object.entries(e).filter(([k]) => STEP_FIELDS[step]?.includes(k)));
    setErrors(here);
    if (Object.keys(here).length) { toast('Revise os campos destacados.', 'bad'); return; }
    setStep((s) => Math.min(lastStep, s + 1));
    window.scrollTo({ top: 0 });
  };

  const save = async () => {
    const e = allErrors();
    setErrors(e);
    const bad = errorStep(e);
    if (bad) { setStep(bad); toast('Revise os campos destacados.', 'bad'); return; }
    setBusy(true);
    try { await onSave(d); } catch (er) {
      if (er instanceof DomainError && er.fields) { setErrors(er.fields); const b = errorStep(er.fields); if (b) setStep(b); }
      toast((er as Error).message, 'bad');
    } finally { setBusy(false); }
  };

  const txt = (id: string, k: keyof Championship, label: string, opts: { optional?: boolean; hint?: string; type?: string; ph?: string } = {}) => (
    <Field label={label} optional={opts.optional} hint={opts.hint} error={errors[k as string]} htmlFor={id}>
      <input id={id} type={opts.type ?? 'text'} className={`input${errors[k as string] ? ' err' : ''}`} value={(d[k] as string) ?? ''} placeholder={opts.ph}
        onChange={(e) => set({ [k]: e.target.value } as Partial<Championship>)} />
    </Field>
  );

  const fcMin = checkFormat(d, d.minTeams);
  const fcMax = d.maxTeams !== d.minTeams ? checkFormat(d, d.maxTeams) : fcMin;
  const suggestions = [...fcMin.suggestions, ...fcMax.suggestions].filter((s, i, a) => a.findIndex((x) => x.label === s.label) === i);
  const problems = [...new Set([...fcMin.problems.map((p) => p), ...fcMax.problems.filter((p) => !fcMin.problems.includes(p))])];
  const opts = tiebreakOptions(d.sport);
  const enabledTb = d.tiebreakers.filter((t) => opts.some((o) => o.id === t));
  const moveTb = (i: number, dir: -1 | 1) => {
    const a = enabledTb.slice(); const j = i + dir;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]];
    set({ tiebreakers: a });
  };
  const hasCards = sp.cards && (d.stats.yellow || d.stats.red);
  const lockNote = 'Bloqueado depois do sorteio. Refaça o sorteio para mudar.';
  const onOff = (v: boolean) => <Badge tone={v ? 'green' : undefined}>{v ? 'Ativado' : 'Desativado'}</Badge>;

  return (
    <div className="stack lg">
      <div className="stepper" role="tablist" aria-label="Etapas">
        {STEPS.filter((s) => s.n <= lastStep).map((s) => (
          <button key={s.n} role="tab" aria-selected={step === s.n} className={`step${step === s.n ? ' on' : ''}${step > s.n ? ' done' : ''}`}
            onClick={() => { if (mode === 'edit' || s.n <= step) setStep(s.n); }}>
            <span className="n">{step > s.n ? <Icon name="check" size={13} /> : s.n}</span>{s.t}
          </button>
        ))}
      </div>

      {locked && <Banner tone="warn" icon="lock">O sorteio já foi feito. Modalidade e formato estão bloqueados. Placar, pontos, estatísticas e informações gerais ainda podem ser editados.</Banner>}

      {step === 1 && (
        <section className="card pad-lg stack">
          <div><h2 style={{ fontSize: 20 }}>Informações gerais</h2><p className="muted small">O que as equipes e o público vão ver primeiro.</p></div>
          {txt('c-name', 'name', 'Nome do campeonato', { ph: 'Ex.: Copa Bairro Esperança' })}
          <Field label="Descrição" optional error={errors.description} htmlFor="c-desc">
            <textarea id="c-desc" className="textarea" value={d.description} onChange={(e) => set({ description: e.target.value })} placeholder="Conte em poucas linhas como será o campeonato." />
          </Field>
          <div className="field">
            <span className="label" id="sport-l">Modalidade</span>
            <div className="grid g3" role="radiogroup" aria-labelledby="sport-l" style={{ gap: 10 }}>
              {SPORT_LIST.map((s) => (
                <button key={s.id} type="button" role="radio" aria-checked={d.sport === s.id} disabled={locked && d.sport !== s.id}
                  className={`choice${d.sport === s.id ? ' on' : ''}`} onClick={() => setSport(s.id)}>
                  <span className="t">{s.label}</span>
                  <span className="hint">{s.sets ? 'Placar por sets' : s.timed ? 'Tempo cronometrado' : s.id === 'esports' ? 'Mapas ou rodadas' : 'Regras flexíveis'}</span>
                </button>
              ))}
            </div>
          </div>
          {d.sport === 'outra' && txt('c-custom', 'customSport', 'Nome da modalidade', { ph: 'Ex.: Handebol, Beach tennis' })}
          <div className="grid g2">
            <Field label="Categoria" hint="Livre, sub-15, feminino… ou o que você definir." htmlFor="c-cat">
              <input id="c-cat" className="input" list="cats" value={d.category} onChange={(e) => set({ category: e.target.value })} />
              <datalist id="cats">{['Livre', 'Sub-13', 'Sub-15', 'Sub-17', 'Feminino', 'Misto', 'Master', 'Escolar'].map((c) => <option key={c} value={c} />)}</datalist>
            </Field>
            {txt('c-city', 'city', 'Cidade', { optional: true })}
          </div>
          {txt('c-venue', 'venue', 'Local', { optional: true, ph: 'Ex.: Quadra da escola, ginásio, campo do bairro' })}
          <div className="grid g2">
            {txt('c-start', 'startDate', 'Início previsto', { type: 'date' })}
            {txt('c-end', 'endDate', 'Encerramento previsto', { type: 'date', optional: true })}
          </div>
          <p className="hint">Imagem de capa e escudo do campeonato ficam para a versão com armazenamento real de arquivos.</p>
        </section>
      )}

      {step === 2 && (
        <section className="card pad-lg stack">
          <div><h2 style={{ fontSize: 20 }}>Equipes e inscrições</h2><p className="muted small">Define quem pode se inscrever pelo link e como.</p></div>
          <div className="grid g2">
            <Field label="Máximo de equipes" error={errors.maxTeams} htmlFor="c-max"><Num id="c-max" value={d.maxTeams} min={2} max={128} err={!!errors.maxTeams} onChange={(n) => set({ maxTeams: n as number })} /></Field>
            <Field label="Mínimo de equipes" error={errors.minTeams} htmlFor="c-min" hint="O sorteio só roda com esse número de equipes aprovadas."><Num id="c-min" value={d.minTeams} min={2} max={128} err={!!errors.minTeams} onChange={(n) => set({ minTeams: n as number })} /></Field>
            {txt('c-ro', 'regOpenDate', 'Abertura das inscrições', { type: 'date' })}
            {txt('c-rc', 'regCloseDate', 'Encerramento das inscrições', { type: 'date', optional: true })}
            <Field label="Mínimo de jogadores por equipe" optional error={errors.minPlayers} htmlFor="c-minp"><Num id="c-minp" value={d.minPlayers} min={1} err={!!errors.minPlayers} onChange={(n) => set({ minPlayers: n })} placeholder="Sem mínimo" /></Field>
            <Field label="Máximo de jogadores por equipe" optional error={errors.maxPlayers} htmlFor="c-maxp"><Num id="c-maxp" value={d.maxPlayers} min={1} err={!!errors.maxPlayers} onChange={(n) => set({ maxPlayers: n })} placeholder="Sem limite" /></Field>
          </div>
          <div className="grid g2">
            <Field label="Contato exigido" htmlFor="c-contact">
              <select id="c-contact" className="select" value={d.contactRule} onChange={(e) => set({ contactRule: e.target.value as Championship['contactRule'] })}>
                <option value="either">E-mail ou telefone</option><option value="email">E-mail obrigatório</option><option value="phone">Telefone obrigatório</option>
              </select>
            </Field>
            <div className="field"><span className="label">Cidade da equipe</span><Toggle id="c-reqcity" checked={d.requireCity} onChange={(v) => set({ requireCity: v })} title="Exigir cidade" desc="A equipe precisa informar de onde é." /></div>
          </div>
          <Field label="Orientações para os participantes" optional htmlFor="c-notes" hint="Aparece no formulário público de inscrição.">
            <textarea id="c-notes" className="textarea" value={d.regNotes} onChange={(e) => set({ regNotes: e.target.value })} placeholder="Ex.: Levar documento com foto no primeiro jogo." />
          </Field>
        </section>
      )}

      {step === 3 && (
        <section className="card pad-lg stack">
          <div><h2 style={{ fontSize: 20 }}>Formato da competição</h2><p className="muted small">Só aparecem formatos que o Tornevo consegue gerar por completo.</p></div>
          <div className="grid g2" role="radiogroup" aria-label="Formato" style={{ gap: 10 }}>
            {(['groups_knockout', 'league', 'knockout', 'groups'] as FormatId[]).map((f) => (
              <button key={f} type="button" role="radio" aria-checked={d.format === f} disabled={locked && d.format !== f}
                className={`choice${d.format === f ? ' on' : ''}`} onClick={() => !locked && set({ format: f })}>
                <span className="t">{FORMAT_LABEL[f]}</span><span className="hint">{FORMAT_HINT[f]}</span>
              </button>
            ))}
          </div>

          <div className="grid g2">
            {(d.format === 'groups' || d.format === 'groups_knockout') && (
              <Field label="Número de grupos" error={errors.groupCount} htmlFor="c-g"><Num id="c-g" value={d.groupCount} min={2} max={16} disabled={locked} err={!!errors.groupCount} onChange={(n) => set({ groupCount: n as number })} /></Field>
            )}
            {d.format === 'groups_knockout' && (
              <Field label="Classificados por grupo" error={errors.qualifiersPerGroup} htmlFor="c-q" hint={`${(d.groupCount || 0) * (d.qualifiersPerGroup || 0)} equipes avançam para as eliminatórias.`}><Num id="c-q" value={d.qualifiersPerGroup} min={1} max={16} disabled={locked} err={!!errors.qualifiersPerGroup} onChange={(n) => set({ qualifiersPerGroup: n as number })} /></Field>
            )}
            {(d.format === 'league' || d.format === 'groups') && (
              <Field label="Turnos" htmlFor="c-legs">
                <select id="c-legs" className="select" disabled={locked} value={d.legs} onChange={(e) => set({ legs: Number(e.target.value) as 1 | 2 })}>
                  <option value={1}>Turno único</option><option value={2}>Ida e volta</option>
                </select>
              </Field>
            )}
          </div>
          {(d.format === 'knockout' || d.format === 'groups_knockout') && (
            <Toggle id="c-third" checked={d.thirdPlace} locked={locked} lockNote={lockNote} onChange={(v) => set({ thirdPlace: v })} title="Disputa de 3º lugar" desc="Os perdedores das semifinais jogam entre si." />
          )}

          {(problems.length > 0 || errors.teams) && (
            <Banner tone="bad" icon="alert">
              <div className="stack sm">
                <strong>Esse formato não funciona com o número de equipes configurado.</strong>
                <ul style={{ margin: 0, paddingLeft: 18 }}>{(problems.length ? problems : [errors.teams]).map((p) => <li key={p}>{p}</li>)}</ul>
                {suggestions.length > 0 && !locked && (
                  <div className="row wrap">
                    <span className="small">Alternativas:</span>
                    {suggestions.map((s) => <Button key={s.label} size="sm" variant="secondary" onClick={() => set(s.patch)}>{s.label}</Button>)}
                  </div>
                )}
              </div>
            </Banner>
          )}
          {problems.length === 0 && !errors.teams && (d.format === 'groups' || d.format === 'groups_knockout') && (
            <p className="small muted num">Com {d.minTeams} equipes: grupos de {groupSizes(d.minTeams, d.groupCount).join(', ')}. Com {d.maxTeams}: grupos de {groupSizes(d.maxTeams, d.groupCount).join(', ')}.</p>
          )}
          {d.format === 'knockout' && <p className="small muted">Se o número de equipes não for potência de 2 (ex.: 6), as primeiras posições do sorteio avançam direto à rodada seguinte.</p>}

          {d.format !== 'knockout' && (
            <div className="stack">
              <hr className="divider" />
              <h3 style={{ fontSize: 17 }}>Pontuação e desempate</h3>
              {sp.sets ? (
                <Banner icon="info">No vôlei, vitória por 2×0 ou 2×1 vale 3 pontos, vitória no tie-break vale 2 e derrota no tie-break vale 1. Derrota sem tie-break não pontua.</Banner>
              ) : (
                <div className="grid g3">
                  <Field label="Vitória" error={errors.pointsWin} htmlFor="c-pw"><Num id="c-pw" value={d.pointsWin} min={0} max={10} err={!!errors.pointsWin} onChange={(n) => set({ pointsWin: n as number })} /></Field>
                  {sp.draws && <Field label="Empate" error={errors.pointsDraw} htmlFor="c-pd"><Num id="c-pd" value={d.pointsDraw} min={0} max={10} err={!!errors.pointsDraw} onChange={(n) => set({ pointsDraw: n as number })} /></Field>}
                  <Field label="Derrota" error={errors.pointsLoss} htmlFor="c-pl"><Num id="c-pl" value={d.pointsLoss} min={0} max={10} err={!!errors.pointsLoss} onChange={(n) => set({ pointsLoss: n as number })} /></Field>
                </div>
              )}
              <div className="stack sm">
                <span className="label">Critérios de desempate (em ordem)</span>
                {enabledTb.length === 0 && <p className="hint">Sem critérios: empates seguem a ordem alfabética.</p>}
                {enabledTb.map((id, i) => {
                  const o = opts.find((x) => x.id === id)!;
                  return (
                    <div key={id} className="tb-item">
                      <span className="pos" style={{ background: 'var(--surface-2)' }}>{i + 1}</span>
                      <span className="grow"><span className="bold">{o.label}</span><br /><span className="hint">{o.hint}</span></span>
                      <Button size="sm" variant="ghost" className="btn-icon" aria-label="Subir" disabled={i === 0} onClick={() => moveTb(i, -1)}><Icon name="up" size={16} /></Button>
                      <Button size="sm" variant="ghost" className="btn-icon" aria-label="Descer" disabled={i === enabledTb.length - 1} onClick={() => moveTb(i, 1)}><Icon name="down" size={16} /></Button>
                      <Button size="sm" variant="ghost" className="btn-icon" aria-label="Remover critério" onClick={() => set({ tiebreakers: enabledTb.filter((t) => t !== id) })}><Icon name="x" size={16} /></Button>
                    </div>
                  );
                })}
                <div className="row wrap">
                  {opts.filter((o) => !enabledTb.includes(o.id)).map((o) => (
                    <Button key={o.id} size="sm" variant="secondary" icon="plus" onClick={() => set({ tiebreakers: [...enabledTb, o.id as TiebreakId] })}>{o.label}</Button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </section>
      )}

      {step === 4 && (
        <section className="card pad-lg stack">
          <div><h2 style={{ fontSize: 20 }}>Regras da partida e estatísticas</h2><p className="muted small">Ative só o que o seu campeonato usa. O que ficar desligado não aparece nas telas de partida.</p></div>
          {sp.timed && (
            <div className="grid g2">
              <Field label={d.sport === 'basquete' ? 'Quantidade de quartos' : 'Quantidade de períodos'} error={errors.periods} htmlFor="c-per"><Num id="c-per" value={d.periods} min={1} max={8} err={!!errors.periods} onChange={(n) => set({ periods: n as number })} /></Field>
              <Field label="Duração de cada período (min)" error={errors.periodMinutes} htmlFor="c-pm"><Num id="c-pm" value={d.periodMinutes} min={1} max={120} err={!!errors.periodMinutes} onChange={(n) => set({ periodMinutes: n as number })} /></Field>
            </div>
          )}
          {sp.sets && (
            <div className="grid g3">
              <Field label="Formato" htmlFor="c-stw">
                <select id="c-stw" className="select" value={d.setsToWin} onChange={(e) => set({ setsToWin: Number(e.target.value) })}>
                  <option value={1}>Set único</option><option value={2}>Melhor de 3 sets</option><option value={3}>Melhor de 5 sets</option>
                </select>
              </Field>
              <Field label="Pontos por set" error={errors.setPoints} htmlFor="c-sp"><Num id="c-sp" value={d.setPoints} min={5} max={50} err={!!errors.setPoints} onChange={(n) => set({ setPoints: n as number })} /></Field>
              <Field label="Pontos do set decisivo" error={errors.tiebreakSetPoints} htmlFor="c-tsp"><Num id="c-tsp" value={d.tiebreakSetPoints} min={5} max={50} err={!!errors.tiebreakSetPoints} onChange={(n) => set({ tiebreakSetPoints: n as number })} /></Field>
            </div>
          )}
          {!sp.timed && !sp.sets && <Banner icon="info">Esta modalidade não usa tempo cronometrado. O placar é registrado em {sp.scoreUnit}.</Banner>}

          <hr className="divider" />
          <h3 style={{ fontSize: 17 }}>Estatísticas e cartões</h3>
          {!sp.cards && !sp.scorers && <Banner icon="info">{sp.label} registra apenas o placar da partida. Cartões, artilharia e suspensões não se aplicam.</Banner>}
          <div className="grid g2">
            <Toggle id="s-y" checked={d.stats.yellow} locked={!sp.cards} lockNote={`Não se aplica a ${sp.label.toLowerCase()}.`} onChange={(v) => set({ stats: { ...d.stats, yellow: v } })} title="Cartões amarelos" desc="Registre cartões amarelos por jogador na partida." />
            <Toggle id="s-r" checked={d.stats.red} locked={!sp.cards} lockNote={`Não se aplica a ${sp.label.toLowerCase()}.`} onChange={(v) => set({ stats: { ...d.stats, red: v } })} title="Cartões vermelhos" desc="Registre expulsões por jogador." />
            <Toggle id="s-g" checked={d.stats.scorers} locked={!sp.scorers} lockNote={`Não se aplica a ${sp.label.toLowerCase()}.`} onChange={(v) => set({ stats: { ...d.stats, scorers: v, assists: v ? d.stats.assists : false } })} title="Artilharia" desc="Registre quem fez cada gol e mostre a tabela de artilheiros." />
            <Toggle id="s-a" checked={d.stats.assists} locked={!sp.assists || !d.stats.scorers} lockNote={!sp.assists ? `Não se aplica a ${sp.label.toLowerCase()}.` : 'Ative a artilharia primeiro.'} onChange={(v) => set({ stats: { ...d.stats, assists: v } })} title="Assistências" desc="Registre quem passou para cada gol." />
            <Toggle id="s-s" checked={d.stats.suspensions} locked={!hasCards} lockNote="Ative cartões amarelos ou vermelhos primeiro." onChange={(v) => set({ stats: { ...d.stats, suspensions: v } })} title="Suspensões automáticas" desc="Vermelho suspende por 1 jogo. Amarelos acumulados também." />
          </div>
          {d.stats.suspensions && hasCards && d.stats.yellow && (
            <Field label="Amarelos para suspensão" error={errors.yellowLimit} htmlFor="c-yl" hint="Ao chegar a esse número de amarelos, o jogador fica de fora da partida seguinte." className="" >
              <div style={{ maxWidth: 160 }}><Num id="c-yl" value={d.yellowLimit} min={2} max={10} err={!!errors.yellowLimit} onChange={(n) => set({ yellowLimit: n as number })} /></div>
            </Field>
          )}
          <div className="row wrap small">
            <span className="muted">Resumo:</span>
            <span>Amarelos {onOff(d.stats.yellow && sp.cards)}</span><span>Vermelhos {onOff(d.stats.red && sp.cards)}</span>
            <span>Artilharia {onOff(d.stats.scorers && sp.scorers)}</span><span>Assistências {onOff(d.stats.assists && sp.assists)}</span><span>Suspensões {onOff(d.stats.suspensions && hasCards)}</span>
          </div>
        </section>
      )}

      {step === 5 && mode === 'create' && (
        <section className="card pad-lg stack">
          <div><h2 style={{ fontSize: 20 }}>Revisão</h2><p className="muted small">Confira antes de criar. Tudo pode ser editado depois em Configurações.</p></div>
          <dl className="kv">
            <dt>Nome</dt><dd>{d.name}</dd>
            <dt>Modalidade</dt><dd>{sportName(d)} · {d.category}</dd>
            <dt>Datas</dt><dd>{fmtDate(d.startDate)}{d.endDate ? ` a ${fmtDate(d.endDate)}` : ''}</dd>
            <dt>Local</dt><dd>{[d.venue, d.city].filter(Boolean).join(', ') || '—'}</dd>
            <dt>Equipes</dt><dd>{d.minTeams} a {d.maxTeams}{d.minPlayers || d.maxPlayers ? ` · elenco ${d.minPlayers ?? '—'} a ${d.maxPlayers ?? '—'}` : ''}</dd>
            <dt>Inscrições</dt><dd>{fmtDate(d.regOpenDate)}{d.regCloseDate ? ` a ${fmtDate(d.regCloseDate)}` : ' (sem data final)'}</dd>
            <dt>Formato</dt><dd>{FORMAT_LABEL[d.format]}{d.format !== 'knockout' && d.format !== 'league' ? `, ${d.groupCount} grupos` : ''}{d.format === 'groups_knockout' ? `, ${d.qualifiersPerGroup} por grupo avançam` : ''}{d.thirdPlace && d.format !== 'league' && d.format !== 'groups' ? ', com 3º lugar' : ''}</dd>
            <dt>Partida</dt><dd>{sp.sets ? `Melhor de ${d.setsToWin * 2 - 1} sets, ${d.setPoints} pontos` : sp.timed ? `${d.periods} × ${d.periodMinutes} min` : `Placar em ${sp.scoreUnit}`}</dd>
            <dt>Estatísticas</dt><dd className="row wrap" style={{ gap: 6 }}>
              {[['Amarelos', d.stats.yellow && sp.cards], ['Vermelhos', d.stats.red && sp.cards], ['Artilharia', d.stats.scorers && sp.scorers], ['Assistências', d.stats.assists && sp.assists], ['Suspensões', d.stats.suspensions && hasCards]].map(([l, on]) => <Badge key={l as string} tone={on ? 'green' : undefined}>{l as string}: {on ? 'sim' : 'não'}</Badge>)}
            </dd>
          </dl>
          <Toggle id="c-open" checked={d.status === 'inscricoes'} onChange={(v) => set({ status: v ? 'inscricoes' : 'preparacao' })} title="Abrir inscrições agora" desc="Desligado, o campeonato fica em preparação e o link de inscrição avisa que ainda não abriu." />
          <Banner icon="link">Ao criar, o Tornevo gera dois códigos aleatórios diferentes: um para o público acompanhar e outro para as equipes se inscreverem.</Banner>
        </section>
      )}

      <div className="sticky-actions">
        <Button variant="secondary" icon="back" onClick={() => setStep((s) => Math.max(1, s - 1))} disabled={step === 1}>Voltar</Button>
        <div className="row wrap" style={{ justifyContent: 'flex-end' }}>
          {mode === 'edit' && <Button variant="primary" loading={busy} onClick={save}>Salvar alterações</Button>}
          {step < lastStep && <Button variant={mode === 'edit' ? 'secondary' : 'primary'} onClick={next}>Continuar</Button>}
          {step === lastStep && mode === 'create' && <Button variant="primary" icon="trophy" loading={busy} onClick={save}>Criar campeonato</Button>}
        </div>
      </div>
    </div>
  );
}
