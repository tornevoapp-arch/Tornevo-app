import { config } from '../config';

/** Lê um arquivo de imagem, reduz para 160x160 e devolve data URL. Valida tipo e tamanho. */
export async function fileToShield(file: File): Promise<string> {
  if (!/^image\/(png|jpe?g|webp)$/.test(file.type)) throw new Error('Use uma imagem PNG, JPG ou WebP.');
  if (file.size > 4 * 1024 * 1024) throw new Error('A imagem passa de 4 MB. Escolha uma menor.');
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error('Não foi possível ler a imagem.'));
      i.src = url;
    });
    const size = 160;
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Seu navegador não conseguiu processar a imagem.');
    const s = Math.min(img.width, img.height);
    ctx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
    for (const q of [0.88, 0.7, 0.5]) {
      const data = canvas.toDataURL('image/jpeg', q);
      if (data.length * 0.75 <= config.maxShieldBytes) return data;
    }
    throw new Error('A imagem ficou grande demais mesmo reduzida.');
  } finally {
    URL.revokeObjectURL(url);
  }
}
