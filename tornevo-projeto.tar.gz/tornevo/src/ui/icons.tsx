const P: Record<string, string> = {
  home: 'M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
  trophy: 'M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3',
  plus: 'M12 5v14M5 12h14',
  users: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
  calendar: 'M3 5h18v16H3zM3 10h18M8 3v4M16 3v4',
  table: 'M5 21V10M12 21V4M19 21v-8',
  chart: 'M3 3v18h18M7 15l4-4 3 3 5-6',
  sliders: 'M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4',
  link: 'M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1',
  copy: 'M9 9h11v11H9zM5 15H4V4h11v1',
  check: 'M5 12l5 5 9-10',
  x: 'M6 6l12 12M18 6L6 18',
  edit: 'M4 20h4L19 9l-4-4L4 16zM13 7l4 4',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4-4',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  shuffle: 'M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5',
  back: 'M19 12H5M12 19l-7-7 7-7',
  down: 'M6 9l6 6 6-6',
  up: 'M6 15l6-6 6 6',
  refresh: 'M20 11a8 8 0 0 0-14-4M4 4v4h4M4 13a8 8 0 0 0 14 4M20 20v-4h-4',
  info: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 16v-5M12 8h.01',
  clock: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2',
  upload: 'M12 16V4M7 9l5-5 5 5M4 20h16',
  layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5',
  alert: 'M12 3l10 18H2zM12 10v5M12 18h.01',
  flag: 'M5 21V4M5 4h11l-2 4 2 4H5',
  card: 'M7 3h10v18H7z',
  whistle: 'M3 12a5 5 0 1 0 10 0 5 5 0 0 0-10 0zM13 9h8v4h-8',
  lock: 'M6 11h12v10H6zM8 11V7a4 4 0 0 1 8 0v4',
  ban: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM5 5l14 14',
  play: 'M7 4l13 8-13 8z',
};

export function Icon({ name, size = 18, className }: { name: keyof typeof P | string; size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className} style={{ flex: 'none' }}>
      <path d={P[name] ?? P.info} />
    </svg>
  );
}

/** Logo própria do Tornevo: taça cujo topo e haste formam um T. Troque por um arquivo de marca quando existir. */
export function LogoMark({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true" style={{ flex: 'none' }}>
      <rect width="48" height="48" rx="13" fill="#F07828" />
      <path d="M13 13h22v7a11 11 0 0 1-22 0z" fill="#fff" />
      <path d="M13 16H9v3a5 5 0 0 0 4.5 5M35 16h4v3a5 5 0 0 1-4.5 5" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
      <rect x="22" y="29" width="4" height="7" fill="#fff" />
      <rect x="16" y="36" width="16" height="4" rx="2" fill="#fff" />
    </svg>
  );
}

export function Logo({ compact = false, size = 32 }: { compact?: boolean; size?: number }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }} aria-label="Tornevo">
      <LogoMark size={size} />
      {!compact && <span className="display" style={{ fontWeight: 700, fontSize: size * 0.68, letterSpacing: '-0.02em' }}>Tornevo</span>}
    </span>
  );
}
