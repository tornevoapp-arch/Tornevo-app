import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { Icon } from './icons';
import { initials } from '../domain/format';
import type { Api } from '../services/api';
import { DomainError } from '../services/api';
import type { Team } from '../types';

/* ---------- contexto de dados ---------- */
export const ApiCtx = createContext<Api>(null as unknown as Api);
export const useApi = () => useContext(ApiCtx);

export function useQuery<T>(fn: (api: Api) => Promise<T>, deps: unknown[] = []) {
  const api = useApi();
  const [state, setState] = useState<{ data?: T; loading: boolean; error?: string }>({ loading: true });
  const [tick, setTick] = useState(0);
  useEffect(() => api.subscribe(() => setTick((t) => t + 1)), [api]);
  useEffect(() => {
    let alive = true;
    fn(api).then(
      (data) => alive && setState({ data, loading: false }),
      (e) => alive && setState((s) => ({ ...s, loading: false, error: e instanceof Error ? e.message : 'Erro ao carregar.' })),
    );
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api, tick, ...deps]);
  return state;
}

/* ---------- avisos e confirmações ---------- */
interface ToastItem { id: number; msg: string; kind: 'ok' | 'bad' | 'info' }
interface ConfirmOpts { title: string; body?: ReactNode; confirmLabel?: string; danger?: boolean }
interface UiCtx { toast: (msg: string, kind?: ToastItem['kind']) => void; confirm: (o: ConfirmOpts) => Promise<boolean>; fail: (e: unknown) => void }
const Ui = createContext<UiCtx>(null as unknown as UiCtx);
export const useUi = () => useContext(Ui);

export function UiProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [dlg, setDlg] = useState<(ConfirmOpts & { resolve: (v: boolean) => void }) | null>(null);
  const idRef = useRef(1);
  const toast = useCallback((msg: string, kind: ToastItem['kind'] = 'ok') => {
    const id = idRef.current++;
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === 'bad' ? 6000 : 3200);
  }, []);
  const confirm = useCallback((o: ConfirmOpts) => new Promise<boolean>((resolve) => setDlg({ ...o, resolve })), []);
  const fail = useCallback((e: unknown) => {
    toast(e instanceof DomainError || e instanceof Error ? e.message : 'Algo deu errado. Tente de novo.', 'bad');
  }, [toast]);
  const close = (v: boolean) => { dlg?.resolve(v); setDlg(null); };
  return (
    <Ui.Provider value={{ toast, confirm, fail }}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.kind}`}>
            <Icon name={t.kind === 'bad' ? 'alert' : 'check'} /> <span>{t.msg}</span>
          </div>
        ))}
      </div>
      {dlg && (
        <Modal title={dlg.title} onClose={() => close(false)}
          footer={<>
            <button className="btn btn-secondary" onClick={() => close(false)}>Cancelar</button>
            <button className={`btn ${dlg.danger ? 'btn-danger' : 'btn-primary'}`} onClick={() => close(true)} autoFocus>{dlg.confirmLabel ?? 'Confirmar'}</button>
          </>}>
          <div className="muted">{dlg.body}</div>
        </Modal>
      )}
    </Ui.Provider>
  );
}

/* ---------- componentes básicos ---------- */
export function Modal({ title, onClose, children, footer, wide }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`modal${wide ? ' wide' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="modal-head">
          <h2>{title}</h2>
          <button className="btn btn-ghost btn-icon" onClick={onClose} aria-label="Fechar"><Icon name="x" /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Button({ variant = 'secondary', size, loading, icon, children, className = '', ...rest }:
  { variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'danger-soft'; size?: 'sm'; loading?: boolean; icon?: string; children?: ReactNode; className?: string } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button type="button" {...rest} disabled={rest.disabled || loading}
      className={`btn btn-${variant}${size ? ' btn-sm' : ''} ${className}`}>
      {loading ? <span className="spin" /> : icon ? <Icon name={icon} size={size ? 16 : 18} /> : null}
      {children}
    </button>
  );
}

export function Field({ label, optional, hint, error, children, htmlFor, className = '' }: { label: string; optional?: boolean; hint?: string; error?: string; children: ReactNode; htmlFor?: string; className?: string }) {
  return (
    <div className={`field ${className}`}>
      <label className="label" htmlFor={htmlFor}>{label}{optional && <span className="opt"> (opcional)</span>}</label>
      {children}
      {error ? <span className="err-text" role="alert">{error}</span> : hint ? <span className="hint">{hint}</span> : null}
    </div>
  );
}

export function Badge({ tone, children, dot }: { tone?: 'orange' | 'green' | 'red' | 'blue'; children: ReactNode; dot?: boolean }) {
  return <span className={`badge${tone ? ` b-${tone}` : ''}`}>{dot && <i className="dot" />}{children}</span>;
}

export function Toggle({ id, checked, onChange, title, desc, locked, lockNote }: { id: string; checked: boolean; onChange: (v: boolean) => void; title: string; desc?: string; locked?: boolean; lockNote?: string }) {
  return (
    <label className={`switch${checked && !locked ? ' on' : ''}${locked ? ' off-lock' : ''}`} htmlFor={id}>
      <input id={id} type="checkbox" checked={checked && !locked} disabled={locked} onChange={(e) => onChange(e.target.checked)} />
      <span className="stack sm" style={{ gap: 2 }}>
        <span className="bold">{title}</span>
        {(desc || lockNote) && <span className="hint">{locked && lockNote ? lockNote : desc}</span>}
      </span>
    </label>
  );
}

export function Empty({ icon = 'trophy', title, children, action }: { icon?: string; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="empty">
      <div className="ill"><Icon name={icon} size={32} /></div>
      <h3 style={{ fontSize: 20 }}>{title}</h3>
      {children && <p>{children}</p>}
      {action}
    </div>
  );
}

export function Banner({ tone, icon = 'info', children }: { tone?: 'warn' | 'bad' | 'good'; icon?: string; children: ReactNode }) {
  return <div className={`banner${tone ? ` ${tone}` : ''}`}><Icon name={icon} /><div style={{ minWidth: 0 }}>{children}</div></div>;
}

const SHIELD_COLORS = ['#E4692A', '#3B7DD8', '#2F9E6E', '#8B5CC4', '#D1456B', '#C28A12', '#2A8FA3', '#5B6B7F'];
export function Shield({ team, size = 32 }: { team: Pick<Team, 'name' | 'shield'> | null; size?: number }) {
  if (!team) return <span className="shield" style={{ width: size, height: size, background: 'var(--surface-2)', color: 'var(--muted)', fontSize: size * 0.42 }}>?</span>;
  if (team.shield) return <span className="shield" style={{ width: size, height: size }}><img src={team.shield} alt="" /></span>;
  let h = 0;
  for (const ch of team.name) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return <span className="shield" style={{ width: size, height: size, background: SHIELD_COLORS[h % SHIELD_COLORS.length], fontSize: size * 0.4 }}>{initials(team.name)}</span>;
}

export function CopyField({ value, label }: { value: string; label: string }) {
  const { toast } = useUi();
  const copy = async () => {
    try { await navigator.clipboard.writeText(value); toast('Link copiado.'); return; } catch { /* tenta alternativa */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = value; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      toast(ok ? 'Link copiado.' : 'Não foi possível copiar. Selecione o texto e copie.', ok ? 'ok' : 'bad');
    } catch { toast('Não foi possível copiar. Selecione o texto e copie.', 'bad'); }
  };
  return (
    <div className="copy-field">
      <code title={value}>{value}</code>
      <Button size="sm" variant="secondary" icon="copy" onClick={copy} aria-label={`Copiar ${label}`}>Copiar</Button>
    </div>
  );
}

export function Loading({ label = 'Carregando…' }: { label?: string }) {
  return <div className="row muted" style={{ padding: 40, justifyContent: 'center' }}><span className="spin" /> {label}</div>;
}

export function Progress({ value, max }: { value: number; max: number }) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  return <div className="progress" role="progressbar" aria-valuenow={value} aria-valuemax={max}><i style={{ width: `${pct}%` }} /></div>;
}
