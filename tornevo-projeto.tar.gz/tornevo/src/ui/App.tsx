import { useEffect, useState } from 'react';
import { RouterProvider, useRouter } from './router';
import { ApiCtx, Loading, UiProvider } from './kit';
import { Shell } from './pages/shell';
import { Dashboard } from './pages/dashboard';
import { Championships, NewChampionship } from './pages/championships';
import { ChampLayout, Overview, Settings } from './pages/champ';
import { Teams } from './pages/teams';
import { Matches } from './pages/matches';
import { Standings, Stats } from './pages/standings-stats';
import { PublicRegister, PublicTournament } from './pages/public';
import { About, NotFound, Placeholder } from './pages/misc';
import { openRepository } from '../data/indexeddb';
import { createApi, type Api } from '../services/api';
import { ensureSeeded } from '../data/seed';

function Routes() {
  const { route } = useRouter();
  const p = route.params;
  switch (route.name) {
    case 'register': return <PublicRegister code={p.codigo} />;
    case 'public': return <PublicTournament code={p.codigo} />;
    case 'dashboard': return <Shell><Dashboard /></Shell>;
    case 'championships': return <Shell><Championships /></Shell>;
    case 'new': return <Shell><NewChampionship /></Shell>;
    case 'overview': return <Shell><ChampLayout id={p.id} tab="">{(v) => <Overview v={v} />}</ChampLayout></Shell>;
    case 'teams': return <Shell><ChampLayout id={p.id} tab="equipes">{(v) => <Teams v={v} />}</ChampLayout></Shell>;
    case 'matches': return <Shell><ChampLayout id={p.id} tab="partidas">{(v) => <Matches v={v} />}</ChampLayout></Shell>;
    case 'standings': return <Shell><ChampLayout id={p.id} tab="classificacao">{(v) => <Standings v={v} />}</ChampLayout></Shell>;
    case 'stats': return <Shell><ChampLayout id={p.id} tab="estatisticas">{(v) => <Stats v={v} />}</ChampLayout></Shell>;
    case 'settings': return <Shell><ChampLayout id={p.id} tab="configuracoes">{(v) => <Settings v={v} />}</ChampLayout></Shell>;
    case 'about': return <Shell><About /></Shell>;
    case 'privacy': return <Shell><Placeholder title="Política de privacidade">Esta página existe na rota prevista, mas o texto oficial ainda não foi escrito. Nesta demonstração nenhum dado sai do seu navegador.</Placeholder></Shell>;
    case 'terms': return <Shell><Placeholder title="Termos de uso">Esta página existe na rota prevista, mas o texto oficial ainda não foi escrito.</Placeholder></Shell>;
    default: return <Shell><NotFound /></Shell>;
  }
}

export function App() {
  const [api, setApi] = useState<Api | null>(null);
  const [err, setErr] = useState('');
  useEffect(() => {
    (async () => {
      try {
        const a = createApi(await openRepository());
        await ensureSeeded(a);
        setApi(a);
      } catch (e) { setErr((e as Error).message); }
    })();
  }, []);
  if (err) return <div className="gutter" style={{ paddingBlock: 40 }}><p>Não foi possível iniciar a demonstração: {err}</p></div>;
  if (!api) return <Loading label="Preparando a demonstração…" />;
  return (
    <ApiCtx.Provider value={api}>
      <UiProvider><RouterProvider initial="/painel"><Routes /></RouterProvider></UiProvider>
    </ApiCtx.Provider>
  );
}
