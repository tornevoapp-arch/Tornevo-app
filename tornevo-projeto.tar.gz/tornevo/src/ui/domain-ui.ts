export { fmtDate, fmtDateLong, todayISO, fmtDateRange, plural } from '../domain/format';
