import { createContext, useCallback, useContext, useMemo, useState, type ReactNode, type MouseEvent } from 'react';

/**
 * Roteador em memória. As rotas espelham as previstas para produção (/painel, /torneio/:codigo...),
 * mas a barra de endereço do preview não acompanha, então o app navega por estado.
 * Em produção, troque por React Router mantendo os mesmos caminhos.
 */
export interface Route { name: string; params: Record<string, string>; path: string }

const PATTERNS: Array<[string, string]> = [
  ['/painel', 'dashboard'],
  ['/painel/campeonatos', 'championships'],
  ['/painel/campeonatos/novo', 'new'],
  ['/painel/campeonatos/:id', 'overview'],
  ['/painel/campeonatos/:id/equipes', 'teams'],
  ['/painel/campeonatos/:id/partidas', 'matches'],
  ['/painel/campeonatos/:id/classificacao', 'standings'],
  ['/painel/campeonatos/:id/estatisticas', 'stats'],
  ['/painel/campeonatos/:id/configuracoes', 'settings'],
  ['/torneio/:codigo', 'public'],
  ['/inscricao/:codigo', 'register'],
  ['/sobre', 'about'],
  ['/privacidade', 'privacy'],
  ['/termos', 'terms'],
];

export function matchRoute(path: string): Route {
  const clean = path.replace(/\/+$/, '') || '/';
  if (clean === '/') return { name: 'dashboard', params: {}, path: '/painel' };
  const parts = clean.split('/').filter(Boolean);
  for (const [pattern, name] of PATTERNS) {
    const pp = pattern.split('/').filter(Boolean);
    if (pp.length !== parts.length) continue;
    const params: Record<string, string> = {};
    let ok = true;
    for (let i = 0; i < pp.length; i++) {
      if (pp[i].startsWith(':')) params[pp[i].slice(1)] = decodeURIComponent(parts[i]);
      else if (pp[i] !== parts[i]) { ok = false; break; }
    }
    if (ok) return { name, params, path: clean };
  }
  return { name: 'notfound', params: {}, path: clean };
}

interface Ctx { route: Route; navigate: (p: string, o?: { replace?: boolean }) => void; back: () => void; canBack: boolean }
const RouterCtx = createContext<Ctx>(null as unknown as Ctx);

export function RouterProvider({ children, initial = '/painel' }: { children: ReactNode; initial?: string }) {
  const [stack, setStack] = useState<string[]>([initial]);
  const navigate = useCallback((p: string, o?: { replace?: boolean }) => {
    setStack((s) => (o?.replace ? [...s.slice(0, -1), p] : [...s, p]));
    try { window.scrollTo({ top: 0 }); } catch { /* sem scroll */ }
  }, []);
  const back = useCallback(() => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)), []);
  const value = useMemo(() => ({
    route: matchRoute(stack[stack.length - 1]), navigate, back, canBack: stack.length > 1,
  }), [stack, navigate, back]);
  return <RouterCtx.Provider value={value}>{children}</RouterCtx.Provider>;
}

export const useRouter = () => useContext(RouterCtx);

export function Link({ to, children, className, onClick, ...rest }: { to: string; children: ReactNode; className?: string; onClick?: () => void; [k: string]: unknown }) {
  const { navigate } = useRouter();
  return (
    <a
      href={`#${to}`}
      className={className}
      onClick={(e: MouseEvent) => { e.preventDefault(); onClick?.(); navigate(to); }}
      {...rest}
    >
      {children}
    </a>
  );
}
