import { useMemo } from 'react';
import { Badge, Banner, Empty, Shield } from '../kit';
import { RankingTable, ScorersView, StandingsView, teamMap } from '../views';
import { SPORTS } from '../../domain/sports';
import { computeSuspensions, playerStats, ranking, teamTotals } from '../../domain/stats';
import type { ChampionshipView } from '../../services/api';
import { Link } from '../router';

export function Standings({ v }: { v: ChampionshipView }) {
  return <StandingsView champ={v.champ} teams={v.teams.filter((t) => t.status === 'approved')} matches={v.matches} />;
}

export function Stats({ v }: { v: ChampionshipView }) {
  const c = v.champ;
  const sp = SPORTS[c.sport];
  const approved = v.teams.filter((t) => t.status === 'approved');
  const st = useMemo(() => playerStats(v.players, v.matches), [v]);
  const goals = ranking(st, 'goals', v.players).map((s) => ({ playerId: s.playerId, teamId: s.teamId, value: s.goals }));
  const assists = ranking(st, 'assists', v.players).map((s) => ({ playerId: s.playerId, teamId: s.teamId, value: s.assists }));
  const cards = [...st.values()].filter((s) => s.yellow + s.red > 0).sort((a, b) => b.red * 3 + b.yellow - (a.red * 3 + a.yellow));
  const sus = computeSuspensions(c, approved, v.matches);
  const totals = teamTotals(approved, v.matches).filter((t) => t.played > 0);
  const tm = teamMap(approved);
  const pm = new Map(v.players.map((p) => [p.id, p]));
  const best = (key: 'gf' | 'ga' | 'wins', dir: 1 | -1) => totals.slice().sort((a, b) => dir * (b[key] - a[key]) || a.teamId.localeCompare(b.teamId))[0];
  const attack = totals.length ? best('gf', 1) : null, defense = totals.length ? best('ga', -1) : null, wins = totals.length ? best('wins', 1) : null;
  const onOff = (label: string, on: boolean) => <Badge key={label} tone={on ? 'green' : undefined}>{label}: {on ? 'ativado' : 'desativado'}</Badge>;
  const unit = sp.scoreUnit;
  const card = (title: string, t: { teamId: string } | null, value: string) => (
    <div className="card pad stack sm"><span className="muted small bold">{title}</span>
      {t ? <div className="row"><Shield team={tm.get(t.teamId) ?? null} size={30} /><div><div className="bold">{tm.get(t.teamId)?.name}</div><div className="small muted num">{value}</div></div></div> : <span className="muted small">Sem partidas encerradas</span>}</div>
  );
  return (
    <div className="stack lg">
      <section className="card pad stack sm">
        <div className="row between wrap"><h2 style={{ fontSize: 17 }}>Estatísticas deste campeonato</h2><Link to={`/painel/campeonatos/${c.id}/configuracoes`} className="small" style={{ color: 'var(--accent-text)', fontWeight: 700 }}>Alterar</Link></div>
        <div className="row wrap">
          {onOff('Amarelos', c.stats.yellow && sp.cards)}{onOff('Vermelhos', c.stats.red && sp.cards)}{onOff('Artilharia', c.stats.scorers && sp.scorers)}{onOff('Assistências', c.stats.assists && sp.assists)}{onOff('Suspensões', c.stats.suspensions && sp.cards)}
        </div>
        {!sp.cards && !sp.scorers && <p className="small muted">{sp.label} registra apenas o placar. Os dados de equipes abaixo são calculados automaticamente.</p>}
      </section>

      <div className="grid g3">
        {card('Melhor ataque', attack, attack ? `${attack.gf} ${unit} em ${attack.played} jogos` : '')}
        {card('Melhor defesa', defense, defense ? `${defense.ga} ${unit} sofridos em ${defense.played} jogos` : '')}
        {card('Mais vitórias', wins, wins ? `${wins.wins} vitórias` : '')}
      </div>

      {c.stats.scorers && sp.scorers && <div className="grid g2">
        <ScorersView champ={c} teams={approved} players={v.players} matches={v.matches} />
        {c.stats.assists && sp.assists && <RankingTable title="Assistências" rows={assists} players={v.players} teams={approved} unit="Assist." />}
      </div>}
      {!c.stats.scorers && sp.scorers && <Empty icon="chart" title="Artilharia desativada">Ative em Configurações, etapa Regras, para registrar quem marca os gols.</Empty>}

      {sp.cards && (c.stats.yellow || c.stats.red) && (
        <section className="card"><div className="card-head"><h3>Cartões</h3></div>
          {cards.length === 0 ? <p className="muted small pad">Nenhum cartão registrado.</p> : (
            <div className="tbl-wrap"><table className="tbl"><thead><tr><th>#</th><th className="left">Jogador</th><th className="left">Equipe</th>{c.stats.yellow && <th>Amarelos</th>}{c.stats.red && <th>Vermelhos</th>}</tr></thead>
              <tbody>{cards.slice(0, 15).map((s, i) => <tr key={s.playerId}><td><span className="pos">{i + 1}</span></td><td className="left" style={{ fontWeight: 600 }}>{pm.get(s.playerId)?.name}</td><td className="left muted">{tm.get(s.teamId)?.name}</td>{c.stats.yellow && <td>{s.yellow}</td>}{c.stats.red && <td>{s.red}</td>}</tr>)}</tbody></table></div>
          )}</section>
      )}

      {c.stats.suspensions && sp.cards && (
        <section className="card pad stack"><h3 style={{ fontSize: 17 }}>Suspensões</h3>
          {sus.suspended.length === 0 && sus.hanging.length === 0 ? <p className="muted small">Ninguém suspenso ou pendurado agora.</p> : <>
            {sus.suspended.length > 0 && <div className="stack sm"><span className="label">Suspensos na próxima partida</span>
              {sus.suspended.map((s) => <div key={s.playerId} className="row"><Badge tone="red">{s.reason === 'vermelho' ? 'Vermelho' : `${c.yellowLimit} amarelos`}</Badge><span className="bold">{pm.get(s.playerId)?.name}</span><span className="muted small">{tm.get(s.teamId)?.name}</span></div>)}</div>}
            {sus.hanging.length > 0 && <div className="stack sm"><span className="label">Pendurados (um amarelo de suspensão)</span>
              {sus.hanging.map((s) => <div key={s.playerId} className="row"><Badge tone="orange">Pendurado</Badge><span className="bold">{pm.get(s.playerId)?.name}</span><span className="muted small">{tm.get(s.teamId)?.name}</span></div>)}</div>}
          </>}
          <Banner icon="info">Regra deste campeonato: vermelho suspende 1 jogo; a cada {c.yellowLimit} amarelos acumulados, 1 jogo de suspensão.</Banner>
        </section>
      )}
    </div>
  );
}
