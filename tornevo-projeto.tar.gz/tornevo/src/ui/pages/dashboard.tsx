import { Link, useRouter } from '../router';
import { Badge, Button, Empty, Loading, Progress, Shield, useApi, useQuery, useUi } from '../kit';
import { Icon } from '../icons';
import { StatusBadge } from '../views';
import { fmtDate, fmtDateLong, todayISO } from '../domain-ui';
import { sportName } from '../../domain/sports';
import { resetDemo } from '../../data/seed';
import type { Summary } from '../../services/api';
import { useState } from 'react';

export function Dashboard() {
  const { navigate } = useRouter();
  const api = useApi();
  const { toast, fail } = useUi();
  const [busy, setBusy] = useState(false);
  const q = useQuery((a) => a.getDashboard());
  if (!q.data) return <div className="page"><Loading /></div>;
  const { summaries, upcoming, recent } = q.data;
  const today = todayISO();
  const running = summaries.filter((s) => s.champ.status === 'andamento').length;
  const soon = summaries.filter((s) => (s.champ.status === 'inscricoes' || s.champ.status === 'preparacao') && s.champ.startDate >= today).length;
  const pending = summaries.reduce((a, s) => a + s.pending, 0);
  const firstPending = summaries.find((s) => s.pending > 0);

  if (summaries.length === 0) {
    return (
      <div className="page">
        <div className="card"><Empty icon="trophy" title="Crie seu primeiro campeonato"
          action={<div className="row wrap" style={{ justifyContent: 'center' }}>
            <Button variant="primary" icon="plus" onClick={() => navigate('/painel/campeonatos/novo')}>Criar campeonato</Button>
            <Button variant="secondary" icon="refresh" loading={busy} onClick={async () => { setBusy(true); try { await resetDemo(api); toast('Exemplos carregados.'); } catch (e) { fail(e); } finally { setBusy(false); } }}>Carregar exemplos</Button>
          </div>}>
          Configure o formato, compartilhe o link de inscrição e acompanhe tudo daqui. Ou carregue os exemplos para testar.
        </Empty></div>
      </div>
    );
  }

  const tile = (v: number, l: string, icon: string, to?: string) => {
    const inner = (<><div className="row between"><span className="tile v num">{v}</span><span className="badge b-orange" style={{ padding: 7 }}><Icon name={icon} size={18} /></span></div><span className="l">{l}</span></>);
    return to ? <Link to={to} className="card tile" style={{ textDecoration: 'none' }}>{inner}</Link> : <div className="card tile">{inner}</div>;
  };
  const matchRow = (x: { match: any; champ: any; home: any; away: any }, finished: boolean) => (
    <Link key={x.match.id} to={`/painel/campeonatos/${x.champ.id}/partidas`} className="row" style={{ textDecoration: 'none', padding: '12px 18px', gap: 12 }}>
      <div className="grow stack" style={{ gap: 4 }}>
        <span className="xs muted trunc">{x.champ.name}</span>
        <span className="row" style={{ gap: 8 }}><Shield team={x.home} size={22} /><span className="trunc bold">{x.home?.name}</span><span className="muted">×</span><Shield team={x.away} size={22} /><span className="trunc bold">{x.away?.name}</span></span>
      </div>
      <div className="small num" style={{ textAlign: 'right', flex: 'none' }}>
        {finished ? <strong className="display" style={{ fontSize: 18 }}>{x.match.homeScore} – {x.match.awayScore}</strong> : <span className="muted">{x.match.date ? `${fmtDateLong(x.match.date)}${x.match.time ? ` · ${x.match.time}` : ''}` : 'Sem data'}</span>}
      </div>
    </Link>
  );

  return (
    <div className="page">
      <div className="row between wrap top">
        <div><h1 className="page-title">Painel</h1><p className="page-sub">Visão geral dos seus campeonatos.</p></div>
        <Button variant="primary" icon="plus" onClick={() => navigate('/painel/campeonatos/novo')}>Criar campeonato</Button>
      </div>

      <div className="grid g4">
        {tile(summaries.length, 'Campeonatos criados', 'trophy', '/painel/campeonatos')}
        {tile(running, 'Em andamento', 'play', '/painel/campeonatos')}
        {tile(soon, 'Começam em breve', 'calendar', '/painel/campeonatos')}
        {tile(pending, 'Solicitações pendentes', 'users', firstPending ? `/painel/campeonatos/${firstPending.champ.id}/equipes` : undefined)}
      </div>

      <div className="grid g2">
        <section className="card"><div className="card-head"><h2>Próximas partidas</h2></div>
          <div className="list" style={{ paddingTop: 8 }}>{upcoming.length ? upcoming.map((x) => matchRow(x, false)) : <p className="muted small pad">Nenhuma partida agendada. Sorteie um campeonato para gerar os jogos.</p>}</div>
        </section>
        <section className="card"><div className="card-head"><h2>Últimos resultados</h2></div>
          <div className="list" style={{ paddingTop: 8 }}>{recent.length ? recent.map((x) => matchRow(x, true)) : <p className="muted small pad">Os resultados registrados aparecem aqui.</p>}</div>
        </section>
      </div>

      <section className="stack">
        <h2 style={{ fontSize: 20 }}>Seus campeonatos</h2>
        <div className="grid g3">{summaries.map((s) => <ChampCard key={s.champ.id} s={s} />)}</div>
      </section>
    </div>
  );
}

export function ChampCard({ s }: { s: Summary }) {
  const { navigate } = useRouter();
  const c = s.champ;
  return (
    <article className="card pad stack" style={{ justifyContent: 'space-between' }}>
      <div className="stack sm">
        <div className="row wrap" style={{ gap: 6 }}><StatusBadge status={c.status} />{c.isDemo && <Badge>Exemplo</Badge>}{s.pending > 0 && <Badge tone="orange">{s.pending} pendente{s.pending > 1 ? 's' : ''}</Badge>}</div>
        <h3 style={{ fontSize: 18 }}>{c.name}</h3>
        <p className="small muted">{sportName(c)} · {c.category}{c.city ? ` · ${c.city}` : ''}</p>
        <p className="small muted num"><Icon name="calendar" size={14} /> {fmtDate(c.startDate)}{c.endDate ? ` a ${fmtDate(c.endDate)}` : ''}</p>
      </div>
      <div className="stack sm">
        <div className="row between small"><span className="muted">Equipes aprovadas</span><span className="num bold">{s.approved}/{c.maxTeams}</span></div>
        <Progress value={s.approved} max={c.maxTeams} />
      </div>
      <div className="row wrap">
        <Button size="sm" variant="primary" onClick={() => navigate(`/painel/campeonatos/${c.id}`)}>Gerenciar</Button>
        <Button size="sm" variant="secondary" icon="edit" onClick={() => navigate(`/painel/campeonatos/${c.id}/configuracoes`)}>Editar</Button>
        <Button size="sm" variant="ghost" icon="eye" onClick={() => navigate(`/torneio/${c.publicCode}`)}>Página pública</Button>
      </div>
    </article>
  );
}
