import { useMemo, useState } from 'react';
import type { Match, MatchEvent } from '../../types';
import { Badge, Banner, Button, Empty, Field, Modal, Shield, useApi, useUi } from '../kit';
import { Icon } from '../icons';
import { BracketView, MatchList, teamMap } from '../views';
import { SPORTS } from '../../domain/sports';
import { checkFormat, FORMAT_LABEL, groupSizes } from '../../domain/validation';
import { addDays, todayISO } from '../../domain/format';
import { isKnockout } from '../../domain/results';
import { computeSuspensions } from '../../domain/stats';
import { groupStageComplete } from '../../domain/tournament';
import { randomId } from '../../domain/codes';
import type { ChampionshipView } from '../../services/api';

const toNum = (s: string) => (s.trim() === '' ? null : Number(s));

function MatchModal({ m, v, onClose }: { m: Match; v: ChampionshipView; onClose: () => void }) {
  const api = useApi();
  const { toast, fail, confirm } = useUi();
  const c = v.champ;
  const sp = SPORTS[c.sport];
  const tm = teamMap(v.teams);
  const home = m.homeId ? tm.get(m.homeId) ?? null : null;
  const away = m.awayId ? tm.get(m.awayId) ?? null : null;
  const [date, setDate] = useState(m.date ?? '');
  const [time, setTime] = useState(m.time ?? '');
  const [hs, setHs] = useState(m.homeScore == null ? '' : String(m.homeScore));
  const [as, setAs] = useState(m.awayScore == null ? '' : String(m.awayScore));
  const [hp, setHp] = useState(m.homePens == null ? '' : String(m.homePens));
  const [ap, setAp] = useState(m.awayPens == null ? '' : String(m.awayPens));
  const [sets, setSets] = useState<string[][]>(() => (m.sets?.length ? m.sets.map(([a, b]) => [String(a), String(b)]) : [['', ''], ['', ''], ...(c.setsToWin > 1 ? [] : [])]));
  const [events, setEvents] = useState<MatchEvent[]>(m.events);
  const [busy, setBusy] = useState<'' | 'sched' | 'save' | 'clear'>('');
  const [error, setError] = useState('');
  const ko = isKnockout(m);
  const tied = hs.trim() !== '' && as.trim() !== '' && hs === as;
  const ready = !!home && !!away;
  const susp = useMemo(() => computeSuspensions(c, v.teams.filter((t) => t.status === 'approved'), v.matches).suspended.filter((s) => s.matchId === m.id), [c, v, m.id]);
  const pname = (id: string) => v.players.find((p) => p.id === id)?.name ?? '';
  const canGoal = sp.scorers && c.stats.scorers;
  const canYellow = sp.cards && c.stats.yellow;
  const canRed = sp.cards && c.stats.red;
  const timed = sp.timed;

  const addEv = (type: MatchEvent['type']) => setEvents((e) => [...e, { id: randomId(), type, teamId: m.homeId!, playerId: null, assistPlayerId: null, minute: null }]);
  const updEv = (id: string, patch: Partial<MatchEvent>) => setEvents((e) => e.map((x) => (x.id === id ? { ...x, ...patch } : x)));
  const playersOf = (teamId: string) => v.players.filter((p) => p.teamId === teamId).sort((a, b) => (a.number ?? 999) - (b.number ?? 999));
  const label = (p: { id: string; name: string; number: number | null }) => `${p.number != null ? `${p.number} · ` : ''}${p.name}${susp.some((s) => s.playerId === p.id) ? ' (suspenso)' : ''}`;

  const saveSched = async () => {
    setBusy('sched');
    try { await api.updateSchedule(m.id, date || null, time || null); toast('Data e horário salvos.'); } catch (e) { fail(e); } finally { setBusy(''); }
  };
  const saveResult = async () => {
    setError(''); setBusy('save');
    try {
      await api.saveResult(m.id, {
        homeScore: toNum(hs), awayScore: toNum(as), homePens: tied ? toNum(hp) : null, awayPens: tied ? toNum(ap) : null,
        sets: sp.sets ? sets.filter((s) => s[0].trim() !== '' || s[1].trim() !== '').map((s) => [Number(s[0]), Number(s[1])] as [number, number]) : null,
        events: events.map((e) => ({ ...e, playerId: e.playerId || null, assistPlayerId: e.assistPlayerId || null })),
      });
      if (date !== (m.date ?? '') || time !== (m.time ?? '')) await api.updateSchedule(m.id, date || null, time || null);
      toast('Resultado salvo.'); onClose();
    } catch (e) { setError((e as Error).message); } finally { setBusy(''); }
  };
  const clear = async () => {
    if (!(await confirm({ title: 'Limpar resultado?', body: 'O placar e os eventos desta partida serão apagados.', confirmLabel: 'Limpar', danger: true }))) return;
    setBusy('clear');
    try { await api.clearResult(m.id); toast('Resultado removido.'); onClose(); } catch (e) { setError((e as Error).message); } finally { setBusy(''); }
  };

  const score = (id: string, val: string, set: (s: string) => void, lab: string) => (
    <input id={id} aria-label={lab} className="input score-in" inputMode="numeric" value={val} onChange={(e) => set(e.target.value.replace(/\D/g, '').slice(0, 3))} disabled={!ready} />
  );
  const teamSel = (e: MatchEvent) => (
    <select className="select" aria-label="Equipe" value={e.teamId} onChange={(x) => updEv(e.id, { teamId: x.target.value, playerId: null, assistPlayerId: null })}>
      <option value={m.homeId!}>{home?.name}</option><option value={m.awayId!}>{away?.name}</option>
    </select>
  );

  return (
    <Modal wide title={m.status === 'finished' ? 'Editar partida' : 'Registrar resultado'} onClose={onClose} footer={<>
      {m.status === 'finished' && <Button variant="danger-soft" loading={busy === 'clear'} onClick={clear} className="" icon="trash">Limpar</Button>}
      <span className="grow" />
      <Button variant="secondary" onClick={onClose}>Fechar</Button>
      <Button variant="primary" loading={busy === 'save'} disabled={!ready} onClick={saveResult}>Salvar resultado</Button></>}>
      <div className="stack lg">
        <div className="muted small">{m.phase === 'group' ? `Grupo ${m.group} · ` : ''}{m.roundLabel}{timed && c.periods > 0 ? ` · ${c.periods}×${c.periodMinutes} min` : ''}</div>
        {!ready && <Banner tone="warn" icon="clock">Esta partida espera o resultado da fase anterior para definir as equipes. Você já pode marcar data e horário.</Banner>}
        <div className="side-by">
          <div className="tm"><Shield team={home} size={48} /><span>{home?.name ?? 'A definir'}</span></div>
          <span className="muted bold">×</span>
          <div className="tm"><Shield team={away} size={48} /><span>{away?.name ?? 'A definir'}</span></div>
        </div>

        <div className="stack">
          <div className="grid g2">
            <Field label="Data" htmlFor="m-date"><input id="m-date" type="date" className="input" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
            <Field label="Horário" htmlFor="m-time"><input id="m-time" type="time" className="input" value={time} onChange={(e) => setTime(e.target.value)} /></Field>
          </div>
          <div><Button size="sm" variant="secondary" loading={busy === 'sched'} onClick={saveSched}>Salvar só data e horário</Button></div>
        </div>
        <hr className="divider" />

        {sp.sets ? (
          <div className="stack">
            <h3 style={{ fontSize: 17 }}>Placar dos sets</h3>
            {sets.map((s, i) => (
              <div key={i} className="row" style={{ gap: 10 }}>
                <span className="small muted" style={{ width: 54 }}>Set {i + 1}</span>
                <input className="input score-in" aria-label={`Set ${i + 1} ${home?.name ?? 'mandante'}`} inputMode="numeric" disabled={!ready} value={s[0]} onChange={(e) => setSets(sets.map((x, j) => (j === i ? [e.target.value.replace(/\D/g, ''), x[1]] : x)))} />
                <span className="muted">×</span>
                <input className="input score-in" aria-label={`Set ${i + 1} ${away?.name ?? 'visitante'}`} inputMode="numeric" disabled={!ready} value={s[1]} onChange={(e) => setSets(sets.map((x, j) => (j === i ? [x[0], e.target.value.replace(/\D/g, '')] : x)))} />
                <Button size="sm" variant="ghost" className="btn-icon" aria-label={`Remover set ${i + 1}`} onClick={() => setSets(sets.filter((_, j) => j !== i))}><Icon name="x" size={16} /></Button>
              </div>
            ))}
            {sets.length < c.setsToWin * 2 - 1 && <div><Button size="sm" variant="secondary" icon="plus" onClick={() => setSets([...sets, ['', '']])}>Adicionar set</Button></div>}
            <p className="hint">Set normal vai a {c.setPoints} pontos; o decisivo, a {c.tiebreakSetPoints}. Sempre com 2 de diferença.</p>
          </div>
        ) : (
          <div className="stack">
            <h3 style={{ fontSize: 17 }}>Placar ({sp.scoreUnit})</h3>
            <div className="row" style={{ justifyContent: 'center', gap: 16 }}>{score('m-hs', hs, setHs, `${sp.scoreUnit} de ${home?.name ?? 'mandante'}`)}<span className="muted bold">×</span>{score('m-as', as, setAs, `${sp.scoreUnit} de ${away?.name ?? 'visitante'}`)}</div>
            {tied && ko && sp.draws && (
              <Banner tone="warn" icon="flag"><div className="stack sm"><strong>Empate no mata-mata: informe o desempate ({sp.tiebreakLabel.toLowerCase()}).</strong>
                <div className="row" style={{ justifyContent: 'center', gap: 16 }}>{score('m-hp', hp, setHp, 'Desempate mandante')}<span className="muted bold">×</span>{score('m-ap', ap, setAp, 'Desempate visitante')}</div></div></Banner>
            )}
            {tied && ko && !sp.draws && <Banner tone="warn" icon="flag">{sp.label} não termina empatado. Informe o placar final com a prorrogação.</Banner>}
          </div>
        )}

        {(canGoal || canYellow || canRed) && (
          <div className="stack">
            <hr className="divider" />
            <div className="row between wrap"><h3 style={{ fontSize: 17 }}>Eventos da partida</h3>
              <div className="row wrap" style={{ gap: 6 }}>
                {canGoal && <Button size="sm" variant="secondary" icon="plus" disabled={!ready} onClick={() => addEv('goal')}>Gol</Button>}
                {canYellow && <Button size="sm" variant="secondary" icon="plus" disabled={!ready} onClick={() => addEv('yellow')}>Amarelo</Button>}
                {canRed && <Button size="sm" variant="secondary" icon="plus" disabled={!ready} onClick={() => addEv('red')}>Vermelho</Button>}
              </div></div>
            {c.stats.suspensions && susp.length > 0 && <Banner tone="warn" icon="ban">Suspensos nesta partida: {susp.map((s) => `${pname(s.playerId)} (${s.reason})`).join(', ')}.</Banner>}
            {events.length === 0 && <p className="hint">Opcional. Registre gols e cartões para alimentar a artilharia e as estatísticas.</p>}
            {events.map((e) => (
              <div key={e.id} className="stack sm" style={{ padding: 10, border: '1px solid var(--border)', borderRadius: 10 }}>
                <div className="row between"><Badge tone={e.type === 'goal' ? 'green' : e.type === 'yellow' ? 'orange' : 'red'}>{e.type === 'goal' ? 'Gol' : e.type === 'yellow' ? 'Cartão amarelo' : 'Cartão vermelho'}</Badge>
                  <Button size="sm" variant="ghost" className="btn-icon" aria-label="Remover evento" onClick={() => setEvents(events.filter((x) => x.id !== e.id))}><Icon name="trash" size={16} /></Button></div>
                <div className="grid g2" style={{ gap: 8 }}>
                  {teamSel(e)}
                  <select className="select" aria-label="Jogador" value={e.playerId ?? ''} onChange={(x) => updEv(e.id, { playerId: x.target.value || null })}>
                    <option value="">Jogador não informado</option>{playersOf(e.teamId).map((p) => <option key={p.id} value={p.id}>{label(p)}</option>)}
                  </select>
                  {e.type === 'goal' && c.stats.assists && sp.assists && (
                    <select className="select" aria-label="Assistência" value={e.assistPlayerId ?? ''} onChange={(x) => updEv(e.id, { assistPlayerId: x.target.value || null })}>
                      <option value="">Sem assistência</option>{playersOf(e.teamId).filter((p) => p.id !== e.playerId).map((p) => <option key={p.id} value={p.id}>{label(p)}</option>)}
                    </select>
                  )}
                  {timed && <input className="input" aria-label="Minuto" inputMode="numeric" placeholder="Minuto (opcional)" value={e.minute ?? ''} onChange={(x) => updEv(e.id, { minute: x.target.value === '' ? null : Number(x.target.value.replace(/\D/g, '')) })} />}
                </div>
              </div>
            ))}
          </div>
        )}
        {error && <Banner tone="bad" icon="alert">{error}</Banner>}
      </div>
    </Modal>
  );
}

function ScheduleModal({ v, onClose }: { v: ChampionshipView; onClose: () => void }) {
  const api = useApi();
  const { toast, fail } = useUi();
  const c = v.champ;
  const [f, setF] = useState({ startDate: c.startDate >= todayISO() ? c.startDate : addDays(todayISO(), 1), startTime: '19:00', intervalMinutes: Math.max(30, c.periods * c.periodMinutes + 15) || 60, perDay: 4, onlyUnscheduled: true });
  const [busy, setBusy] = useState(false);
  return (
    <Modal title="Calendário automático" onClose={onClose} footer={<><Button variant="secondary" onClick={onClose}>Cancelar</Button>
      <Button variant="primary" loading={busy} onClick={async () => { setBusy(true); try { const n = await api.autoSchedule(c.id, f); toast(`${n} partidas agendadas.`); onClose(); } catch (e) { fail(e); } finally { setBusy(false); } }}>Agendar</Button></>}>
      <div className="stack">
        <p className="muted small">Distribui data e horário em sequência, na ordem das rodadas. Partidas encerradas não mudam. Depois você ajusta qualquer jogo individualmente.</p>
        <div className="grid g2">
          <Field label="Primeiro dia" htmlFor="s-d"><input id="s-d" type="date" className="input" value={f.startDate} onChange={(e) => setF({ ...f, startDate: e.target.value })} /></Field>
          <Field label="Primeiro horário" htmlFor="s-t"><input id="s-t" type="time" className="input" value={f.startTime} onChange={(e) => setF({ ...f, startTime: e.target.value })} /></Field>
          <Field label="Intervalo entre jogos (min)" htmlFor="s-i"><input id="s-i" type="number" className="input num" value={f.intervalMinutes} onChange={(e) => setF({ ...f, intervalMinutes: Number(e.target.value) })} /></Field>
          <Field label="Jogos por dia" htmlFor="s-p"><input id="s-p" type="number" className="input num" value={f.perDay} onChange={(e) => setF({ ...f, perDay: Number(e.target.value) })} /></Field>
        </div>
        <label className="check"><input type="checkbox" checked={f.onlyUnscheduled} onChange={(e) => setF({ ...f, onlyUnscheduled: e.target.checked })} /><span>Manter datas já definidas (agendar só jogos sem data)</span></label>
      </div>
    </Modal>
  );
}

function DrawPanel({ v }: { v: ChampionshipView }) {
  const api = useApi();
  const { toast, fail, confirm } = useUi();
  const [busy, setBusy] = useState(false);
  const c = v.champ;
  const approved = v.teams.filter((t) => t.status === 'approved').length;
  const need = Math.max(2, c.minTeams);
  const fc = checkFormat(c, approved);
  const enough = approved >= need;
  const preview = !enough ? null : c.format === 'league' ? `${(approved * (approved - 1)) / 2 * c.legs} partidas em ${(approved % 2 ? approved : approved - 1) * c.legs} rodadas`
    : c.format === 'knockout' ? `${approved - 1 + (c.thirdPlace && approved >= 4 ? 1 : 0)} partidas eliminatórias${(approved & (approved - 1)) ? `; ${Math.pow(2, Math.ceil(Math.log2(approved))) - approved} equipes avançam direto` : ''}`
      : fc.ok ? `${c.groupCount} grupos com ${groupSizes(approved, c.groupCount).join(', ')} equipes` : null;
  const go = async () => {
    if (!(await confirm({ title: 'Sortear agora?', body: `As ${approved} equipes aprovadas serão sorteadas e as inscrições se encerram. Você ainda pode refazer o sorteio depois, mas isso apaga as partidas.`, confirmLabel: 'Sortear e gerar partidas' }))) return;
    setBusy(true);
    try { await api.runDraw(c.id); toast('Sorteio feito. Partidas geradas.'); } catch (e) { fail(e); } finally { setBusy(false); }
  };
  return (
    <section className="card pad-lg stack lg">
      <div className="row top" style={{ gap: 14 }}>
        <span className="badge b-orange" style={{ padding: 12 }}><Icon name="shuffle" size={26} /></span>
        <div className="stack sm"><h2 style={{ fontSize: 20 }}>Sorteio e geração de partidas</h2>
          <p className="muted small">Formato: {FORMAT_LABEL[c.format]}. O sorteio é aleatório e feito aqui no navegador; ninguém, nem o organizador, escolhe os confrontos.</p></div>
      </div>
      <div className="grid g3">
        <div className="stack sm"><span className="muted small bold">Equipes aprovadas</span><span className="tile v num" style={{ padding: 0 }}>{approved}</span><span className="hint">mínimo para sortear: {need}</span></div>
        <div className="stack sm" style={{ gridColumn: 'span 2' }}><span className="muted small bold">O que será criado</span><span>{preview ?? '—'}</span></div>
      </div>
      {!enough && <Banner tone="warn" icon="users">Faltam {need - approved} equipes aprovadas. Aprove solicitações ou cadastre equipes na aba Equipes.</Banner>}
      {enough && !fc.ok && (
        <Banner tone="bad" icon="alert"><div className="stack sm"><strong>O formato escolhido não funciona com {approved} equipes.</strong>
          <ul style={{ margin: 0, paddingLeft: 18 }}>{fc.problems.map((p) => <li key={p}>{p}</li>)}</ul>
          <div className="row wrap"><span className="small">Alternativas:</span>{fc.suggestions.map((s) => <Button key={s.label} size="sm" variant="secondary" onClick={async () => { try { await api.updateChampionship(c.id, s.patch); toast('Configuração ajustada.'); } catch (e) { fail(e); } }}>{s.label}</Button>)}</div></div></Banner>
      )}
      <div><Button variant="primary" icon="shuffle" loading={busy} disabled={!enough || !fc.ok} onClick={go}>Sortear e gerar partidas</Button></div>
    </section>
  );
}

export function Matches({ v }: { v: ChampionshipView }) {
  const api = useApi();
  const { toast, fail, confirm } = useUi();
  const c = v.champ;
  const [mode, setMode] = useState<'lista' | 'chave'>('lista');
  const [phase, setPhase] = useState<'todas' | 'pontos' | 'mata'>('todas');
  const [group, setGroup] = useState('todos');
  const [status, setStatus] = useState<'todas' | 'scheduled' | 'finished'>('todas');
  const [openId, setOpenId] = useState<string | null>(null);
  const [sched, setSched] = useState(false);
  const approved = v.teams.filter((t) => t.status === 'approved');

  const filtered = useMemo(() => v.matches.filter((m) =>
    (phase === 'todas' || (phase === 'mata' ? isKnockout(m) : !isKnockout(m))) &&
    (group === 'todos' || m.group === group) && (status === 'todas' || m.status === status)), [v.matches, phase, group, status]);

  if (v.matches.length === 0) return <DrawPanel v={v} />;
  const hasKo = v.matches.some(isKnockout);
  const groups = [...new Set(v.matches.map((m) => m.group).filter(Boolean))] as string[];
  const open = openId ? v.matches.find((m) => m.id === openId) : null;
  const finished = v.matches.filter((m) => m.status === 'finished').length;
  const canKo = c.format === 'groups_knockout' && !c.knockoutGenerated;
  const run = async (fn: () => Promise<unknown>, msg: string) => { try { await fn(); toast(msg); } catch (e) { fail(e); } };

  return (
    <div className="stack lg">
      <div className="row between wrap">
        <p className="muted small num">{finished} de {v.matches.length} partidas encerradas</p>
        <div className="row wrap">
          <Button size="sm" variant="secondary" icon="calendar" onClick={() => setSched(true)}>Calendário automático</Button>
          {canKo && <Button size="sm" variant="primary" icon="trophy" disabled={!groupStageComplete(v.matches)} title={groupStageComplete(v.matches) ? '' : 'Termine os jogos dos grupos primeiro'} onClick={() => run(() => api.generateKnockout(c.id), 'Eliminatórias geradas.')}>Gerar eliminatórias</Button>}
          {c.format === 'groups_knockout' && c.knockoutGenerated && !v.matches.filter(isKnockout).some((m) => m.status === 'finished') && <Button size="sm" variant="secondary" onClick={async () => { if (await confirm({ title: 'Apagar eliminatórias?', body: 'O chaveamento será removido. Você poderá gerá-lo de novo.', confirmLabel: 'Apagar', danger: true })) run(() => api.resetKnockout(c.id), 'Eliminatórias apagadas.'); }}>Apagar eliminatórias</Button>}
          <Button size="sm" variant="danger-soft" icon="shuffle" onClick={async () => {
            if (await confirm({ title: 'Refazer o sorteio?', body: 'Todas as partidas e resultados serão apagados. As equipes aprovadas continuam e você poderá sortear de novo, ou mudar o formato.', confirmLabel: 'Apagar partidas e refazer', danger: true })) { await run(() => api.resetDraw(c.id), 'Sorteio desfeito.'); }
          }}>Refazer sorteio</Button>
        </div>
      </div>
      {canKo && !groupStageComplete(v.matches) && <Banner icon="info">Quando todas as partidas dos grupos terminarem, o botão “Gerar eliminatórias” leva os {c.groupCount * c.qualifiersPerGroup} classificados ao mata-mata.</Banner>}

      <div className="row wrap" style={{ gap: 12 }}>
        {hasKo && <div className="seg" role="group" aria-label="Visualização"><button className={mode === 'lista' ? 'on' : ''} onClick={() => setMode('lista')}>Lista</button><button className={mode === 'chave' ? 'on' : ''} onClick={() => setMode('chave')}>Chaveamento</button></div>}
        {mode === 'lista' && <>
          {hasKo && c.format === 'groups_knockout' && <div className="seg" role="group" aria-label="Fase"><button className={phase === 'todas' ? 'on' : ''} onClick={() => setPhase('todas')}>Todas</button><button className={phase === 'pontos' ? 'on' : ''} onClick={() => setPhase('pontos')}>Grupos</button><button className={phase === 'mata' ? 'on' : ''} onClick={() => setPhase('mata')}>Eliminatórias</button></div>}
          {groups.length > 1 && <select className="select" style={{ width: 'auto' }} aria-label="Grupo" value={group} onChange={(e) => setGroup(e.target.value)}><option value="todos">Todos os grupos</option>{groups.map((g) => <option key={g} value={g}>Grupo {g}</option>)}</select>}
          <div className="seg" role="group" aria-label="Situação"><button className={status === 'todas' ? 'on' : ''} onClick={() => setStatus('todas')}>Todas</button><button className={status === 'scheduled' ? 'on' : ''} onClick={() => setStatus('scheduled')}>Agendadas</button><button className={status === 'finished' ? 'on' : ''} onClick={() => setStatus('finished')}>Encerradas</button></div>
        </>}
      </div>

      {mode === 'chave' ? <BracketView matches={v.matches} teams={approved} onOpen={(m) => setOpenId(m.id)} />
        : <MatchList matches={filtered} teams={approved} champ={c} onOpen={(m) => setOpenId(m.id)} />}
      {open && <MatchModal key={open.id} m={open} v={v} onClose={() => setOpenId(null)} />}
      {sched && <ScheduleModal v={v} onClose={() => setSched(false)} />}
    </div>
  );
}
