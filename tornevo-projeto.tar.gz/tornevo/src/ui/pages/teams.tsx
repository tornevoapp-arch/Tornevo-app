import { useState } from 'react';
import type { Player, Team } from '../../types';
import { Badge, Banner, Button, Empty, Field, Modal, Shield, useApi, useUi } from '../kit';
import { Icon } from '../icons';
import { TeamForm } from '../views';
import { fileToShield } from '../image';
import type { ChampionshipView } from '../../services/api';
import { DomainError } from '../../services/api';

function PlayerRow({ p, onSave, onDelete }: { p: Player; onSave: (d: { id: string; name: string; number: string; position: string }) => Promise<void>; onDelete: () => void }) {
  const [edit, setEdit] = useState(false);
  const [f, setF] = useState({ name: p.name, number: p.number == null ? '' : String(p.number), position: p.position });
  const [err, setErr] = useState('');
  if (!edit) return (
    <div className="player-row">
      <span className="num-badge">{p.number ?? '–'}</span>
      <div style={{ minWidth: 0 }}><div className="bold trunc">{p.name}</div><div className="xs muted">{p.position || 'Sem posição'}</div></div>
      <div className="row" style={{ gap: 2 }}>
        <Button size="sm" variant="ghost" className="btn-icon" aria-label={`Editar ${p.name}`} onClick={() => setEdit(true)}><Icon name="edit" size={16} /></Button>
        <Button size="sm" variant="ghost" className="btn-icon" aria-label={`Remover ${p.name}`} onClick={onDelete}><Icon name="trash" size={16} /></Button>
      </div>
    </div>
  );
  return (
    <form className="stack sm" style={{ padding: '8px 0' }} onSubmit={async (e) => { e.preventDefault(); try { await onSave({ id: p.id, ...f }); setEdit(false); } catch (x) { setErr((x as Error).message); } }}>
      <div className="row top" style={{ gap: 8 }}>
        <input className="input" style={{ flex: 3 }} aria-label="Nome" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <input className="input" style={{ width: 72 }} aria-label="Número" inputMode="numeric" value={f.number} onChange={(e) => setF({ ...f, number: e.target.value.replace(/\D/g, '') })} />
        <input className="input" style={{ flex: 2 }} aria-label="Posição" value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })} />
      </div>
      {err && <span className="err-text">{err}</span>}
      <div className="row"><Button size="sm" type="submit" variant="primary">Salvar</Button><Button size="sm" variant="ghost" onClick={() => setEdit(false)}>Cancelar</Button></div>
    </form>
  );
}

function TeamCard({ t, v, players }: { t: Team; v: ChampionshipView; players: Player[] }) {
  const api = useApi();
  const { toast, fail, confirm } = useUi();
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState(false);
  const [np, setNp] = useState<{ name: string; number: string; position: string } | null>(null);
  const [npErr, setNpErr] = useState('');
  const c = v.champ;
  const act = async (fn: () => Promise<unknown>, msg: string) => { try { await fn(); toast(msg); } catch (e) { fail(e); } };
  const short = c.minPlayers != null && players.length < c.minPlayers;
  return (
    <article className="card">
      <div className="pad row top wrap" style={{ gap: 14 }}>
        <Shield team={t} size={48} />
        <div className="grow stack" style={{ gap: 4 }}>
          <div className="row wrap" style={{ gap: 8 }}><h3 style={{ fontSize: 18 }}>{t.name}</h3>
            {t.group && <Badge tone="orange">Grupo {t.group}</Badge>}
            {t.source === 'public' && <Badge tone="blue">Pelo link</Badge>}
            {short && <Badge tone="red">Elenco abaixo do mínimo</Badge>}</div>
          <p className="small muted">Responsável: {t.manager}{t.city ? ` · ${t.city}` : ''}</p>
          <p className="small muted trunc">{[t.email, t.phone].filter(Boolean).join(' · ') || 'Sem contato'}</p>
        </div>
        <div className="row wrap" style={{ gap: 6 }}>
          {t.status === 'pending' && <>
            <Button size="sm" variant="primary" icon="check" onClick={() => act(() => api.approveTeam(t.id), `${t.name} aprovada.`)}>Aprovar</Button>
            <Button size="sm" variant="secondary" icon="x" onClick={() => act(() => api.rejectTeam(t.id), `${t.name} recusada.`)}>Recusar</Button>
          </>}
          {t.status === 'rejected' && <Button size="sm" variant="secondary" icon="refresh" onClick={() => act(() => api.restoreTeam(t.id), 'Voltou para pendentes.')}>Reavaliar</Button>}
          <Button size="sm" variant="ghost" icon="edit" onClick={() => setEdit(true)}>Editar</Button>
          <Button size="sm" variant="ghost" icon={open ? 'up' : 'users'} onClick={() => setOpen(!open)} aria-expanded={open}>{players.length} jogador{players.length === 1 ? '' : 'es'}</Button>
          <Button size="sm" variant="ghost" className="btn-icon" aria-label={`Excluir ${t.name}`} onClick={async () => {
            if (await confirm({ title: `Excluir ${t.name}?`, body: 'A equipe e seus jogadores serão removidos.', confirmLabel: 'Excluir', danger: true })) act(() => api.deleteTeam(t.id), 'Equipe excluída.');
          }}><Icon name="trash" size={16} /></Button>
        </div>
      </div>
      {open && (
        <div style={{ borderTop: '1px solid var(--border)', padding: '6px 18px 16px' }}>
          <div className="list">{players.map((p) => (
            <PlayerRow key={p.id} p={p} onSave={async (d) => { try { await api.savePlayer(t.id, d); } catch (e) { throw e instanceof DomainError && e.fields ? new Error(Object.values(e.fields)[0]) : e; } }}
              onDelete={() => act(() => api.deletePlayer(p.id), 'Jogador removido.')} />
          ))}</div>
          {players.length === 0 && <p className="small muted" style={{ padding: '10px 0' }}>Nenhum jogador cadastrado.</p>}
          {np ? (
            <form className="stack sm" style={{ paddingTop: 10 }} onSubmit={async (e) => { e.preventDefault(); try { await api.savePlayer(t.id, np); setNp(null); setNpErr(''); toast('Jogador adicionado.'); } catch (x) { setNpErr(x instanceof DomainError && x.fields ? Object.values(x.fields)[0] : (x as Error).message); } }}>
              <div className="row top" style={{ gap: 8 }}>
                <input className="input" style={{ flex: 3 }} placeholder="Nome" aria-label="Nome do novo jogador" autoFocus value={np.name} onChange={(e) => setNp({ ...np, name: e.target.value })} />
                <input className="input" style={{ width: 72 }} placeholder="Nº" aria-label="Número" inputMode="numeric" value={np.number} onChange={(e) => setNp({ ...np, number: e.target.value.replace(/\D/g, '') })} />
                <input className="input" style={{ flex: 2 }} placeholder="Posição" aria-label="Posição" value={np.position} onChange={(e) => setNp({ ...np, position: e.target.value })} />
              </div>
              {npErr && <span className="err-text">{npErr}</span>}
              <div className="row"><Button size="sm" type="submit" variant="primary">Adicionar</Button><Button size="sm" variant="ghost" onClick={() => { setNp(null); setNpErr(''); }}>Cancelar</Button></div>
            </form>
          ) : <div style={{ paddingTop: 10 }}><Button size="sm" variant="secondary" icon="plus" onClick={() => setNp({ name: '', number: '', position: '' })}>Adicionar jogador</Button></div>}
        </div>
      )}
      {edit && <EditTeam t={t} onClose={() => setEdit(false)} />}
    </article>
  );
}

function EditTeam({ t, onClose }: { t: Team; onClose: () => void }) {
  const api = useApi();
  const { toast, fail } = useUi();
  const [f, setF] = useState({ name: t.name, manager: t.manager, email: t.email, phone: t.phone, city: t.city, shield: t.shield });
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const inp = (k: 'name' | 'manager' | 'email' | 'phone' | 'city', label: string) => (
    <Field label={label} error={errs[k]} htmlFor={`et-${k}`}><input id={`et-${k}`} className={`input${errs[k] ? ' err' : ''}`} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></Field>
  );
  return (
    <Modal title="Editar equipe" onClose={onClose} footer={<>
      <Button variant="secondary" onClick={onClose}>Cancelar</Button>
      <Button variant="primary" loading={busy} onClick={async () => {
        setBusy(true);
        try { await api.updateTeam(t.id, f); toast('Equipe atualizada.'); onClose(); } catch (e) { if (e instanceof DomainError && e.fields) setErrs(e.fields); fail(e); } finally { setBusy(false); }
      }}>Salvar</Button></>}>
      <div className="stack">
        <div className="row"><Shield team={{ name: f.name, shield: f.shield }} size={56} />
          <label className="btn btn-secondary btn-sm" htmlFor="et-shield"><Icon name="upload" size={16} /> Trocar escudo</label>
          <input id="et-shield" className="sr" type="file" accept="image/png,image/jpeg,image/webp" onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; try { setF({ ...f, shield: await fileToShield(file) }); } catch (x) { fail(x); } }} />
          {f.shield && <Button size="sm" variant="ghost" onClick={() => setF({ ...f, shield: null })}>Remover</Button>}</div>
        {inp('name', 'Nome da equipe')}{inp('manager', 'Responsável')}{inp('email', 'E-mail')}{inp('phone', 'Telefone')}{inp('city', 'Cidade')}
      </div>
    </Modal>
  );
}

export function Teams({ v }: { v: ChampionshipView }) {
  const api = useApi();
  const { toast } = useUi();
  const [tab, setTab] = useState<'pending' | 'approved' | 'rejected'>(v.teams.some((t) => t.status === 'pending') ? 'pending' : 'approved');
  const [adding, setAdding] = useState(false);
  const c = v.champ;
  const by = (s: Team['status']) => v.teams.filter((t) => t.status === s);
  const list = by(tab);
  const approved = by('approved').length;
  const labels: Record<typeof tab, string> = { pending: 'Pendentes', approved: 'Aprovadas', rejected: 'Recusadas' };
  return (
    <div className="stack lg">
      <div className="row between wrap">
        <div className="seg" role="tablist" aria-label="Status das equipes">
          {(['pending', 'approved', 'rejected'] as const).map((s) => <button key={s} role="tab" aria-selected={tab === s} className={tab === s ? 'on' : ''} onClick={() => setTab(s)}>{labels[s]} <span className="num">({by(s).length}{s === 'approved' ? `/${c.maxTeams}` : ''})</span></button>)}
        </div>
        <Button variant="primary" icon="plus" disabled={c.drawDone || approved >= c.maxTeams} onClick={() => setAdding(true)}>Cadastrar equipe</Button>
      </div>
      {c.drawDone && <Banner tone="warn" icon="lock">O sorteio já foi feito, então não dá para aprovar nem cadastrar novas equipes. Refaça o sorteio em Partidas se precisar.</Banner>}
      {!c.drawDone && approved >= c.maxTeams && <Banner tone="warn" icon="alert">O limite de {c.maxTeams} equipes foi atingido. Novas solicitações ficam pendentes até abrir uma vaga.</Banner>}
      {list.length === 0
        ? <div className="card"><Empty icon="users" title={tab === 'pending' ? 'Nenhuma solicitação pendente' : tab === 'approved' ? 'Nenhuma equipe aprovada' : 'Nenhuma equipe recusada'}>
          {tab === 'pending' ? 'Quando uma equipe se inscrever pelo link, ela aparece aqui para você aprovar.' : tab === 'approved' ? 'Aprove solicitações ou cadastre equipes diretamente.' : 'Equipes recusadas ficam guardadas aqui.'}</Empty></div>
        : <div className="stack">{list.map((t) => <TeamCard key={t.id} t={t} v={v} players={v.players.filter((p) => p.teamId === t.id)} />)}</div>}
      {adding && (
        <Modal wide title="Cadastrar equipe" onClose={() => setAdding(false)}>
          <TeamForm champ={c} submitLabel="Cadastrar e aprovar" hideContactNote onCancel={() => setAdding(false)} onSubmit={async (d) => { await api.addTeam(c.id, d); toast('Equipe cadastrada e aprovada.'); setAdding(false); setTab('approved'); }} />
        </Modal>
      )}
    </div>
  );
}
