import type { ReactNode } from 'react';
import { Link, useRouter } from '../router';
import { Badge, Banner, Button, CopyField, Loading, Progress, useApi, useQuery, useUi, Empty, Shield } from '../kit';
import { Icon } from '../icons';
import { StatusBadge, teamMap } from '../views';
import { ChampForm } from '../ChampForm';
import { fmtDate, fmtDateRange } from '../../domain/format';
import { SPORTS, sportName } from '../../domain/sports';
import { FORMAT_LABEL } from '../../domain/validation';
import { plannedUrl } from '../../config';
import { registrationState } from '../../domain/registration';
import { groupStageComplete, podium } from '../../domain/tournament';
import { todayISO } from '../../domain/format';
import type { ChampionshipView } from '../../services/api';

export function ChampLayout({ id, tab, children }: { id: string; tab: string; children: (v: ChampionshipView) => ReactNode }) {
  const q = useQuery((a) => a.getView(id), [id]);
  const { navigate } = useRouter();
  if (q.loading && !q.data) return <div className="page"><Loading /></div>;
  const v = q.data;
  if (!v) return <div className="page"><div className="card"><Empty icon="search" title="Campeonato não encontrado" action={<Button variant="primary" onClick={() => navigate('/painel/campeonatos')}>Ver campeonatos</Button>}>Ele pode ter sido excluído.</Empty></div></div>;
  const c = v.champ;
  const pending = v.teams.filter((t) => t.status === 'pending').length;
  const tabs: Array<[string, string, string?]> = [
    ['', 'Visão geral'], ['equipes', 'Equipes', pending ? String(pending) : undefined], ['partidas', 'Partidas'],
    ['classificacao', 'Classificação'], ['estatisticas', 'Estatísticas'], ['configuracoes', 'Configurações'],
  ];
  return (
    <div className="page">
      <div className="stack sm">
        <Link to="/painel/campeonatos" className="small muted row" style={{ textDecoration: 'none', gap: 6 }}><Icon name="back" size={16} /> Campeonatos</Link>
        <div className="row between wrap top">
          <div className="stack sm" style={{ minWidth: 0 }}>
            <div className="row wrap" style={{ gap: 6 }}><StatusBadge status={c.status} />{c.isDemo && <Badge>Exemplo</Badge>}</div>
            <h1 className="page-title">{c.name}</h1>
            <p className="muted small num">{sportName(c)} · {c.category}{c.city ? ` · ${c.city}` : ''} · {fmtDateRange(c.startDate, c.endDate)}</p>
          </div>
          <Button variant="secondary" icon="eye" onClick={() => navigate(`/torneio/${c.publicCode}`)}>Ver página pública</Button>
        </div>
      </div>
      <nav className="tabs" aria-label="Seções do campeonato">
        {tabs.map(([slug, label, badge]) => (
          <Link key={slug} to={`/painel/campeonatos/${id}${slug ? `/${slug}` : ''}`} className={`tab${tab === slug ? ' active' : ''}`} aria-current={tab === slug ? 'page' : undefined}>
            {label}{badge && <span className="badge b-orange num">{badge}</span>}
          </Link>
        ))}
      </nav>
      {children(v)}
    </div>
  );
}

export function LinksPanel({ v }: { v: ChampionshipView }) {
  const api = useApi();
  const { navigate } = useRouter();
  const { confirm, toast, fail } = useUi();
  const c = v.champ;
  const approved = v.teams.filter((t) => t.status === 'approved').length;
  const st = registrationState(c, approved, todayISO());
  const run = async (fn: () => Promise<unknown>, msg: string) => { try { await fn(); toast(msg); } catch (e) { fail(e); } };
  return (
    <section className="card pad-lg stack">
      <div><h2 style={{ fontSize: 20 }}>Links públicos</h2>
        <p className="muted small">Links previstos para {plannedUrl('torneio', '').replace(/\/torneio\/$/, '')}. Nesta demonstração eles ainda não estão publicados: os botões “Abrir” mostram a página equivalente aqui, e só neste navegador.</p></div>
      <div className="grid g2">
        <div className="stack">
          <div className="row between wrap"><strong>Acompanhar o campeonato</strong><Badge tone="green">Aberto ao público</Badge></div>
          <CopyField value={plannedUrl('torneio', c.publicCode)} label="link do campeonato" />
          <div className="row wrap">
            <Button size="sm" variant="primary" icon="eye" onClick={() => navigate(`/torneio/${c.publicCode}`)}>Abrir página</Button>
            <Button size="sm" variant="secondary" icon="refresh" onClick={async () => {
              if (await confirm({ title: 'Gerar novo link do campeonato?', body: 'O link atual deixa de funcionar para quem já o recebeu. Faça isso só se precisar mesmo.', confirmLabel: 'Gerar novo link', danger: true })) await run(() => api.regenerateCode(c.id, 'publicCode'), 'Novo link do campeonato gerado.');
            }}>Gerar novo</Button>
          </div>
        </div>
        <div className="stack">
          <div className="row between wrap"><strong>Inscrição de equipes</strong>
            {st.open ? <Badge tone="green" dot>Recebendo inscrições</Badge> : <Badge tone="red" dot>Fechado</Badge>}</div>
          <CopyField value={plannedUrl('inscricao', c.regCode)} label="link de inscrição" />
          {!st.open && <p className="small muted">{st.reason}</p>}
          <div className="row wrap">
            <Button size="sm" variant="primary" icon="eye" onClick={() => navigate(`/inscricao/${c.regCode}`)}>Abrir formulário</Button>
            <Button size="sm" variant="secondary" icon="ban" onClick={() => run(() => api.setRegLinkActive(c.id, !c.regLinkActive), c.regLinkActive ? 'Link de inscrição desativado.' : 'Link de inscrição reativado.')}>{c.regLinkActive ? 'Desativar' : 'Reativar'}</Button>
            <Button size="sm" variant="secondary" icon="refresh" onClick={async () => {
              if (await confirm({ title: 'Gerar novo link de inscrição?', body: 'O link anterior para de funcionar imediatamente.', confirmLabel: 'Gerar novo link', danger: true })) await run(() => api.regenerateCode(c.id, 'regCode'), 'Novo link de inscrição gerado.');
            }}>Gerar novo</Button>
          </div>
        </div>
      </div>
      <p className="hint">Códigos de demonstração gerados neste navegador. Em produção, o servidor gera e valida os códigos. Compartilhar por WhatsApp entra junto com a publicação.</p>
    </section>
  );
}

export function Overview({ v }: { v: ChampionshipView }) {
  const api = useApi();
  const { navigate } = useRouter();
  const { toast, fail } = useUi();
  const c = v.champ;
  const sp = SPORTS[c.sport];
  const approved = v.teams.filter((t) => t.status === 'approved');
  const pending = v.teams.filter((t) => t.status === 'pending');
  const finished = v.matches.filter((m) => m.status === 'finished').length;
  const pod = podium(c, approved, v.matches);
  const tm = teamMap(v.teams);
  const to = (s: string) => navigate(`/painel/campeonatos/${c.id}/${s}`);

  let step: { title: string; text: string; action: ReactNode } | null = null;
  if (c.status === 'preparacao') step = { title: 'Abra as inscrições', text: 'O link de inscrição só funciona depois disso.', action: <Button variant="primary" onClick={async () => { try { await api.setStatus(c.id, 'inscricoes'); toast('Inscrições abertas.'); } catch (e) { fail(e); } }}>Abrir inscrições</Button> };
  else if (!c.drawDone && pending.length > 0) step = { title: `${pending.length} solicitaç${pending.length > 1 ? 'ões' : 'ão'} para analisar`, text: 'Aprove ou recuse as equipes que pediram vaga.', action: <Button variant="primary" onClick={() => to('equipes')}>Analisar equipes</Button> };
  else if (!c.drawDone && approved.length >= Math.max(2, c.minTeams)) step = { title: 'Pronto para sortear', text: `${approved.length} equipes aprovadas. O sorteio gera grupos e partidas.`, action: <Button variant="primary" icon="shuffle" onClick={() => to('partidas')}>Ir para o sorteio</Button> };
  else if (!c.drawDone) step = { title: 'Receba e aprove equipes', text: `Faltam ${Math.max(0, Math.max(2, c.minTeams) - approved.length)} equipes aprovadas para poder sortear. Compartilhe o link de inscrição ou cadastre equipes você mesmo.`, action: <Button variant="primary" onClick={() => to('equipes')}>Gerenciar equipes</Button> };
  else if (c.format === 'groups_knockout' && !c.knockoutGenerated && groupStageComplete(v.matches)) step = { title: 'Fase de grupos concluída', text: 'Gere as eliminatórias com os classificados.', action: <Button variant="primary" onClick={() => to('partidas')}>Gerar eliminatórias</Button> };
  else if (c.status === 'andamento') step = { title: 'Registre os resultados', text: `${finished} de ${v.matches.length} partidas encerradas.`, action: <Button variant="primary" onClick={() => to('partidas')}>Ver partidas</Button> };

  return (
    <div className="stack lg">
      {pod && c.status === 'encerrado' && (
        <section className="card pad-lg hero-box"><div className="row wrap" style={{ gap: 20 }}>
          <Icon name="trophy" size={40} className="" />
          <div className="stack sm"><span className="eyebrow">Campeonato encerrado</span>
            <div className="row wrap" style={{ gap: 18 }}>
              {([['Campeão', pod.first], ['Vice', pod.second], ['3º lugar', pod.third]] as const).filter(([, id]) => id).map(([l, id]) => (
                <div key={l} className="row"><Shield team={tm.get(id!) ?? null} size={34} /><div><div className="xs muted">{l}</div><div className="bold">{tm.get(id!)?.name}</div></div></div>
              ))}
            </div></div></div></section>
      )}
      {step && (
        <section className="card pad-lg row between wrap" style={{ borderColor: 'var(--accent)' }}>
          <div className="stack sm"><span className="eyebrow" style={{ color: 'var(--accent-text)' }}>Próximo passo</span><h2 style={{ fontSize: 20 }}>{step.title}</h2><p className="muted small">{step.text}</p></div>
          {step.action}
        </section>
      )}
      <div className="grid g3">
        <div className="card pad stack sm"><span className="muted small bold">Equipes aprovadas</span><div className="row between"><span className="tile v num" style={{ padding: 0 }}>{approved.length}<small className="muted" style={{ fontSize: 16 }}> / {c.maxTeams}</small></span></div><Progress value={approved.length} max={c.maxTeams} /></div>
        <div className="card pad stack sm"><span className="muted small bold">Solicitações pendentes</span><span className="tile v num" style={{ padding: 0 }}>{pending.length}</span><span className="hint">{v.teams.filter((t) => t.status === 'rejected').length} recusadas</span></div>
        <div className="card pad stack sm"><span className="muted small bold">Partidas encerradas</span><span className="tile v num" style={{ padding: 0 }}>{finished}<small className="muted" style={{ fontSize: 16 }}> / {v.matches.length}</small></span><Progress value={finished} max={v.matches.length} /></div>
      </div>
      <LinksPanel v={v} />
      <section className="card pad-lg stack">
        <div className="row between wrap"><h2 style={{ fontSize: 20 }}>Regras do campeonato</h2><Button size="sm" variant="secondary" icon="edit" onClick={() => to('configuracoes')}>Editar</Button></div>
        <dl className="kv">
          <dt>Formato</dt><dd>{FORMAT_LABEL[c.format]}{c.format.startsWith('groups') ? ` · ${c.groupCount} grupos` : ''}{c.format === 'groups_knockout' ? ` · ${c.qualifiersPerGroup} avançam por grupo` : ''}</dd>
          <dt>Partida</dt><dd>{sp.sets ? `Melhor de ${c.setsToWin * 2 - 1} sets de ${c.setPoints} pontos` : sp.timed ? `${c.periods} × ${c.periodMinutes} min` : `Placar em ${sp.scoreUnit}`}</dd>
          <dt>Inscrições</dt><dd>{fmtDate(c.regOpenDate)}{c.regCloseDate ? ` a ${fmtDate(c.regCloseDate)}` : ''}</dd>
          <dt>Estatísticas</dt><dd className="row wrap" style={{ gap: 6 }}>
            {[['Amarelos', c.stats.yellow && sp.cards], ['Vermelhos', c.stats.red && sp.cards], ['Artilharia', c.stats.scorers && sp.scorers], ['Assistências', c.stats.assists && sp.assists], ['Suspensões', c.stats.suspensions && sp.cards]].map(([l, on]) => <Badge key={l as string} tone={on ? 'green' : undefined}>{l as string}: {on ? 'sim' : 'não'}</Badge>)}
          </dd>
        </dl>
      </section>
    </div>
  );
}

export function Settings({ v }: { v: ChampionshipView }) {
  const api = useApi();
  const { navigate } = useRouter();
  const { confirm, toast, fail } = useUi();
  const c = v.champ;
  return (
    <div className="stack lg">
      <ChampForm key={c.updatedAt} mode="edit" initial={c} locked={c.drawDone} approvedCount={v.teams.filter((t) => t.status === 'approved').length}
        onSave={async (d) => { await api.updateChampionship(c.id, d); toast('Alterações salvas.'); }} />
      {!c.drawDone && (
        <section className="card pad-lg row between wrap">
          <div><h3 style={{ fontSize: 17 }}>Inscrições</h3><p className="small muted">{c.status === 'inscricoes' ? 'Abertas: o link de inscrição está recebendo equipes.' : 'Em preparação: o link ainda não recebe inscrições.'}</p></div>
          <Button variant="secondary" onClick={async () => { try { await api.setStatus(c.id, c.status === 'inscricoes' ? 'preparacao' : 'inscricoes'); toast(c.status === 'inscricoes' ? 'Inscrições pausadas.' : 'Inscrições abertas.'); } catch (e) { fail(e); } }}>{c.status === 'inscricoes' ? 'Pausar inscrições' : 'Abrir inscrições'}</Button>
        </section>
      )}
      <LinksPanel v={v} />
      <section className="card pad-lg stack" style={{ borderColor: 'var(--danger)' }}>
        <h3 style={{ fontSize: 17, color: 'var(--danger)' }}>Zona de risco</h3>
        <p className="small muted">Excluir apaga equipes, jogadores, partidas e resultados deste campeonato. Não dá para desfazer.</p>
        <div><Button variant="danger-soft" icon="trash" onClick={async () => {
          if (await confirm({ title: `Excluir “${c.name}”?`, body: 'Todos os dados deste campeonato serão removidos deste navegador.', confirmLabel: 'Excluir campeonato', danger: true })) {
            try { await api.deleteChampionship(c.id); toast('Campeonato excluído.'); navigate('/painel/campeonatos', { replace: true }); } catch (e) { fail(e); }
          }
        }}>Excluir campeonato</Button></div>
      </section>
      {c.drawDone && <Banner icon="info">Para trocar modalidade ou formato, refaça o sorteio em Partidas. Isso apaga as partidas e resultados.</Banner>}
    </div>
  );
}
