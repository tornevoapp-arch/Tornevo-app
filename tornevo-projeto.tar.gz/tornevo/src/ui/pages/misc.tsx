import { useState } from 'react';
import { useRouter } from '../router';
import { Badge, Banner, Button, Empty, useApi, useUi } from '../kit';
import { Icon } from '../icons';
import { resetDemo } from '../../data/seed';
import { StorageNote } from './shell';

export function About() {
  const api = useApi();
  const { confirm, toast, fail } = useUi();
  const { navigate } = useRouter();
  const [busy, setBusy] = useState('');
  const wipe = async () => {
    if (!(await confirm({ title: 'Apagar todos os dados?', body: 'Remove todos os campeonatos, equipes e partidas deste navegador. A tela de início vai pedir para criar o primeiro campeonato.', confirmLabel: 'Apagar tudo', danger: true }))) return;
    setBusy('wipe'); try { await api.wipe(); await api.repo.setMeta('seeded', '1'); toast('Dados apagados.'); navigate('/painel', { replace: true }); } catch (e) { fail(e); } finally { setBusy(''); }
  };
  const restore = async () => { setBusy('reset'); try { await resetDemo(api); toast('Exemplos restaurados.'); navigate('/painel', { replace: true }); } catch (e) { fail(e); } finally { setBusy(''); }};
  return (
    <div className="page narrow">
      <div><h1 className="page-title">Sobre a demonstração</h1><p className="page-sub">Esta é a primeira versão do Tornevo para você testar sem configurar nada. Aqui está o que é real e o que ainda é simulado.</p></div>
      <section className="card pad-lg stack">
        <h2 style={{ fontSize: 20 }}>O que funciona de verdade</h2>
        <ul className="stack sm" style={{ margin: 0, paddingLeft: 20 }}>
          <li>Criar, editar e excluir campeonatos em 5 etapas, com validação de formato e número de equipes.</li>
          <li>Inscrição de equipes e jogadores pelo formulário público, aprovação e recusa pelo painel.</li>
          <li>Sorteio aleatório de grupos e confrontos; todos contra todos, grupos, mata-mata com folgas e grupos + mata-mata.</li>
          <li>Resultados (placar, sets, desempate), gols, assistências, cartões e suspensões, conforme o que cada campeonato ativar.</li>
          <li>Classificação automática com critérios de desempate configuráveis e avanço no chaveamento.</li>
        </ul>
      </section>
      <section className="card pad-lg stack">
        <h2 style={{ fontSize: 20 }}>O que ainda é simulado</h2>
        <ul className="stack sm" style={{ margin: 0, paddingLeft: 20 }}>
          <li><strong>Não há login.</strong> Não existe conta nem segurança de acesso aqui. A autenticação real vem na etapa de produção.</li>
          <li><strong>Os dados ficam só neste navegador.</strong> Outro aparelho, ou outra pessoa, não vê o que você criou.</li>
          <li><strong>Os links públicos não funcionam na internet.</strong> Os endereços de tornevo.app são o formato previsto. Os botões “Abrir” mostram a página equivalente aqui dentro.</li>
          <li>Os códigos públicos são gerados no navegador. Em produção, o servidor gera e valida.</li>
          <li>Escudos das equipes ficam guardados no navegador, reduzidos. Em produção vão para o armazenamento de arquivos.</li>
          <li>Imagem de capa do campeonato, WhatsApp, recuperação de senha e proteção contra spam dependem do backend e não estão nesta versão.</li>
        </ul>
        <Banner icon="info">As barras de endereço do preview não mudam quando você navega. A rota prevista de cada tela aparece no topo.</Banner>
      </section>
      <section className="card pad-lg stack">
        <h2 style={{ fontSize: 20 }}>Como o código está organizado</h2>
        <div className="stack sm">
          <div className="layer demo"><div className="row between wrap"><strong>Interface (React + TypeScript)</strong><Badge tone="orange">fica</Badge></div><p className="small muted">Telas e componentes. Só falam com a camada de serviços.</p></div>
          <div className="layer"><div className="row between wrap"><strong>Domínio (funções puras)</strong><Badge tone="green">fica</Badge></div><p className="small muted">Sorteio, chaveamento, classificação, estatísticas e validações. Sem acesso a armazenamento. As regras de segurança e capacidade também serão validadas no servidor.</p></div>
          <div className="layer"><div className="row between wrap"><strong>Serviços (casos de uso)</strong><Badge tone="green">fica, com nova implementação</Badge></div><p className="small muted">createChampionship, submitRegistration, runDraw, saveResult… É o ponto de troca para chamadas reais ao backend.</p></div>
          <div className="layer demo"><div className="row between wrap"><strong>Repositório local (IndexedDB)</strong><Badge tone="red">será substituído</Badge></div><p className="small muted">Por Supabase (Postgres, autenticação, armazenamento). A interface não muda.</p></div>
        </div>
        <p className="small muted">O passo a passo para ligar os serviços reais está no documento de arquitetura entregue junto com esta versão.</p>
      </section>
      <section className="card pad-lg stack">
        <h2 style={{ fontSize: 20 }}>Seus dados nesta demonstração</h2>
        <StorageNote />
        <div className="row wrap"><Button variant="secondary" icon="refresh" loading={busy === 'reset'} onClick={async () => { if (await confirm({ title: 'Restaurar exemplos?', body: 'Apaga o que você criou e recarrega os 3 campeonatos de exemplo.', confirmLabel: 'Restaurar', danger: true })) restore(); }}>Restaurar exemplos</Button>
          <Button variant="danger-soft" icon="trash" loading={busy === 'wipe'} onClick={wipe}>Apagar tudo</Button></div>
      </section>
    </div>
  );
}

export function Placeholder({ title, children }: { title: string; children: string }) {
  const { navigate } = useRouter();
  return <div className="page narrow"><div className="card"><Empty icon="info" title={title} action={<Button variant="secondary" onClick={() => navigate('/painel')}>Voltar ao painel</Button>}>{children}</Empty></div></div>;
}

export function NotFound() {
  const { navigate } = useRouter();
  return <div className="page narrow"><div className="card"><Empty icon="search" title="Página não encontrada" action={<Button variant="primary" onClick={() => navigate('/painel')}>Ir para o painel</Button>}>O endereço não existe nesta demonstração.</Empty></div></div>;
}
