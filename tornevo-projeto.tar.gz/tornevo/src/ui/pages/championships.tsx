import { useMemo, useState } from 'react';
import { useRouter } from '../router';
import { Button, Empty, Field, Loading, useApi, useQuery, useUi } from '../kit';
import { Icon } from '../icons';
import { ChampCard } from './dashboard';
import { ChampForm } from '../ChampForm';
import { newChampionshipDraft } from '../../domain/defaults';
import type { ChampStatus } from '../../types';

export function Championships() {
  const { navigate } = useRouter();
  const [term, setTerm] = useState('');
  const [status, setStatus] = useState<'todos' | ChampStatus>('todos');
  const q = useQuery((a) => a.listSummaries());
  const list = useMemo(() => (q.data ?? []).filter((s) =>
    (status === 'todos' || s.champ.status === status) && s.champ.name.toLowerCase().includes(term.trim().toLowerCase())), [q.data, term, status]);
  if (!q.data) return <div className="page"><Loading /></div>;
  const chips: Array<[string, 'todos' | ChampStatus]> = [['Todos', 'todos'], ['Em preparação', 'preparacao'], ['Inscrições abertas', 'inscricoes'], ['Em andamento', 'andamento'], ['Encerrados', 'encerrado']];
  return (
    <div className="page">
      <div className="row between wrap top">
        <div><h1 className="page-title">Campeonatos</h1><p className="page-sub">Todos os campeonatos que você organiza.</p></div>
        <Button variant="primary" icon="plus" onClick={() => navigate('/painel/campeonatos/novo')}>Novo campeonato</Button>
      </div>
      <div className="row wrap" style={{ gap: 12 }}>
        <div style={{ flex: '1 1 240px', maxWidth: 360 }}>
          <Field label="Buscar pelo nome" htmlFor="q-term"><div style={{ position: 'relative' }}>
            <input id="q-term" className="input" style={{ paddingLeft: 38 }} value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Ex.: Copa" />
            <span style={{ position: 'absolute', left: 12, top: 12, color: 'var(--muted)' }}><Icon name="search" /></span>
          </div></Field>
        </div>
        <div className="stack sm"><span className="label">Status</span><div className="seg" role="group" aria-label="Filtrar por status">{chips.map(([l, v]) => <button key={v} className={status === v ? 'on' : ''} onClick={() => setStatus(v)}>{l}</button>)}</div></div>
      </div>
      {q.data.length === 0
        ? <div className="card"><Empty title="Nenhum campeonato ainda" action={<Button variant="primary" icon="plus" onClick={() => navigate('/painel/campeonatos/novo')}>Criar primeiro campeonato</Button>}>Crie um campeonato para receber inscrições e organizar os jogos.</Empty></div>
        : list.length === 0
          ? <div className="card"><Empty icon="search" title="Nada encontrado">Nenhum campeonato combina com a busca ou o filtro.</Empty></div>
          : <div className="grid g3">{list.map((s) => <ChampCard key={s.champ.id} s={s} />)}</div>}
    </div>
  );
}

export function NewChampionship() {
  const api = useApi();
  const { navigate } = useRouter();
  const { toast } = useUi();
  return (
    <div className="page narrow">
      <div><h1 className="page-title">Novo campeonato</h1><p className="page-sub">Cinco etapas rápidas. Você pode voltar sem perder o que preencheu.</p></div>
      <ChampForm mode="create" initial={newChampionshipDraft()} onSave={async (c) => {
        const created = await api.createChampionship(c);
        toast('Campeonato criado. Os links já estão disponíveis.');
        navigate(`/painel/campeonatos/${created.id}`, { replace: true });
      }} />
    </div>
  );
}
