import { useState } from 'react';
import { Link, useRouter } from '../router';
import { Badge, Banner, Button, Empty, Loading, Shield, useApi, useQuery } from '../kit';
import { Icon } from '../icons';
import { BracketView, MatchList, ScorersView, StandingsView, StatusBadge, TeamForm, teamMap } from '../views';
import { PublicShell } from './shell';
import { fmtDateRange } from '../../domain/format';
import { sportName } from '../../domain/sports';
import { podium } from '../../domain/tournament';
import { plannedUrl } from '../../config';

export function InvalidLink({ kind }: { kind: 'torneio' | 'inscricao' }) {
  const { navigate } = useRouter();
  return (
    <PublicShell><div className="page narrow"><div className="card">
      <Empty icon="ban" title="Este link não está disponível" action={<Button variant="primary" onClick={() => navigate('/painel')}>Voltar ao painel da demonstração</Button>}>
        {kind === 'torneio' ? 'O link do campeonato não existe ou foi substituído por um novo. Peça o link atualizado ao organizador.' : 'O link de inscrição não existe, foi desativado ou foi substituído por um novo. Peça o link atualizado ao organizador.'}
      </Empty></div></div></PublicShell>
  );
}

export function PublicTournament({ code }: { code: string }) {
  const q = useQuery((a) => a.getPublicView(code), [code]);
  const [tab, setTab] = useState('classificacao');
  if (q.loading && !q.data) return <PublicShell><div className="page"><Loading /></div></PublicShell>;
  if (!q.data) return <InvalidLink kind="torneio" />;
  const { champ: c, teams, players, matches } = q.data;
  const hasKo = matches.some((m) => m.phase === 'knockout');
  const pod = c.status === 'encerrado' ? podium(c, teams, matches) : null;
  const tm = teamMap(teams);
  const tabs: Array<[string, string]> = [['classificacao', c.format === 'knockout' ? 'Chaveamento' : 'Classificação'], ['jogos', 'Jogos'], ...(hasKo && c.format !== 'knockout' ? [['chave', 'Eliminatórias'] as [string, string]] : []), ...(c.stats.scorers ? [['artilharia', 'Artilharia'] as [string, string]] : []), ['equipes', 'Equipes']];
  return (
    <PublicShell>
      <div className="page">
        <section className="stack">
          <div className="row wrap" style={{ gap: 6 }}><StatusBadge status={c.status} /><Badge>{sportName(c)}</Badge><Badge>{c.category}</Badge></div>
          <h1 className="page-title">{c.name}</h1>
          <p className="muted small num"><Icon name="calendar" size={14} /> {fmtDateRange(c.startDate, c.endDate)}{c.venue || c.city ? ` · ${[c.venue, c.city].filter(Boolean).join(', ')}` : ''}</p>
          {c.description && <p style={{ maxWidth: '65ch' }}>{c.description}</p>}
        </section>
        {pod && <section className="card pad-lg hero-box row wrap" style={{ gap: 20 }}><Icon name="trophy" size={36} />{([['Campeão', pod.first], ['Vice', pod.second], ['3º lugar', pod.third]] as const).filter(([, id]) => id).map(([l, id]) => <div key={l} className="row"><Shield team={tm.get(id!) ?? null} size={32} /><div><div className="xs muted">{l}</div><div className="bold">{tm.get(id!)?.name}</div></div></div>)}</section>}
        {c.status === 'inscricoes' && <Banner tone="good" icon="users">Inscrições abertas para equipes. <Link to={`/inscricao/${c.regCode}`} style={{ fontWeight: 700 }}>Abrir formulário de inscrição (demo)</Link></Banner>}
        <nav className="tabs" aria-label="Seções">{tabs.map(([k, l]) => <button key={k} className={`tab${tab === k ? ' active' : ''}`} onClick={() => setTab(k)}>{l}</button>)}</nav>
        {tab === 'classificacao' && <StandingsView champ={c} teams={teams} matches={matches} />}
        {tab === 'jogos' && (matches.length ? <MatchList matches={matches} teams={teams} champ={c} /> : <div className="card"><Empty icon="calendar" title="Jogos ainda não definidos">As partidas aparecem depois do sorteio.</Empty></div>)}
        {tab === 'chave' && <BracketView matches={matches} teams={teams} />}
        {tab === 'artilharia' && <ScorersView champ={c} teams={teams} players={players} matches={matches} />}
        {tab === 'equipes' && (teams.length ? (
          <div className="grid g3">{teams.map((t) => (
            <details key={t.id} className="card pad"><summary className="row" style={{ cursor: 'pointer', listStyle: 'none' }}><Shield team={t} size={40} /><div className="grow"><div className="bold">{t.name}</div><div className="xs muted">{t.group ? `Grupo ${t.group} · ` : ''}{players.filter((p) => p.teamId === t.id).length} jogadores</div></div><Icon name="down" size={16} /></summary>
              <ul style={{ margin: '12px 0 0', padding: 0, listStyle: 'none' }} className="stack sm">{players.filter((p) => p.teamId === t.id).map((p) => <li key={p.id} className="row small"><span className="num-badge" style={{ width: 26, height: 26 }}>{p.number ?? '–'}</span><span>{p.name}</span><span className="muted xs">{p.position}</span></li>)}</ul></details>
          ))}</div>
        ) : <div className="card"><Empty icon="users" title="Nenhuma equipe confirmada ainda" /></div>)}
        <p className="small muted">Link previsto: {plannedUrl('torneio', c.publicCode)}</p>
      </div>
    </PublicShell>
  );
}

export function PublicRegister({ code }: { code: string }) {
  const api = useApi();
  const { navigate } = useRouter();
  const q = useQuery((a) => a.getRegistrationView(code), [code]);
  const [done, setDone] = useState<string | null>(null);
  if (q.loading && !q.data) return <PublicShell><div className="page"><Loading /></div></PublicShell>;
  if (!q.data) return <InvalidLink kind="inscricao" />;
  const { champ: c, approved, state } = q.data;
  const left = Math.max(0, c.maxTeams - approved);
  return (
    <PublicShell>
      <div className="page narrow">
        <section className="stack">
          <div className="row wrap" style={{ gap: 6 }}><Badge tone="orange">Inscrição de equipes</Badge><Badge>{sportName(c)}</Badge><Badge>{c.category}</Badge></div>
          <h1 className="page-title">{c.name}</h1>
          <dl className="kv">
            <dt>Datas</dt><dd className="num">{fmtDateRange(c.startDate, c.endDate)}</dd>
            {(c.venue || c.city) && <><dt>Local</dt><dd>{[c.venue, c.city].filter(Boolean).join(', ')}</dd></>}
            <dt>Vagas</dt><dd className="num">{left} de {c.maxTeams} restantes</dd>
            {c.regCloseDate && <><dt>Inscrições até</dt><dd className="num">{fmtDateRange(c.regCloseDate, '')}</dd></>}
            {(c.minPlayers || c.maxPlayers) && <><dt>Elenco</dt><dd>{c.minPlayers ? `mínimo ${c.minPlayers}` : ''}{c.minPlayers && c.maxPlayers ? ' · ' : ''}{c.maxPlayers ? `máximo ${c.maxPlayers}` : ''} jogadores</dd></>}
          </dl>
          {c.regNotes && <Banner icon="info">{c.regNotes}</Banner>}
        </section>

        {done ? (
          <section className="card pad-lg stack" style={{ borderColor: 'var(--ok)' }}>
            <div className="row"><span className="badge b-green" style={{ padding: 10 }}><Icon name="check" size={22} /></span><h2 style={{ fontSize: 22 }}>Solicitação recebida</h2></div>
            <p><strong>{done}</strong> foi enviada para análise. O organizador vai aprovar ou recusar. Nesta demonstração, ela aparece como pendente na aba Equipes do painel.</p>
            <div className="row wrap"><Button variant="primary" onClick={() => navigate(`/painel/campeonatos/${c.id}/equipes`)}>Ver no painel (demo)</Button><Button variant="secondary" onClick={() => setDone(null)}>Enviar outra equipe</Button></div>
          </section>
        ) : !state.open ? (
          <div className="card"><Empty icon="lock" title="Inscrições indisponíveis">{state.reason}</Empty></div>
        ) : (
          <section className="card pad-lg stack">
            <h2 style={{ fontSize: 20 }}>Dados da equipe</h2>
            <TeamForm champ={c} submitLabel="Enviar inscrição" onSubmit={async (d) => { const t = await api.submitRegistration(code, d); setDone(t.name); window.scrollTo({ top: 0 }); }} />
          </section>
        )}
        <p className="small muted">Link previsto: {plannedUrl('inscricao', c.regCode)}. Nenhuma conta é necessária para se inscrever.</p>
      </div>
    </PublicShell>
  );
}
