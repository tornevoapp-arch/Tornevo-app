import type { ReactNode } from 'react';
import { Link, useRouter } from '../router';
import { Icon, Logo } from '../icons';
import { useApi, useUi } from '../kit';
import { resetDemo } from '../../data/seed';
import { plannedUrl, config } from '../../config';

const NAV = [
  { to: '/painel', label: 'Painel', short: 'Painel', icon: 'home', match: (p: string) => p === '/painel' },
  { to: '/painel/campeonatos', label: 'Campeonatos', short: 'Torneios', icon: 'trophy', match: (p: string) => p.startsWith('/painel/campeonatos') && p !== '/painel/campeonatos/novo' },
  { to: '/painel/campeonatos/novo', label: 'Novo campeonato', short: 'Criar', icon: 'plus', match: (p: string) => p === '/painel/campeonatos/novo' },
  { to: '/sobre', label: 'Sobre a demonstração', short: 'Sobre', icon: 'layers', match: (p: string) => p === '/sobre' },
];

export function DemoPill({ label = 'Modo de demonstração' }: { label?: string }) {
  return <span className="demo-pill" title="Dados de exemplo salvos apenas neste navegador"><i className="dot" />{label}</span>;
}

export function StorageNote() {
  const api = useApi();
  return api.storageMode === 'indexeddb'
    ? <p className="xs muted">Seus dados ficam salvos neste navegador (IndexedDB). Nada é enviado a servidores.</p>
    : <p className="xs" style={{ color: 'var(--accent-text)' }}>O armazenamento do navegador não está disponível aqui. Os dados valem só enquanto esta página estiver aberta.</p>;
}

export function Shell({ children }: { children: ReactNode }) {
  const { route, navigate } = useRouter();
  const api = useApi();
  const { confirm, toast, fail } = useUi();
  const restore = async () => {
    const ok = await confirm({ title: 'Restaurar dados de exemplo?', body: 'Tudo o que você criou nesta demonstração será apagado e os 3 campeonatos de exemplo voltam ao estado inicial.', confirmLabel: 'Restaurar', danger: true });
    if (!ok) return;
    try { await resetDemo(api); navigate('/painel', { replace: true }); toast('Exemplos restaurados.'); } catch (e) { fail(e); }
  };
  return (
    <div className="app">
      <aside className="sidebar" aria-label="Menu principal">
        <Link to="/painel" className="row" style={{ textDecoration: 'none', padding: '2px 6px' }}><Logo size={34} /></Link>
        <nav className="side-nav">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} className={`side-link${n.match(route.path) ? ' active' : ''}`} aria-current={n.match(route.path) ? 'page' : undefined}><Icon name={n.icon} /> {n.label}</Link>
          ))}
        </nav>
        <div className="side-foot">
          <div className="card pad stack sm" style={{ boxShadow: 'none' }}>
            <DemoPill />
            <p className="small muted">Sem login. Os exemplos são fictícios e você pode mexer à vontade.</p>
            <StorageNote />
            <button className="btn btn-secondary btn-sm" onClick={restore}><Icon name="refresh" size={16} /> Restaurar exemplos</button>
          </div>
        </div>
      </aside>
      <div className="main">
        <header className="topbar gutter">
          <div className="topbar-in">
            <Link to="/painel" className="brand-mobile grow" style={{ textDecoration: 'none' }}><Logo size={28} /></Link>
            <span className="grow trunc small muted route-chip" title="Rota prevista em produção"><span className="xs">rota prevista</span> <code style={{ fontFamily: 'ui-monospace, monospace' }}>{config.publicBaseUrl.replace('https://', '')}{route.path}</code></span>
            <DemoPill />
          </div>
        </header>
        <main className="gutter" style={{ flex: 1, minWidth: 0 }}>{children}</main>
      </div>
      <nav className="bottom-nav" aria-label="Menu principal">
        {NAV.map((n) => (
          <Link key={n.to} to={n.to} className={`bn-link${n.match(route.path) ? ' active' : ''}`}><Icon name={n.icon} size={22} />{n.short}</Link>
        ))}
      </nav>
    </div>
  );
}

export function PublicShell({ children }: { children: ReactNode }) {
  const { navigate, canBack, back } = useRouter();
  return (
    <div style={{ minHeight: '100%' }}>
      <header className="topbar gutter">
        <div className="topbar-in">
          <Logo size={30} />
          <span className="grow" />
          <DemoPill label="Página pública simulada" />
          <button className="btn btn-secondary btn-sm" onClick={() => (canBack ? back() : navigate('/painel'))}><Icon name="back" size={16} /> Voltar ao painel</button>
        </div>
      </header>
      <main className="gutter">{children}</main>
      <footer className="gutter" style={{ paddingBlock: 24 }}>
        <p className="small muted" style={{ maxWidth: 1180, margin: '0 auto' }}>Link previsto em produção: {plannedUrl('torneio', '…')}. Nesta demonstração a página só abre neste navegador, com os dados salvos aqui.</p>
      </footer>
    </div>
  );
}
