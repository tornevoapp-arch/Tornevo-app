import { useMemo, useRef, useState } from 'react';
import type { Championship, ChampStatus, Match, Player, Team } from '../types';
import { Badge, Button, Empty, Field, Shield, useUi } from './kit';
import { Icon } from './icons';
import { SPORTS, tiebreakOptions } from '../domain/sports';
import { computeStandings, groupLetters } from '../domain/standings';
import { fmtDateLong } from '../domain/format';
import { isKnockout, winnerOf } from '../domain/results';
import { validateRegistration, type Errors, type RegistrationInput } from '../domain/validation';
import { DomainError } from '../services/api';
import { fileToShield } from './image';
import { playerStats, ranking } from '../domain/stats';

export const STATUS: Record<ChampStatus, { label: string; tone?: 'orange' | 'green' | 'red' | 'blue' }> = {
  preparacao: { label: 'Em preparação' },
  inscricoes: { label: 'Inscrições abertas', tone: 'green' },
  andamento: { label: 'Em andamento', tone: 'orange' },
  encerrado: { label: 'Encerrado', tone: 'blue' },
};

export function StatusBadge({ status }: { status: ChampStatus }) {
  const s = STATUS[status];
  return <Badge tone={s.tone} dot>{s.label}</Badge>;
}

export const teamMap = (teams: Team[]) => new Map(teams.map((t) => [t.id, t]));

/* ---------- partidas ---------- */
export function MatchCard({ match: m, teams, champ, onOpen, openLabel }: { match: Match; teams: Map<string, Team>; champ: Championship; onOpen?: () => void; openLabel?: string }) {
  const home = m.homeId ? teams.get(m.homeId) ?? null : null;
  const away = m.awayId ? teams.get(m.awayId) ?? null : null;
  const w = winnerOf(m);
  const sp = SPORTS[champ.sport];
  const fin = m.status === 'finished';
  const row = (t: Team | null, score: number | null, pens: number | null, win: boolean) => (
    <div className={`mt${win ? ' win' : ''}${t ? '' : ' tbd'}`}>
      <Shield team={t} size={28} />
      <span className="nm">{t ? t.name : 'A definir'}</span>
      {fin && <span className="sc">{score}{pens != null && <small className="muted" style={{ fontSize: 12, marginLeft: 4 }}>({pens})</small>}</span>}
    </div>
  );
  return (
    <div className="match">
      <div className="teams">
        {row(home, m.homeScore, m.homePens, w === 'home')}
        {row(away, m.awayScore, m.awayPens, w === 'away')}
        {fin && m.sets && <div className="xs muted num">{m.sets.map(([a, b]) => `${a}-${b}`).join(' · ')}</div>}
      </div>
      <div className="meta side">
        <div className="row wrap" style={{ justifyContent: 'flex-end', gap: 6 }}>
          {m.group && <Badge>Grupo {m.group}</Badge>}
          {m.phase === 'third' && <Badge tone="orange">3º lugar</Badge>}
          {fin ? <Badge tone="green">Encerrada</Badge> : <Badge>Agendada</Badge>}
        </div>
        <div className="small muted num" style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <Icon name="clock" size={14} />
          {m.date ? `${fmtDateLong(m.date)}${m.time ? ` · ${m.time}` : ''}` : 'Sem data'}
        </div>
        {onOpen && (
          <Button size="sm" variant={fin ? 'secondary' : 'primary'} onClick={onOpen} disabled={!home || !away && !fin}>
            {openLabel ?? (fin ? 'Editar' : 'Registrar resultado')}
          </Button>
        )}
        {!fin && sp.timed && champ.periods > 0 && <span className="xs muted">{champ.periods}×{champ.periodMinutes} min</span>}
      </div>
    </div>
  );
}

export interface Section { key: string; title: string; matches: Match[] }

export function groupMatches(matches: Match[]): Section[] {
  const map = new Map<string, Section>();
  for (const m of [...matches].sort((a, b) => a.order - b.order)) {
    const title = m.phase === 'group' ? `Fase de grupos · ${m.roundLabel}` : m.roundLabel;
    const key = `${m.phase === 'group' ? 'g' : m.phase}-${title}`;
    if (!map.has(key)) map.set(key, { key, title, matches: [] });
    map.get(key)!.matches.push(m);
  }
  return [...map.values()];
}

export function MatchList({ matches, teams, champ, onOpen }: { matches: Match[]; teams: Team[]; champ: Championship; onOpen?: (m: Match) => void }) {
  const tm = useMemo(() => teamMap(teams), [teams]);
  const sections = useMemo(() => groupMatches(matches), [matches]);
  if (matches.length === 0) return <Empty icon="calendar" title="Nenhuma partida aqui">Ajuste os filtros ou gere as partidas pelo sorteio.</Empty>;
  return (
    <div className="stack lg">
      {sections.map((s) => (
        <section key={s.key} className="stack sm">
          <div className="round-title">{s.title} <span className="badge num">{s.matches.length}</span></div>
          <div className="stack sm">
            {s.matches.map((m) => <MatchCard key={m.id} match={m} teams={tm} champ={champ} onOpen={onOpen ? () => onOpen(m) : undefined} />)}
          </div>
        </section>
      ))}
    </div>
  );
}

/* ---------- chaveamento ---------- */
export function BracketView({ matches, teams, onOpen }: { matches: Match[]; teams: Team[]; onOpen?: (m: Match) => void }) {
  const tm = useMemo(() => teamMap(teams), [teams]);
  const ko = matches.filter((m) => m.phase === 'knockout');
  const third = matches.find((m) => m.phase === 'third');
  const rounds = [...new Set(ko.map((m) => m.ko!.round))].sort((a, b) => a - b);
  if (ko.length === 0) return <Empty icon="trophy" title="O chaveamento aparece aqui">Ele é gerado quando as eliminatórias começam.</Empty>;
  const box = (m: Match) => {
    const w = winnerOf(m);
    const h = m.homeId ? tm.get(m.homeId) ?? null : null;
    const a = m.awayId ? tm.get(m.awayId) ?? null : null;
    const r = (t: Team | null, sc: number | null, pens: number | null, win: boolean) => (
      <div className={`b-row${win ? ' win' : ''}${t ? '' : ' tbd'}`}>
        <Shield team={t} size={20} /><span className="trunc">{t ? t.name : 'A definir'}</span>
        {m.status === 'finished' && <span className="sc">{sc}{pens != null ? ` (${pens})` : ''}</span>}
      </div>
    );
    return (
      <button key={m.id} className="b-match" onClick={() => onOpen?.(m)} disabled={!onOpen} aria-label={`${h?.name ?? 'A definir'} contra ${a?.name ?? 'A definir'}`}>
        {r(h, m.homeScore, m.homePens, w === 'home')}
        {r(a, m.awayScore, m.awayPens, w === 'away')}
        {(m.date || m.sets) && <div className="b-info num">{m.date ? `${fmtDateLong(m.date)}${m.time ? ` · ${m.time}` : ''}` : ''}{m.sets && m.status === 'finished' ? `${m.date ? ' · ' : ''}${m.sets.map(([x, y]) => `${x}-${y}`).join(' ')}` : ''}</div>}
      </button>
    );
  };
  return (
    <div className="stack">
      <div className="bracket">
        {rounds.map((r) => {
          const list = ko.filter((m) => m.ko!.round === r).sort((a, b) => a.ko!.index - b.ko!.index);
          return (
            <div key={r} className="b-col">
              <div className="eyebrow">{list[0].roundLabel}</div>
              <div className="b-list">{list.map(box)}</div>
            </div>
          );
        })}
      </div>
      {third && (
        <div className="stack sm" style={{ maxWidth: 260 }}>
          <div className="eyebrow">Disputa de 3º lugar</div>
          {box(third)}
        </div>
      )}
    </div>
  );
}

/* ---------- classificação ---------- */
export function StandingsTable({ champ, teams, matches, group, qualify }: { champ: Championship; teams: Team[]; matches: Match[]; group?: string | null; qualify?: number }) {
  const rows = useMemo(() => computeStandings(champ, teams, matches, group), [champ, teams, matches, group]);
  const tm = useMemo(() => teamMap(teams), [teams]);
  const sp = SPORTS[champ.sport];
  const sets = sp.sets;
  return (
    <div className="tbl-wrap">
      <table className="tbl">
        <caption className="sr">Classificação{group ? ` do grupo ${group}` : ''}</caption>
        <thead>
          <tr>
            <th>#</th><th className="left">Equipe</th>
            <th title="Pontos">Pts</th><th title="Jogos">J</th><th title="Vitórias">V</th>
            {sp.draws && <th title="Empates">E</th>}
            <th title="Derrotas">D</th>
            <th title={sets ? 'Sets a favor' : `${sp.scoreUnit} a favor`}>Pró</th>
            <th title={sets ? 'Sets contra' : `${sp.scoreUnit} contra`}>Contra</th>
            <th title="Saldo">Saldo</th>
            {sets && <th title="Saldo de pontos nos sets">Pts±</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const t = tm.get(r.teamId)!;
            return (
              <tr key={r.teamId} className={qualify && r.position <= qualify ? 'qual' : ''}>
                <td><span className="pos">{r.position}</span></td>
                <td className="left team"><span className="row"><Shield team={t} size={26} /><span className="trunc" style={{ maxWidth: 190, fontWeight: 600 }}>{t.name}</span></span></td>
                <td className="pts">{r.points}</td><td>{r.played}</td><td>{r.wins}</td>
                {sp.draws && <td>{r.draws}</td>}
                <td>{r.losses}</td><td>{r.gf}</td><td>{r.ga}</td>
                <td>{r.gd > 0 ? `+${r.gd}` : r.gd}</td>
                {sets && <td>{r.pf - r.pa > 0 ? `+${r.pf - r.pa}` : r.pf - r.pa}</td>}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function TiebreakNote({ champ }: { champ: Championship }) {
  const opts = tiebreakOptions(champ.sport);
  const crit = champ.tiebreakers.map((id) => opts.find((o) => o.id === id)).filter((o) => o && !(o.id === 'fairplay' && !(champ.stats.yellow || champ.stats.red)));
  const sp = SPORTS[champ.sport];
  return (
    <p className="small muted">
      {sp.sets
        ? `Pontos: vitória por 2×0 ou 2×1 vale ${champ.pointsWin}, vitória no tie-break vale ${champ.pointsWin - 1} e derrota no tie-break vale 1.`
        : `Pontos: vitória ${champ.pointsWin}${sp.draws ? `, empate ${champ.pointsDraw}` : ''}, derrota ${champ.pointsLoss}.`}
      {' '}Desempate: {crit.length ? crit.map((o, i) => `${i + 1}. ${o!.label}`).join(' · ') : 'ordem alfabética'}.
    </p>
  );
}

export function StandingsView({ champ, teams, matches }: { champ: Championship; teams: Team[]; matches: Match[] }) {
  const approved = teams.filter((t) => t.status === 'approved');
  if (champ.format === 'knockout') return <BracketView matches={matches} teams={approved} />;
  if (!champ.drawDone) return <Empty icon="table" title="Classificação ainda não disponível">Ela aparece depois do sorteio, assim que houver partidas.</Empty>;
  if (champ.format === 'league') {
    return (
      <div className="stack">
        <div className="card"><StandingsTable champ={champ} teams={approved} matches={matches} /></div>
        <TiebreakNote champ={champ} />
      </div>
    );
  }
  const letters = groupLetters(approved);
  const q = champ.format === 'groups_knockout' ? champ.qualifiersPerGroup : 0;
  return (
    <div className="stack lg">
      <div className="grid g2">
        {letters.map((g) => (
          <div key={g} className="card">
            <div className="card-head"><h3>Grupo {g}</h3>{q > 0 && <span className="xs muted">Destaque laranja: classificados</span>}</div>
            <StandingsTable champ={champ} teams={approved} matches={matches} group={g} qualify={q} />
          </div>
        ))}
      </div>
      <TiebreakNote champ={champ} />
      {champ.format === 'groups_knockout' && champ.knockoutGenerated && (
        <section className="stack"><h2 style={{ fontSize: 20 }}>Eliminatórias</h2><BracketView matches={matches} teams={approved} /></section>
      )}
    </div>
  );
}

export function RankingTable({ title, rows, players, teams, unit }: { title: string; rows: Array<{ playerId: string; teamId: string; value: number }>; players: Player[]; teams: Team[]; unit: string }) {
  const pm = new Map(players.map((p) => [p.id, p]));
  const tm = teamMap(teams);
  return (
    <div className="card">
      <div className="card-head"><h3>{title}</h3></div>
      {rows.length === 0 ? <p className="muted pad small">Ainda não há registros.</p> : (
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr><th>#</th><th className="left">Jogador</th><th className="left">Equipe</th><th>{unit}</th></tr></thead>
            <tbody>
              {rows.slice(0, 10).map((r, i) => (
                <tr key={r.playerId}>
                  <td><span className="pos">{i + 1}</span></td>
                  <td className="left" style={{ fontWeight: 600 }}>{pm.get(r.playerId)?.name ?? '—'}</td>
                  <td className="left"><span className="row"><Shield team={tm.get(r.teamId) ?? null} size={20} /><span className="muted">{tm.get(r.teamId)?.name}</span></span></td>
                  <td className="pts">{r.value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function ScorersView({ champ, teams, players, matches }: { champ: Championship; teams: Team[]; players: Player[]; matches: Match[] }) {
  const st = useMemo(() => playerStats(players, matches), [players, matches]);
  const goals = ranking(st, 'goals', players).map((s) => ({ playerId: s.playerId, teamId: s.teamId, value: s.goals }));
  if (!champ.stats.scorers) return <Empty icon="chart" title="Artilharia desativada">O organizador não ativou o registro de gols neste campeonato.</Empty>;
  return <RankingTable title={SPORTS[champ.sport].scorerLabel || 'Artilharia'} rows={goals} players={players} teams={teams} unit={SPORTS[champ.sport].scoreUnit === 'gols' ? 'Gols' : 'Pontos'} />;
}

export function isFinalPhase(m: Match) { return isKnockout(m); }

/* ---------- formulário de equipe (inscrição pública e cadastro do organizador) ---------- */
type PRow = { name: string; number: string; position: string };
const POSITIONS: Record<string, string[]> = {
  futebol: ['Goleiro', 'Zagueiro', 'Lateral', 'Volante', 'Meia', 'Atacante'],
  futsal: ['Goleiro', 'Fixo', 'Ala', 'Pivô'],
  volei: ['Levantador', 'Ponteiro', 'Central', 'Oposto', 'Líbero'],
  basquete: ['Armador', 'Ala', 'Pivô'],
  esports: ['Titular', 'Reserva'],
  outra: [],
};

export function TeamForm({ champ, submitLabel, onSubmit, onCancel, hideContactNote }: {
  champ: Championship; submitLabel: string; hideContactNote?: boolean;
  onSubmit: (data: RegistrationInput & { shield: string | null }) => Promise<void>; onCancel?: () => void;
}) {
  const { toast } = useUi();
  const [f, setF] = useState({ name: '', manager: '', email: '', phone: '', city: '' });
  const [shield, setShield] = useState<string | null>(null);
  const [players, setPlayers] = useState<PRow[]>(() => Array.from({ length: Math.min(Math.max(champ.minPlayers ?? 3, 3), 6) }, () => ({ name: '', number: '', position: '' })));
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }));
  const updP = (i: number, k: keyof PRow, v: string) => setPlayers((ps) => ps.map((p, j) => (j === i ? { ...p, [k]: v } : p)));
  const filled = players.filter((p) => p.name.trim()).length;
  const canAdd = champ.maxPlayers == null || players.length < champ.maxPlayers;
  const input = (id: string, k: keyof typeof f, label: string, opts: { type?: string; optional?: boolean; hint?: string; ph?: string; autoComplete?: string } = {}) => (
    <Field label={label} optional={opts.optional} hint={opts.hint} error={errors[k]} htmlFor={id}>
      <input id={id} className={`input${errors[k] ? ' err' : ''}`} type={opts.type ?? 'text'} value={f[k]} onChange={set(k)} placeholder={opts.ph} autoComplete={opts.autoComplete} inputMode={opts.type === 'tel' ? 'tel' : undefined} />
    </Field>
  );
  const pick = async (file?: File) => {
    if (!file) return;
    try { setShield(await fileToShield(file)); } catch (e) { toast((e as Error).message, 'bad'); }
    if (fileRef.current) fileRef.current.value = '';
  };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const data = { ...f, players, shield };
    const errs = validateRegistration(champ, data);
    setErrors(errs);
    if (Object.keys(errs).length) {
      toast('Revise os campos destacados.', 'bad');
      requestAnimationFrame(() => document.querySelector('.err-text')?.scrollIntoView({ block: 'center', behavior: 'smooth' }));
      return;
    }
    setBusy(true);
    try { await onSubmit(data); } catch (er) {
      if (er instanceof DomainError && er.fields) setErrors(er.fields);
      toast((er as Error).message, 'bad');
    } finally { setBusy(false); }
  };
  const posList = POSITIONS[champ.sport];
  return (
    <form className="stack lg" onSubmit={submit} noValidate>
      <div className="stack">
        <div className="row top" style={{ gap: 14 }}>
          <div className="stack sm" style={{ alignItems: 'center' }}>
            <Shield team={{ name: f.name || 'Equipe', shield }} size={72} />
            <input ref={fileRef} id="shield-file" type="file" accept="image/png,image/jpeg,image/webp" className="sr" onChange={(e) => pick(e.target.files?.[0])} />
            <div className="row" style={{ gap: 4 }}>
              <Button size="sm" variant="secondary" icon="upload" onClick={() => fileRef.current?.click()}>{shield ? 'Trocar' : 'Escudo'}</Button>
              {shield && <Button size="sm" variant="ghost" onClick={() => setShield(null)} aria-label="Remover escudo"><Icon name="x" size={16} /></Button>}
            </div>
          </div>
          <div className="grow stack">{input('tf-name', 'name', 'Nome da equipe', { ph: 'Ex.: Unidos da Esperança', autoComplete: 'off' })}</div>
        </div>
        <div className="grid g2">
          {input('tf-manager', 'manager', 'Responsável pela equipe', { autoComplete: 'name' })}
          {input('tf-city', 'city', 'Cidade', { optional: !champ.requireCity })}
          {input('tf-email', 'email', 'E-mail de contato', { type: 'email', optional: champ.contactRule !== 'email', autoComplete: 'email' })}
          {input('tf-phone', 'phone', 'Telefone / WhatsApp', { type: 'tel', optional: champ.contactRule !== 'phone', ph: '(11) 91234-5678', autoComplete: 'tel' })}
        </div>
        {!hideContactNote && champ.contactRule === 'either' && <p className="hint">Informe pelo menos um contato: e-mail ou telefone.</p>}
      </div>

      <div className="stack">
        <div className="row between wrap">
          <div>
            <h3 style={{ fontSize: 18 }}>Jogadores</h3>
            <p className="hint num">
              {filled} cadastrado{filled === 1 ? '' : 's'}
              {champ.minPlayers != null && ` · mínimo ${champ.minPlayers}`}{champ.maxPlayers != null && ` · máximo ${champ.maxPlayers}`}
            </p>
          </div>
          <Button size="sm" variant="secondary" icon="plus" disabled={!canAdd} onClick={() => setPlayers((p) => [...p, { name: '', number: '', position: '' }])}>Adicionar jogador</Button>
        </div>
        {errors.players && <span className="err-text" role="alert">{errors.players}</span>}
        <datalist id="pos-list">{posList.map((p) => <option key={p} value={p} />)}</datalist>
        <div className="stack sm">
          {players.map((p, i) => (
            <div key={i} className="row top" style={{ gap: 8 }}>
              <div className="grow" style={{ flex: 3 }}>
                <label className="sr" htmlFor={`pn-${i}`}>Nome do jogador {i + 1}</label>
                <input id={`pn-${i}`} className={`input${errors[`player-${i}-name`] ? ' err' : ''}`} placeholder={`Jogador ${i + 1}`} value={p.name} onChange={(e) => updP(i, 'name', e.target.value)} autoComplete="off" />
                {errors[`player-${i}-name`] && <span className="err-text">{errors[`player-${i}-name`]}</span>}
              </div>
              <div style={{ width: 74 }}>
                <label className="sr" htmlFor={`pnum-${i}`}>Camisa do jogador {i + 1}</label>
                <input id={`pnum-${i}`} className={`input${errors[`player-${i}-number`] ? ' err' : ''}`} placeholder="Nº" inputMode="numeric" value={p.number} onChange={(e) => updP(i, 'number', e.target.value.replace(/\D/g, '').slice(0, 3))} />
                {errors[`player-${i}-number`] && <span className="err-text">{errors[`player-${i}-number`]}</span>}
              </div>
              <div className="grow" style={{ flex: 2 }}>
                <label className="sr" htmlFor={`pp-${i}`}>Posição do jogador {i + 1}</label>
                <input id={`pp-${i}`} className="input" list="pos-list" placeholder="Posição" value={p.position} onChange={(e) => updP(i, 'position', e.target.value)} />
              </div>
              <Button variant="ghost" className="btn-icon" aria-label={`Remover jogador ${i + 1}`} onClick={() => setPlayers((ps) => ps.filter((_, j) => j !== i))}><Icon name="trash" /></Button>
            </div>
          ))}
          {players.length === 0 && <p className="muted small">Nenhum jogador na lista. Use “Adicionar jogador”.</p>}
        </div>
        <p className="hint">Linhas vazias são ignoradas. A foto individual não é necessária; sem foto, o jogador aparece com um avatar padrão.</p>
      </div>

      <div className="row wrap" style={{ justifyContent: 'flex-end' }}>
        {onCancel && <Button variant="secondary" onClick={onCancel}>Cancelar</Button>}
        <Button type="submit" variant="primary" loading={busy}>{submitLabel}</Button>
      </div>
    </form>
  );
}
