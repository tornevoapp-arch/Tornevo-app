/**
 * Configuração central. Em produção estes valores vêm de variáveis de ambiente
 * (ex.: import.meta.env.VITE_PUBLIC_BASE_URL). Nenhuma credencial vive aqui.
 */
export const config = {
  /** Domínio planejado. Usado só para MOSTRAR o link previsto; ainda não está publicado. */
  publicBaseUrl: 'https://tornevo.app',
  appName: 'Tornevo',
  slogan: 'Seu campeonato. Sua história. Sua vitória.',
  demoMode: true,
  publicCodeLength: 12,
  maxShieldBytes: 300 * 1024,
} as const;

export function plannedUrl(kind: 'torneio' | 'inscricao', code: string): string {
  return `${config.publicBaseUrl}/${kind}/${code}`;
}
