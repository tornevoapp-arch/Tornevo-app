import type { Championship, Match, MatchEvent, Player } from '../types';
import { SPORTS } from './sports';

export interface ResultInput {
  homeScore: number | null;
  awayScore: number | null;
  homePens: number | null;
  awayPens: number | null;
  sets: Array<[number, number]> | null;
  events: MatchEvent[];
}

const int = (n: unknown): n is number => typeof n === 'number' && Number.isInteger(n) && n >= 0;

export function isKnockout(m: Match): boolean {
  return m.phase === 'knockout' || m.phase === 'third';
}

export function setsWon(sets: Array<[number, number]>): [number, number] {
  let h = 0, a = 0;
  for (const [x, y] of sets) { if (x > y) h++; else if (y > x) a++; }
  return [h, a];
}

/** Valida e devolve o resultado normalizado, ou lista de erros. */
export function checkResult(
  c: Championship, m: Match, input: ResultInput, players: Player[],
): { ok: true; value: ResultInput } | { ok: false; errors: string[] } {
  const sp = SPORTS[c.sport];
  const errors: string[] = [];
  const v: ResultInput = { ...input, homePens: null, awayPens: null };

  if (sp.sets) {
    const sets = (input.sets ?? []).filter((s) => s && (s[0] !== null || s[1] !== null));
    if (sets.length === 0) errors.push('Informe o placar de pelo menos um set.');
    const deciding = 2 * c.setsToWin - 1;
    let h = 0, a = 0;
    sets.forEach(([x, y], i) => {
      const n = i + 1;
      if (!int(x) || !int(y)) { errors.push(`Set ${n}: informe os dois placares.`); return; }
      if (h === c.setsToWin || a === c.setsToWin) { errors.push(`Set ${n}: a partida já tinha terminado.`); return; }
      const min = n === deciding ? c.tiebreakSetPoints : c.setPoints;
      const w = Math.max(x, y), l = Math.min(x, y);
      if (w < min || w - l < 2 || (w > min && w - l !== 2)) {
        errors.push(`Set ${n}: precisa chegar a ${min} pontos com 2 de diferença.`);
      }
      if (x > y) h++; else a++;
    });
    if (errors.length === 0 && h !== c.setsToWin && a !== c.setsToWin) {
      errors.push(`Alguém precisa vencer ${c.setsToWin} ${c.setsToWin === 1 ? 'set' : 'sets'}.`);
    }
    v.sets = sets as Array<[number, number]>;
    v.homeScore = h; v.awayScore = a;
  } else {
    v.sets = null;
    if (!int(input.homeScore) || !int(input.awayScore)) errors.push('Informe o placar das duas equipes.');
    else if (input.homeScore === input.awayScore) {
      if (isKnockout(m)) {
        if (!sp.draws) errors.push(`${sp.label} não termina empatado: informe o placar final com a prorrogação.`);
        else if (!int(input.homePens) || !int(input.awayPens)) errors.push(`Empate no mata-mata: informe o placar do desempate (${sp.tiebreakLabel.toLowerCase()}).`);
        else if (input.homePens === input.awayPens) errors.push('O desempate não pode terminar igual.');
        else { v.homePens = input.homePens; v.awayPens = input.awayPens; }
      } else if (!sp.draws) {
        errors.push(`Empates não são possíveis em ${sp.label.toLowerCase()}.`);
      }
    }
  }

  // eventos
  const byId = new Map(players.map((p) => [p.id, p]));
  const goalsBy: Record<string, number> = {};
  for (const ev of input.events) {
    if (ev.type === 'goal' && !(sp.scorers && c.stats.scorers)) { errors.push('Registro de gols está desativado neste campeonato.'); break; }
    if (ev.type === 'yellow' && !(sp.cards && c.stats.yellow)) { errors.push('Cartão amarelo está desativado neste campeonato.'); break; }
    if (ev.type === 'red' && !(sp.cards && c.stats.red)) { errors.push('Cartão vermelho está desativado neste campeonato.'); break; }
    if (ev.teamId !== m.homeId && ev.teamId !== m.awayId) { errors.push('Evento com equipe que não joga esta partida.'); break; }
    if (ev.playerId) {
      const p = byId.get(ev.playerId);
      if (!p || p.teamId !== ev.teamId) { errors.push('Jogador não pertence à equipe do evento.'); break; }
    }
    if (ev.assistPlayerId) {
      const p = byId.get(ev.assistPlayerId);
      if (!c.stats.assists || !sp.assists) { errors.push('Assistências estão desativadas neste campeonato.'); break; }
      if (!p || p.teamId !== ev.teamId || ev.assistPlayerId === ev.playerId) { errors.push('Assistência inválida: use outro jogador da mesma equipe.'); break; }
    }
    if (ev.minute != null && (!int(ev.minute) || ev.minute > 300)) { errors.push('Minuto inválido.'); break; }
    if (ev.type === 'goal') goalsBy[ev.teamId] = (goalsBy[ev.teamId] ?? 0) + 1;
  }
  if (!sp.sets && int(v.homeScore) && int(v.awayScore)) {
    if ((goalsBy[m.homeId ?? ''] ?? 0) > v.homeScore) errors.push(`Há mais gols detalhados do mandante do que o placar (${v.homeScore}).`);
    if ((goalsBy[m.awayId ?? ''] ?? 0) > v.awayScore) errors.push(`Há mais gols detalhados do visitante do que o placar (${v.awayScore}).`);
  }
  return errors.length ? { ok: false, errors } : { ok: true, value: v };
}

export function winnerOf(m: Match): 'home' | 'away' | null {
  if (m.status !== 'finished' || m.homeScore == null || m.awayScore == null) return null;
  if (m.homeScore > m.awayScore) return 'home';
  if (m.awayScore > m.homeScore) return 'away';
  if (m.homePens != null && m.awayPens != null) return m.homePens > m.awayPens ? 'home' : 'away';
  return null;
}
