import type { Championship, FormatId } from '../types';
import { SPORTS } from './sports';
import { parseDate } from './format';

export type Errors = Record<string, string>;

export const STEP_FIELDS: Record<number, string[]> = {
  1: ['name', 'customSport', 'startDate', 'endDate', 'description', 'city'],
  2: ['maxTeams', 'minTeams', 'regOpenDate', 'regCloseDate', 'minPlayers', 'maxPlayers'],
  3: ['format', 'groupCount', 'qualifiersPerGroup', 'pointsWin', 'pointsDraw', 'pointsLoss', 'teams'],
  4: ['periods', 'periodMinutes', 'setsToWin', 'setPoints', 'tiebreakSetPoints', 'yellowLimit'],
};

const isInt = (n: unknown, min: number, max: number) =>
  typeof n === 'number' && Number.isInteger(n) && n >= min && n <= max;

export function validateChampionship(c: Championship): Errors {
  const e: Errors = {};
  const sp = SPORTS[c.sport];
  if (!c.name || c.name.trim().length < 3) e.name = 'Informe um nome com pelo menos 3 letras.';
  else if (c.name.length > 80) e.name = 'Use no máximo 80 caracteres.';
  if (c.description && c.description.length > 600) e.description = 'Use no máximo 600 caracteres.';
  if (c.sport === 'outra' && !c.customSport.trim()) e.customSport = 'Diga qual é a modalidade.';
  if (!c.startDate || !parseDate(c.startDate)) e.startDate = 'Informe a data de início prevista.';
  if (c.endDate) {
    if (!parseDate(c.endDate)) e.endDate = 'Data inválida.';
    else if (c.startDate && c.endDate < c.startDate) e.endDate = 'O encerramento não pode ser antes do início.';
  }

  if (!isInt(c.maxTeams, 2, 128)) e.maxTeams = 'Use um número de 2 a 128.';
  if (!isInt(c.minTeams, 2, 128)) e.minTeams = 'Use um número de 2 a 128.';
  else if (isInt(c.maxTeams, 2, 128) && c.minTeams > c.maxTeams) e.minTeams = 'O mínimo não pode passar do máximo.';
  if (c.regOpenDate && !parseDate(c.regOpenDate)) e.regOpenDate = 'Data inválida.';
  if (c.regCloseDate) {
    if (!parseDate(c.regCloseDate)) e.regCloseDate = 'Data inválida.';
    else if (c.regOpenDate && c.regCloseDate < c.regOpenDate) e.regCloseDate = 'O encerramento não pode ser antes da abertura.';
  }
  if (c.minPlayers != null && !isInt(c.minPlayers, 1, 200)) e.minPlayers = 'Use um número de 1 a 200.';
  if (c.maxPlayers != null && !isInt(c.maxPlayers, 1, 200)) e.maxPlayers = 'Use um número de 1 a 200.';
  if (c.minPlayers != null && c.maxPlayers != null && !e.minPlayers && !e.maxPlayers && c.minPlayers > c.maxPlayers)
    e.minPlayers = 'O mínimo de jogadores não pode passar do máximo.';

  if (c.format === 'groups' || c.format === 'groups_knockout') {
    if (!isInt(c.groupCount, 2, 16)) e.groupCount = 'Use de 2 a 16 grupos.';
  }
  if (c.format === 'groups_knockout' && !isInt(c.qualifiersPerGroup, 1, 16)) e.qualifiersPerGroup = 'Use de 1 a 16 classificados.';
  if (c.format !== 'knockout' && !sp.sets) {
    if (!isInt(c.pointsWin, 0, 10)) e.pointsWin = 'Use de 0 a 10.';
    if (!isInt(c.pointsDraw, 0, 10)) e.pointsDraw = 'Use de 0 a 10.';
    if (!isInt(c.pointsLoss, 0, 10)) e.pointsLoss = 'Use de 0 a 10.';
  }

  if (sp.timed) {
    if (!isInt(c.periods, 1, 8)) e.periods = 'Use de 1 a 8 períodos.';
    if (!isInt(c.periodMinutes, 1, 120)) e.periodMinutes = 'Use de 1 a 120 minutos.';
  }
  if (sp.sets) {
    if (!isInt(c.setsToWin, 1, 3)) e.setsToWin = 'Use de 1 a 3 sets.';
    if (!isInt(c.setPoints, 5, 50)) e.setPoints = 'Use de 5 a 50 pontos.';
    if (!isInt(c.tiebreakSetPoints, 5, 50)) e.tiebreakSetPoints = 'Use de 5 a 50 pontos.';
  }
  if (c.stats.suspensions && !isInt(c.yellowLimit, 2, 10)) e.yellowLimit = 'Use de 2 a 10 amarelos.';
  return e;
}

export interface FormatSuggestion { label: string; patch: Partial<Championship> }
export interface FormatCheck { ok: boolean; problems: string[]; suggestions: FormatSuggestion[] }

export const FORMAT_LABEL: Record<FormatId, string> = {
  knockout: 'Eliminatória simples',
  groups: 'Fase de grupos',
  groups_knockout: 'Grupos + eliminatórias',
  league: 'Todos contra todos',
};

export const FORMAT_HINT: Record<FormatId, string> = {
  knockout: 'Quem perde sai. Se o número de equipes não for potência de 2, as melhores posições do sorteio avançam direto.',
  groups: 'Equipes divididas em grupos, todos contra todos dentro de cada grupo.',
  groups_knockout: 'Fase de grupos e depois mata-mata com os melhores de cada grupo.',
  league: 'Todas as equipes se enfrentam. Vence quem somar mais pontos.',
};

export function groupSizes(n: number, g: number): number[] {
  const base = Math.floor(n / g);
  const extra = n % g;
  return Array.from({ length: g }, (_, i) => base + (i < extra ? 1 : 0));
}

/** Verifica se o formato escolhido funciona com `n` equipes. Explica e sugere alternativas. */
export function checkFormat(c: Championship, n: number): FormatCheck {
  const problems: string[] = [];
  const suggestions: FormatSuggestion[] = [];
  if (n < 2) {
    problems.push('São necessárias pelo menos 2 equipes.');
    return { ok: false, problems, suggestions };
  }
  const league: FormatSuggestion = { label: 'Usar todos contra todos', patch: { format: 'league' } };

  if (c.format === 'knockout') {
    if (c.thirdPlace && n < 4) {
      problems.push(`A disputa de 3º lugar precisa de pelo menos 4 equipes (há ${n}).`);
      suggestions.push({ label: 'Desativar disputa de 3º lugar', patch: { thirdPlace: false } });
    }
  }

  if (c.format === 'groups' || c.format === 'groups_knockout') {
    const g = c.groupCount;
    const minSize = Math.floor(n / g);
    if (g < 2) {
      problems.push('Use pelo menos 2 grupos.');
    } else if (minSize < 2) {
      problems.push(`Com ${n} equipes, ${g} grupos deixam algum grupo com menos de 2 equipes.`);
      for (let k = Math.floor(n / 2); k >= 2; k--) {
        if (suggestions.length >= 2) break;
        suggestions.push({
          label: `${k} grupos (${groupSizes(n, k).join(', ')} equipes)`,
          patch: { groupCount: k, qualifiersPerGroup: Math.min(c.qualifiersPerGroup, Math.floor(n / k)) },
        });
      }
      suggestions.push(league);
    } else if (c.format === 'groups_knockout') {
      const q = c.qualifiersPerGroup;
      if (q > minSize) {
        problems.push(`O menor grupo terá ${minSize} equipes, então não dá para classificar ${q} de cada grupo.`);
        suggestions.push({ label: `Classificar ${minSize} por grupo`, patch: { qualifiersPerGroup: minSize } });
      } else if (g * q < 2) {
        problems.push('É preciso classificar pelo menos 2 equipes para as eliminatórias.');
        suggestions.push({ label: 'Classificar 2 por grupo', patch: { qualifiersPerGroup: 2 } });
      } else if (c.thirdPlace && g * q < 4) {
        problems.push(`Só ${g * q} equipes chegam às eliminatórias, e a disputa de 3º lugar precisa de 4.`);
        suggestions.push({ label: 'Desativar disputa de 3º lugar', patch: { thirdPlace: false } });
      }
    }
  }
  return { ok: problems.length === 0, problems, suggestions };
}

export interface RegistrationInput {
  name: string;
  manager: string;
  email: string;
  phone: string;
  city: string;
  players: Array<{ name: string; number: string; position: string }>;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function validateRegistration(c: Championship, r: RegistrationInput): Errors {
  const e: Errors = {};
  if (r.name.trim().length < 2) e.name = 'Informe o nome da equipe.';
  else if (r.name.length > 50) e.name = 'Use no máximo 50 caracteres.';
  if (r.manager.trim().length < 2) e.manager = 'Informe o nome do responsável.';
  const email = r.email.trim();
  const phoneDigits = r.phone.replace(/\D/g, '');
  if (email && !EMAIL_RE.test(email)) e.email = 'E-mail inválido.';
  if (r.phone.trim() && (phoneDigits.length < 10 || phoneDigits.length > 13)) e.phone = 'Telefone inválido. Use DDD e número.';
  if (c.contactRule === 'email' && !email) e.email = 'Informe um e-mail de contato.';
  if (c.contactRule === 'phone' && !r.phone.trim()) e.phone = 'Informe um telefone de contato.';
  if (c.contactRule === 'either' && !email && !r.phone.trim()) {
    e.email = 'Informe e-mail ou telefone.';
    e.phone = 'Informe e-mail ou telefone.';
  }
  if (c.requireCity && !r.city.trim()) e.city = 'Informe a cidade.';

  const filled = r.players.filter((p) => p.name.trim() || p.number.trim() || p.position.trim());
  if (c.minPlayers != null && filled.length < c.minPlayers) e.players = `Cadastre pelo menos ${c.minPlayers} jogadores (há ${filled.length}).`;
  if (c.maxPlayers != null && filled.length > c.maxPlayers) e.players = `O limite é de ${c.maxPlayers} jogadores (há ${filled.length}).`;
  const numbers = new Set<number>();
  r.players.forEach((p, i) => {
    const empty = !p.name.trim() && !p.number.trim() && !p.position.trim();
    if (empty) return;
    if (p.name.trim().length < 2) e[`player-${i}-name`] = 'Informe o nome.';
    if (p.number.trim()) {
      const n = Number(p.number);
      if (!Number.isInteger(n) || n < 0 || n > 999) e[`player-${i}-number`] = 'Número de 0 a 999.';
      else if (numbers.has(n)) e[`player-${i}-number`] = 'Número repetido.';
      else numbers.add(n);
    }
  });
  return e;
}
