import type { Championship, Match, Team } from '../types';
import { randomId, shuffle } from './codes';
import { addDays, todayISO } from './format';

export function newMatch(champId: string, patch: Partial<Match>): Match {
  return {
    id: randomId(), championshipId: champId, phase: 'league', group: null, round: 1, roundLabel: '', leg: 1,
    homeId: null, awayId: null, date: null, time: null, status: 'scheduled',
    homeScore: null, awayScore: null, homePens: null, awayPens: null, sets: null, events: [], ko: null,
    order: 0, finishedAt: null, ...patch,
  };
}

/** Método do círculo. Retorna rodadas com pares [mandante, visitante]. */
export function roundRobin(ids: string[], legs: 1 | 2): Array<Array<[string, string]>> {
  const arr: Array<string | null> = ids.slice();
  if (arr.length % 2 === 1) arr.push(null);
  const n = arr.length;
  const rounds: Array<Array<[string, string]>> = [];
  for (let r = 0; r < n - 1; r++) {
    const pairs: Array<[string, string]> = [];
    for (let i = 0; i < n / 2; i++) {
      const a = arr[i];
      const b = arr[n - 1 - i];
      if (a == null || b == null) continue;
      pairs.push((i === 0 ? r % 2 === 1 : (r + i) % 2 === 1) ? [b, a] : [a, b]);
    }
    rounds.push(pairs);
    arr.splice(1, 0, arr.pop() as string | null);
  }
  if (legs === 2) {
    const back = rounds.map((rd) => rd.map(([h, a]) => [a, h] as [string, string]));
    return rounds.concat(back);
  }
  return rounds;
}

export function groupName(i: number): string {
  return String.fromCharCode(65 + i);
}

export function seedOrder(size: number): number[] {
  let order = [1];
  while (order.length < size) {
    const n = order.length * 2;
    order = order.flatMap((s) => [s, n + 1 - s]);
  }
  return order;
}

export function koRoundLabel(matchesInRound: number): string {
  if (matchesInRound === 1) return 'Final';
  if (matchesInRound === 2) return 'Semifinal';
  if (matchesInRound === 4) return 'Quartas de final';
  if (matchesInRound === 8) return 'Oitavas de final';
  return `Fase de ${matchesInRound * 2} equipes`;
}

/**
 * Monta o chaveamento. `seeds[0]` é o cabeça 1. Se o número de equipes não for potência de 2,
 * os melhores cabeças avançam direto (folga) para a rodada seguinte.
 * `groupOf` evita confrontos entre equipes do mesmo grupo na primeira rodada, quando possível.
 */
export function buildKnockout(
  champId: string, seeds: string[], thirdPlace: boolean, startOrder = 0, groupOf?: Record<string, string | null>,
): Match[] {
  const n = seeds.length;
  if (n < 2) return [];
  let size = 2;
  while (size < n) size *= 2;
  const rounds = Math.log2(size);
  const order = seedOrder(size);
  const slotTeam: Array<string | null> = order.map((s) => seeds[s - 1] ?? null);

  if (groupOf) {
    const g = (id: string | null) => (id ? groupOf[id] ?? null : null);
    const conflict = (a: string | null, b: string | null) => !!a && !!b && g(a) != null && g(a) === g(b);
    const pairs = size / 2;
    for (let i = 0; i < pairs; i++) {
      if (!conflict(slotTeam[2 * i], slotTeam[2 * i + 1])) continue;
      for (let j = 0; j < pairs; j++) {
        if (j === i) continue;
        const a = slotTeam[2 * i], b = slotTeam[2 * i + 1], c = slotTeam[2 * j], d = slotTeam[2 * j + 1];
        if (!d || !b) continue;
        if (!conflict(a, d) && !conflict(c, b)) {
          slotTeam[2 * i + 1] = d;
          slotTeam[2 * j + 1] = b;
          break;
        }
      }
    }
  }

  const grid: Match[][] = [];
  let ord = startOrder;
  for (let r = 1; r <= rounds; r++) {
    const count = size / 2 ** r;
    const label = koRoundLabel(count);
    grid.push(Array.from({ length: count }, (_, i) => newMatch(champId, {
      phase: 'knockout', round: r, roundLabel: label, order: ord++,
      ko: { round: r, index: i, nextId: null, nextSlot: null, loserNextId: null, loserNextSlot: null },
    })));
  }
  for (let r = 0; r < rounds - 1; r++) {
    grid[r].forEach((m, i) => {
      const next = grid[r + 1][i >> 1];
      m.ko!.nextId = next.id;
      m.ko!.nextSlot = i % 2 === 0 ? 'home' : 'away';
    });
  }
  const removed = new Set<string>();
  grid[0].forEach((m, i) => {
    const a = slotTeam[2 * i], b = slotTeam[2 * i + 1];
    if (a && b) { m.homeId = a; m.awayId = b; return; }
    removed.add(m.id);
    const t = a ?? b;
    const next = grid[1]?.[i >> 1];
    if (next && t) { if (i % 2 === 0) next.homeId = t; else next.awayId = t; }
  });

  const all = grid.flat().filter((m) => !removed.has(m.id));
  if (thirdPlace && n >= 4 && rounds >= 2) {
    const semis = grid[rounds - 2];
    const third = newMatch(champId, {
      phase: 'third', round: rounds, roundLabel: 'Disputa de 3º lugar', order: ord++,
      ko: { round: rounds, index: 1, nextId: null, nextSlot: null, loserNextId: null, loserNextSlot: null },
    });
    semis.forEach((m, i) => { m.ko!.loserNextId = third.id; m.ko!.loserNextSlot = i === 0 ? 'home' : 'away'; });
    all.push(third);
  }
  return all;
}

export interface DrawResult {
  assignments: Record<string, string | null>;
  matches: Match[];
}

export function generateDraw(c: Championship, teams: Team[], shuffleFn: <T>(a: readonly T[]) => T[] = shuffle): DrawResult {
  const ids = shuffleFn(teams.map((t) => t.id));
  const assignments: Record<string, string | null> = {};
  const matches: Match[] = [];
  let ord = 0;

  if (c.format === 'knockout') {
    ids.forEach((id) => (assignments[id] = null));
    return { assignments, matches: buildKnockout(c.id, ids, c.thirdPlace, 0) };
  }

  if (c.format === 'league') {
    ids.forEach((id) => (assignments[id] = null));
    roundRobin(ids, c.legs).forEach((pairs, r) => {
      pairs.forEach(([h, a]) => matches.push(newMatch(c.id, {
        phase: 'league', round: r + 1, roundLabel: `Rodada ${r + 1}`, homeId: h, awayId: a, order: ord++,
      })));
    });
    return { assignments, matches };
  }

  const g = c.groupCount;
  const groups: string[][] = Array.from({ length: g }, () => []);
  ids.forEach((id, i) => groups[i % g].push(id));
  groups.forEach((members, gi) => members.forEach((id) => (assignments[id] = groupName(gi))));
  const perGroup = groups.map((members) => roundRobin(members, c.legs));
  const maxRounds = Math.max(...perGroup.map((r) => r.length));
  for (let r = 0; r < maxRounds; r++) {
    perGroup.forEach((rounds, gi) => {
      (rounds[r] ?? []).forEach(([h, a]) => matches.push(newMatch(c.id, {
        phase: 'group', group: groupName(gi), round: r + 1, roundLabel: `Rodada ${r + 1}`,
        homeId: h, awayId: a, order: ord++,
      })));
    });
  }
  return { assignments, matches };
}

export interface ScheduleOptions {
  startDate: string;
  startTime: string; // HH:MM
  intervalMinutes: number;
  perDay: number;
  onlyUnscheduled: boolean;
}

/** Distribui data e hora em sequência. Não mexe em partidas já encerradas. */
export function autoSchedule(matches: Match[], o: ScheduleOptions): Map<string, { date: string; time: string }> {
  const out = new Map<string, { date: string; time: string }>();
  const [hh, mm] = o.startTime.split(':').map(Number);
  const list = matches
    .filter((m) => m.status !== 'finished' && m.homeId && m.awayId && (!o.onlyUnscheduled || !m.date))
    .sort((a, b) => a.order - b.order);
  let day = 0;
  let slot = 0;
  for (const m of list) {
    if (slot >= o.perDay) { day++; slot = 0; }
    const total = hh * 60 + mm + slot * o.intervalMinutes;
    const h = Math.floor(total / 60) % 24;
    const min = total % 60;
    out.set(m.id, {
      date: addDays(o.startDate || todayISO(), day),
      time: `${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`,
    });
    slot++;
  }
  return out;
}
