import type { Championship, Match, Player, Team } from '../types';

export interface PlayerStat {
  playerId: string; teamId: string;
  goals: number; assists: number; yellow: number; red: number;
}

export function playerStats(players: Player[], matches: Match[]): Map<string, PlayerStat> {
  const out = new Map<string, PlayerStat>();
  const get = (p: Player) => {
    let s = out.get(p.id);
    if (!s) { s = { playerId: p.id, teamId: p.teamId, goals: 0, assists: 0, yellow: 0, red: 0 }; out.set(p.id, s); }
    return s;
  };
  const byId = new Map(players.map((p) => [p.id, p]));
  for (const m of matches) {
    if (m.status !== 'finished') continue;
    for (const ev of m.events) {
      const p = ev.playerId ? byId.get(ev.playerId) : null;
      if (p) {
        const s = get(p);
        if (ev.type === 'goal') s.goals++;
        if (ev.type === 'yellow') s.yellow++;
        if (ev.type === 'red') s.red++;
      }
      const a = ev.assistPlayerId ? byId.get(ev.assistPlayerId) : null;
      if (a && ev.type === 'goal') get(a).assists++;
    }
  }
  return out;
}

export function ranking(stats: Map<string, PlayerStat>, key: 'goals' | 'assists', players: Player[]): PlayerStat[] {
  const name = new Map(players.map((p) => [p.id, p.name]));
  return [...stats.values()]
    .filter((s) => s[key] > 0)
    .sort((a, b) => b[key] - a[key] || (name.get(a.playerId) ?? '').localeCompare(name.get(b.playerId) ?? '', 'pt-BR'));
}

export interface Suspension {
  playerId: string; teamId: string; reason: 'vermelho' | 'amarelos'; matchId: string;
}

/**
 * Suspensões automáticas (só se o campeonato ativar): cartão vermelho = 1 jogo;
 * amarelos acumulados em múltiplos do limite = 1 jogo. Vale para a próxima partida da equipe.
 */
export function computeSuspensions(c: Championship, teams: Team[], matches: Match[]): { suspended: Suspension[]; hanging: Array<{ playerId: string; teamId: string }> } {
  const suspended: Suspension[] = [];
  const hanging: Array<{ playerId: string; teamId: string }> = [];
  if (!c.stats.suspensions || !(c.stats.yellow || c.stats.red)) return { suspended, hanging };
  for (const t of teams) {
    const mine = matches.filter((m) => m.homeId === t.id || m.awayId === t.id).sort((a, b) => a.order - b.order);
    const yellows = new Map<string, number>();
    const pending = new Map<string, 'vermelho' | 'amarelos'>();
    for (let i = 0; i < mine.length; i++) {
      const m = mine[i];
      if (m.status !== 'finished') {
        for (const [pid, reason] of pending) suspended.push({ playerId: pid, teamId: t.id, reason, matchId: m.id });
        pending.clear();
        break;
      }
      pending.clear();
      for (const ev of m.events.filter((e) => e.teamId === t.id && e.playerId)) {
        const pid = ev.playerId as string;
        if (ev.type === 'red' && c.stats.red) pending.set(pid, 'vermelho');
        if (ev.type === 'yellow' && c.stats.yellow) {
          const n = (yellows.get(pid) ?? 0) + 1;
          yellows.set(pid, n);
          if (n % c.yellowLimit === 0 && !pending.has(pid)) pending.set(pid, 'amarelos');
        }
      }
    }
    for (const [pid, n] of yellows) if (n % c.yellowLimit === c.yellowLimit - 1) hanging.push({ playerId: pid, teamId: t.id });
  }
  return { suspended, hanging };
}

export interface TeamTotals { teamId: string; played: number; gf: number; ga: number; wins: number }

export function teamTotals(teams: Team[], matches: Match[]): TeamTotals[] {
  const map = new Map(teams.map((t) => [t.id, { teamId: t.id, played: 0, gf: 0, ga: 0, wins: 0 }]));
  for (const m of matches) {
    if (m.status !== 'finished' || !m.homeId || !m.awayId) continue;
    const h = map.get(m.homeId), a = map.get(m.awayId);
    if (!h || !a) continue;
    const hs = m.homeScore ?? 0, as = m.awayScore ?? 0;
    h.played++; a.played++; h.gf += hs; h.ga += as; a.gf += as; a.ga += hs;
    if (hs > as) h.wins++; else if (as > hs) a.wins++;
  }
  return [...map.values()];
}
