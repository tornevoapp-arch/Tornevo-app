/**
 * Códigos públicos. NA DEMONSTRAÇÃO são gerados no navegador (crypto.getRandomValues).
 * Em produção devem ser gerados no servidor e gravados com índice único.
 */
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'; // sem I, O, l, 0, 1

export function randomCode(length = 12): string {
  const out: string[] = [];
  const limit = 256 - (256 % ALPHABET.length);
  while (out.length < length) {
    const buf = new Uint8Array(length * 2);
    crypto.getRandomValues(buf);
    for (const b of buf) {
      if (b < limit && out.length < length) out.push(ALPHABET[b % ALPHABET.length]);
    }
  }
  return out.join('');
}

export function randomId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return randomCode(24);
}

/** Embaralhamento Fisher-Yates com fonte criptográfica. */
export function shuffle<T>(items: readonly T[]): T[] {
  const a = items.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const buf = new Uint32Array(1);
    const max = 0x100000000 - (0x100000000 % (i + 1));
    let r: number;
    do { crypto.getRandomValues(buf); r = buf[0]; } while (r >= max);
    const j = r % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
