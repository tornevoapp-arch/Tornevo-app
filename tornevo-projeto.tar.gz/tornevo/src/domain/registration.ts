import type { Championship } from '../types';

export type RegCode = 'ok' | 'revoked' | 'draft' | 'notyet' | 'closed' | 'full' | 'started';

export interface RegState { open: boolean; code: RegCode; reason: string | null }

export function registrationState(c: Championship, approvedCount: number, today: string): RegState {
  if (!c.regLinkActive) return { open: false, code: 'revoked', reason: 'Este link de inscrição foi desativado pelo organizador.' };
  if (c.status === 'preparacao') return { open: false, code: 'draft', reason: 'O organizador ainda não abriu as inscrições.' };
  if (c.drawDone || c.status === 'andamento' || c.status === 'encerrado') {
    return { open: false, code: 'started', reason: 'As inscrições foram encerradas porque o campeonato já começou.' };
  }
  if (c.regOpenDate && today < c.regOpenDate) return { open: false, code: 'notyet', reason: 'As inscrições ainda não abriram.' };
  if (c.regCloseDate && today > c.regCloseDate) return { open: false, code: 'closed', reason: 'O prazo de inscrição terminou.' };
  if (approvedCount >= c.maxTeams) return { open: false, code: 'full', reason: 'Todas as vagas já foram preenchidas.' };
  return { open: true, code: 'ok', reason: null };
}
