import type { Championship, SportId } from '../types';
import { SPORTS, defaultTiebreakers } from './sports';
import { todayISO, addDays } from './format';

export function sportDefaults(sport: SportId): Partial<Championship> {
  const p = SPORTS[sport];
  return {
    periods: p.defaultPeriods || 2,
    periodMinutes: p.defaultPeriodMinutes || 20,
    pointsWin: p.defaultPoints[0],
    pointsDraw: p.defaultPoints[1],
    pointsLoss: p.defaultPoints[2],
    tiebreakers: defaultTiebreakers(sport),
    setsToWin: 2, setPoints: 25, tiebreakSetPoints: 15,
    stats: { yellow: p.cards, red: p.cards, scorers: p.scorers, assists: false, suspensions: false },
  };
}

export function newChampionshipDraft(): Championship {
  const today = todayISO();
  const base: Championship = {
    id: '', isDemo: false, name: '', description: '', sport: 'futsal', customSport: '', category: 'Livre',
    city: '', venue: '', startDate: addDays(today, 14), endDate: addDays(today, 45),
    regOpenDate: today, regCloseDate: addDays(today, 10), regNotes: '',
    maxTeams: 8, minTeams: 4, minPlayers: 5, maxPlayers: 15, contactRule: 'either', requireCity: false,
    format: 'groups_knockout', groupCount: 2, qualifiersPerGroup: 2, thirdPlace: true, legs: 1,
    pointsWin: 3, pointsDraw: 1, pointsLoss: 0, tiebreakers: [],
    periods: 2, periodMinutes: 20, setsToWin: 2, setPoints: 25, tiebreakSetPoints: 15,
    stats: { yellow: true, red: true, scorers: true, assists: false, suspensions: false }, yellowLimit: 3,
    status: 'inscricoes', drawDone: false, knockoutGenerated: false,
    publicCode: '', regCode: '', regLinkActive: true, createdAt: '', updatedAt: '',
  };
  return { ...base, ...sportDefaults('futsal') } as Championship;
}
