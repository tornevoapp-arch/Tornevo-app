import type { Championship, Match, Team } from '../types';
import { computeStandings, groupLetters } from './standings';
import { buildKnockout } from './fixtures';
import { winnerOf } from './results';

/** Todas as partidas da fase de pontos corridos/grupos terminaram? */
export function groupStageComplete(matches: Match[]): boolean {
  const g = matches.filter((m) => m.phase === 'group' || m.phase === 'league');
  return g.length > 0 && g.every((m) => m.status === 'finished');
}

/** Equipes classificadas dos grupos, em ordem de cabeça de chave. */
export function qualifiersFromGroups(c: Championship, teams: Team[], matches: Match[]): Team[] {
  const letters = groupLetters(teams);
  const tables = letters.map((l) => computeStandings(c, teams, matches, l));
  const byId = new Map(teams.map((t) => [t.id, t]));
  const out: Team[] = [];
  for (let p = 0; p < c.qualifiersPerGroup; p++) {
    for (const tb of tables) {
      const row = tb[p];
      if (row) out.push(byId.get(row.teamId)!);
    }
  }
  return out;
}

export function generateKnockoutFromGroups(c: Championship, teams: Team[], matches: Match[]): Match[] {
  const q = qualifiersFromGroups(c, teams, matches);
  const groupOf: Record<string, string | null> = {};
  q.forEach((t) => (groupOf[t.id] = t.group));
  const startOrder = matches.reduce((mx, m) => Math.max(mx, m.order), -1) + 1;
  return buildKnockout(c.id, q.map((t) => t.id), c.thirdPlace, startOrder, groupOf);
}

/** O campeonato acabou? (todas as partidas encerradas e, se houver mata-mata, ele já foi gerado) */
export function isFinished(c: Championship, matches: Match[]): boolean {
  if (matches.length === 0) return false;
  if (c.format === 'groups_knockout' && !c.knockoutGenerated) return false;
  return matches.every((m) => m.status === 'finished');
}

export interface Podium { first: string | null; second: string | null; third: string | null }

export function podium(c: Championship, teams: Team[], matches: Match[]): Podium | null {
  const final = matches.find((m) => m.phase === 'knockout' && m.ko && m.ko.nextId === null);
  const third = matches.find((m) => m.phase === 'third');
  if (final) {
    const w = winnerOf(final);
    if (!w) return null;
    const first = w === 'home' ? final.homeId : final.awayId;
    const second = w === 'home' ? final.awayId : final.homeId;
    let t3: string | null = null;
    if (third) { const tw = winnerOf(third); if (tw) t3 = tw === 'home' ? third.homeId : third.awayId; }
    return { first, second, third: t3 };
  }
  if ((c.format === 'league') && matches.length && matches.every((m) => m.status === 'finished')) {
    const rows = computeStandings(c, teams, matches);
    return { first: rows[0]?.teamId ?? null, second: rows[1]?.teamId ?? null, third: rows[2]?.teamId ?? null };
  }
  return null;
}
