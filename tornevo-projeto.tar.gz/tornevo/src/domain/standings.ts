import type { Championship, Match, Team, TiebreakId } from '../types';

export interface Row {
  teamId: string;
  played: number; wins: number; draws: number; losses: number;
  gf: number; ga: number; gd: number;
  pf: number; pa: number;
  points: number;
  fairplay: number;
  position: number;
}

function emptyRow(teamId: string): Row {
  return { teamId, played: 0, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0, gd: 0, pf: 0, pa: 0, points: 0, fairplay: 0, position: 0 };
}

/** Pontos de cada lado em uma partida encerrada. */
export function pointsFor(c: Championship, m: Match): [number, number] {
  const h = m.homeScore ?? 0, a = m.awayScore ?? 0;
  if (c.sport === 'volei') {
    // 3 pontos para vitória sem tie-break, 2 com tie-break; 1 para quem perde no tie-break.
    const loserSets = Math.min(h, a);
    const tie = loserSets >= c.setsToWin - 1;
    const win = tie ? c.pointsWin - 1 : c.pointsWin;
    const lose = tie ? 1 : c.pointsLoss;
    return h > a ? [win, lose] : [lose, win];
  }
  if (h > a) return [c.pointsWin, c.pointsLoss];
  if (a > h) return [c.pointsLoss, c.pointsWin];
  return [c.pointsDraw, c.pointsDraw];
}

function applyMatch(c: Championship, rows: Map<string, Row>, m: Match) {
  const hr = rows.get(m.homeId!), ar = rows.get(m.awayId!);
  if (!hr || !ar) return;
  const h = m.homeScore ?? 0, a = m.awayScore ?? 0;
  const [hp, ap] = pointsFor(c, m);
  hr.played++; ar.played++;
  hr.gf += h; hr.ga += a; ar.gf += a; ar.ga += h;
  if (m.sets) for (const [x, y] of m.sets) { hr.pf += x; hr.pa += y; ar.pf += y; ar.pa += x; }
  hr.points += hp; ar.points += ap;
  if (h > a) { hr.wins++; ar.losses++; } else if (a > h) { ar.wins++; hr.losses++; } else { hr.draws++; ar.draws++; }
  for (const ev of m.events) {
    const r = ev.teamId === m.homeId ? hr : ar;
    if (ev.type === 'yellow') r.fairplay += 1;
    if (ev.type === 'red') r.fairplay += 3;
  }
}

function activeCriteria(c: Championship): TiebreakId[] {
  return c.tiebreakers.filter((t) => {
    if (t === 'fairplay') return c.stats.yellow || c.stats.red;
    if (t === 'saldoPontos') return c.sport === 'volei';
    return true;
  });
}

function headToHead(c: Championship, ids: Set<string>, matches: Match[]): Map<string, number> {
  const pts = new Map<string, number>([...ids].map((id) => [id, 0]));
  for (const m of matches) {
    if (m.status !== 'finished' || !m.homeId || !m.awayId) continue;
    if (!ids.has(m.homeId) || !ids.has(m.awayId)) continue;
    const [hp, ap] = pointsFor(c, m);
    pts.set(m.homeId, (pts.get(m.homeId) ?? 0) + hp);
    pts.set(m.awayId, (pts.get(m.awayId) ?? 0) + ap);
  }
  return pts;
}

function resolve(c: Championship, block: Row[], crit: TiebreakId[], matches: Match[], names: Map<string, string>): Row[] {
  if (block.length <= 1) return block;
  if (crit.length === 0) return block.slice().sort((x, y) => (names.get(x.teamId) ?? '').localeCompare(names.get(y.teamId) ?? '', 'pt-BR'));
  const [t, ...rest] = crit;
  let key: (r: Row) => number;
  if (t === 'vitorias') key = (r) => r.wins;
  else if (t === 'saldo') key = (r) => r.gd;
  else if (t === 'golspro') key = (r) => r.gf;
  else if (t === 'saldoPontos') key = (r) => r.pf - r.pa;
  else if (t === 'fairplay') key = (r) => -r.fairplay;
  else {
    const h2h = headToHead(c, new Set(block.map((r) => r.teamId)), matches);
    key = (r) => h2h.get(r.teamId) ?? 0;
  }
  const sorted = block.slice().sort((x, y) => key(y) - key(x));
  const out: Row[] = [];
  let i = 0;
  while (i < sorted.length) {
    let j = i + 1;
    while (j < sorted.length && key(sorted[j]) === key(sorted[i])) j++;
    const group = sorted.slice(i, j);
    out.push(...(group.length > 1 ? resolve(c, group, rest, matches, names) : group));
    i = j;
  }
  return out;
}

/** Classificação de um conjunto de equipes considerando apenas partidas de pontos corridos/grupo. */
export function computeStandings(c: Championship, teams: Team[], matches: Match[], group?: string | null): Row[] {
  const list = teams.filter((t) => (group === undefined ? true : t.group === group));
  const rows = new Map(list.map((t) => [t.id, emptyRow(t.id)]));
  const relevant = matches.filter((m) =>
    (m.phase === 'league' || m.phase === 'group') && m.homeId && m.awayId && rows.has(m.homeId) && rows.has(m.awayId));
  for (const m of relevant) if (m.status === 'finished') applyMatch(c, rows, m);
  const all = [...rows.values()];
  all.forEach((r) => (r.gd = r.gf - r.ga));
  const names = new Map(list.map((t) => [t.id, t.name]));
  const crit = activeCriteria(c);
  const byPoints = all.slice().sort((x, y) => y.points - x.points);
  const out: Row[] = [];
  let i = 0;
  while (i < byPoints.length) {
    let j = i + 1;
    while (j < byPoints.length && byPoints[j].points === byPoints[i].points) j++;
    const block = byPoints.slice(i, j);
    out.push(...(block.length > 1 ? resolve(c, block, crit, relevant, names) : block));
    i = j;
  }
  out.forEach((r, idx) => (r.position = idx + 1));
  return out;
}

export function groupLetters(teams: Team[]): string[] {
  return [...new Set(teams.map((t) => t.group).filter((g): g is string => !!g))].sort();
}
