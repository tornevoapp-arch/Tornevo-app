import type { Championship, SportId, TiebreakId } from '../types';

export interface SportProfile {
  id: SportId;
  label: string;
  /** Mostra períodos e minutos? */
  timed: boolean;
  defaultPeriods: number;
  defaultPeriodMinutes: number;
  /** Placar por sets (vôlei)? */
  sets: boolean;
  /** Empates são possíveis na fase de pontos corridos? */
  draws: boolean;
  scoreUnit: string; // plural: gols, pontos, sets...
  scoreUnitSingular: string;
  /** Quais estatísticas individuais fazem sentido */
  cards: boolean;
  scorers: boolean;
  assists: boolean;
  tiebreakLabel: string;
  scorerLabel: string;
  defaultPoints: [number, number, number];
}

export const SPORTS: Record<SportId, SportProfile> = {
  futebol: {
    id: 'futebol', label: 'Futebol de campo', timed: true, defaultPeriods: 2, defaultPeriodMinutes: 30,
    sets: false, draws: true, scoreUnit: 'gols', scoreUnitSingular: 'gol', cards: true, scorers: true, assists: true,
    tiebreakLabel: 'Pênaltis', scorerLabel: 'Artilharia', defaultPoints: [3, 1, 0],
  },
  futsal: {
    id: 'futsal', label: 'Futsal', timed: true, defaultPeriods: 2, defaultPeriodMinutes: 20,
    sets: false, draws: true, scoreUnit: 'gols', scoreUnitSingular: 'gol', cards: true, scorers: true, assists: true,
    tiebreakLabel: 'Pênaltis', scorerLabel: 'Artilharia', defaultPoints: [3, 1, 0],
  },
  volei: {
    id: 'volei', label: 'Vôlei', timed: false, defaultPeriods: 0, defaultPeriodMinutes: 0,
    sets: true, draws: false, scoreUnit: 'sets', scoreUnitSingular: 'set', cards: false, scorers: false, assists: false,
    tiebreakLabel: '', scorerLabel: '', defaultPoints: [3, 0, 0],
  },
  basquete: {
    id: 'basquete', label: 'Basquete', timed: true, defaultPeriods: 4, defaultPeriodMinutes: 10,
    sets: false, draws: false, scoreUnit: 'pontos', scoreUnitSingular: 'ponto', cards: false, scorers: false, assists: false,
    tiebreakLabel: '', scorerLabel: '', defaultPoints: [2, 0, 1],
  },
  esports: {
    id: 'esports', label: 'eSports', timed: false, defaultPeriods: 0, defaultPeriodMinutes: 0,
    sets: false, draws: true, scoreUnit: 'mapas', scoreUnitSingular: 'mapa', cards: false, scorers: false, assists: false,
    tiebreakLabel: 'Desempate', defaultPoints: [3, 1, 0], scorerLabel: '',
  },
  outra: {
    id: 'outra', label: 'Outra modalidade', timed: true, defaultPeriods: 2, defaultPeriodMinutes: 20,
    sets: false, draws: true, scoreUnit: 'pontos', scoreUnitSingular: 'ponto', cards: true, scorers: true, assists: true,
    tiebreakLabel: 'Desempate', scorerLabel: 'Pontuadores', defaultPoints: [3, 1, 0],
  },
};

export const SPORT_LIST = Object.values(SPORTS);

export function sportName(c: Pick<Championship, 'sport' | 'customSport'>): string {
  if (c.sport === 'outra' && c.customSport.trim()) return c.customSport.trim();
  return SPORTS[c.sport].label;
}

export function profile(c: Pick<Championship, 'sport'>): SportProfile {
  return SPORTS[c.sport];
}

export interface TiebreakInfo { id: TiebreakId; label: string; hint: string }

export function tiebreakOptions(sport: SportId): TiebreakInfo[] {
  const p = SPORTS[sport];
  const opts: TiebreakInfo[] = [
    { id: 'vitorias', label: 'Mais vitórias', hint: 'Número de vitórias na fase.' },
    { id: 'saldo', label: `Saldo de ${p.scoreUnit}`, hint: `${cap(p.scoreUnit)} marcados menos ${p.scoreUnit} sofridos.` },
    { id: 'golspro', label: `${cap(p.scoreUnit)} marcados`, hint: `Total de ${p.scoreUnit} a favor.` },
    { id: 'confronto', label: 'Confronto direto', hint: 'Pontos nos jogos entre as equipes empatadas.' },
  ];
  if (p.sets) opts.push({ id: 'saldoPontos', label: 'Saldo de pontos nos sets', hint: 'Pontos feitos menos pontos sofridos dentro dos sets.' });
  if (p.cards) opts.push({ id: 'fairplay', label: 'Fair play (menos cartões)', hint: 'Amarelo vale 1 e vermelho vale 3. Só vale se os cartões estiverem ativados.' });
  return opts;
}

export function defaultTiebreakers(sport: SportId): TiebreakId[] {
  return SPORTS[sport].sets ? ['vitorias', 'saldo', 'saldoPontos', 'confronto'] : ['vitorias', 'saldo', 'golspro', 'confronto'];
}

export function cap(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
