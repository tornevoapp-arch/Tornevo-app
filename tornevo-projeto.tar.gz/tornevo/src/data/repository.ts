import type { StoreName } from '../types';

/**
 * Contrato de armazenamento. A demonstração usa IndexedDB (ou memória).
 * Em produção, implemente esta mesma interface com Supabase/Postgres
 * (ou troque a camada de serviços por chamadas HTTP; veja ARQUITETURA.md).
 */
export interface Repository {
  readonly mode: 'indexeddb' | 'memory';
  list<T>(store: StoreName): Promise<T[]>;
  listByChampionship<T>(store: Exclude<StoreName, 'championships'>, championshipId: string): Promise<T[]>;
  get<T>(store: StoreName, id: string): Promise<T | undefined>;
  put<T extends { id: string }>(store: StoreName, value: T): Promise<void>;
  putMany<T extends { id: string }>(store: StoreName, values: T[]): Promise<void>;
  remove(store: StoreName, id: string): Promise<void>;
  removeMany(store: StoreName, ids: string[]): Promise<void>;
  clear(): Promise<void>;
  getMeta(key: string): Promise<string | undefined>;
  setMeta(key: string, value: string): Promise<void>;
}

export const STORES: StoreName[] = ['championships', 'teams', 'players', 'matches'];
