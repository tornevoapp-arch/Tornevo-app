import type { StoreName } from '../types';
import { STORES, type Repository } from './repository';

const clone = <T,>(v: T): T => (typeof structuredClone === 'function' ? structuredClone(v) : JSON.parse(JSON.stringify(v)));

export function createMemoryRepository(): Repository {
  const data = new Map<string, Map<string, any>>(STORES.map((s) => [s, new Map()]));
  const meta = new Map<string, string>();
  const st = (s: StoreName) => data.get(s)!;
  return {
    mode: 'memory',
    async list(s) { return [...st(s).values()].map(clone) as any; },
    async listByChampionship(s, id) { return [...st(s).values()].filter((x) => x.championshipId === id).map(clone) as any; },
    async get(s, id) { const v = st(s).get(id); return v ? clone(v) : undefined; },
    async put(s, v) { st(s).set(v.id, clone(v)); },
    async putMany(s, vs) { vs.forEach((v) => st(s).set(v.id, clone(v))); },
    async remove(s, id) { st(s).delete(id); },
    async removeMany(s, ids) { ids.forEach((id) => st(s).delete(id)); },
    async clear() { STORES.forEach((s) => st(s).clear()); meta.clear(); },
    async getMeta(k) { return meta.get(k); },
    async setMeta(k, v) { meta.set(k, v); },
  };
}
