import type { Api } from '../services/api';
import type { Championship, MatchEvent, Player } from '../types';
import { newChampionshipDraft, sportDefaults } from '../domain/defaults';
import { addDays, todayISO } from '../domain/format';
import { randomId } from '../domain/codes';

/** Dados de exemplo. Tudo é fictício e marcado como demonstração. */

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const FIRST = ['Lucas', 'Mateus', 'Pedro', 'Gabriel', 'Rafael', 'Bruno', 'Thiago', 'Diego', 'Felipe', 'André', 'Caio', 'Vinícius', 'Renan', 'Igor', 'Leandro', 'Murilo', 'Heitor', 'Davi', 'Otávio', 'Samuel', 'Marcos', 'Paulo', 'Joaquim', 'Enzo', 'Ricardo', 'Fábio', 'Nelson', 'Cauã'];
const LAST = ['Silva', 'Souza', 'Oliveira', 'Santos', 'Lima', 'Pereira', 'Costa', 'Ribeiro', 'Almeida', 'Carvalho', 'Gomes', 'Martins', 'Rocha', 'Barbosa', 'Moura', 'Teixeira', 'Nunes', 'Araújo', 'Mendes', 'Freitas'];
const TEAMS = ['Unidos da Esperança', 'Estrela do Norte', 'Ferroviário Vila Nova', 'Juventude do Morro', 'Atlético das Flores', 'Ribeirão Sport Clube', 'Amigos da Praça', 'Raça Azul', 'Tigres da Várzea', 'Leões do Cerrado'];
const MANAGERS = ['Carla Mendes', 'Roberto Lima', 'Patrícia Souza', 'Jorge Teixeira', 'Fernanda Rocha', 'Eduardo Nunes', 'Marta Gomes', 'Sérgio Alves'];
const POS_FUT = ['Goleiro', 'Fixo', 'Ala', 'Ala', 'Pivô'];
const POS_VOL = ['Levantador', 'Ponteiro', 'Central', 'Oposto', 'Líbero', 'Ponteiro'];

function makePlayers(rng: () => number, n: number, positions: string[]) {
  const used = new Set<string>();
  const nums = Array.from({ length: 40 }, (_, i) => i + 1).sort(() => rng() - 0.5);
  const out: Array<{ name: string; number: string; position: string }> = [];
  while (out.length < n) {
    const name = `${FIRST[Math.floor(rng() * FIRST.length)]} ${LAST[Math.floor(rng() * LAST.length)]}`;
    if (used.has(name)) continue;
    used.add(name);
    out.push({ name, number: String(nums[out.length]), position: positions[out.length % positions.length] });
  }
  return out;
}

function demoChamp(patch: Partial<Championship>): Championship {
  return { ...newChampionshipDraft(), isDemo: true, ...patch };
}

function genSets(rng: () => number, setsToWin: number, homeWins: boolean): Array<[number, number]> {
  const loserSets = rng() < 0.45 ? setsToWin - 1 : 0;
  const winnerSeq: boolean[] = Array(setsToWin).fill(true);
  const seq: boolean[] = [...winnerSeq];
  for (let i = 0; i < loserSets; i++) seq.splice(Math.floor(rng() * seq.length), 0, false);
  if (loserSets > 0) { // o último set decide: vitória do vencedor
    const last = seq.lastIndexOf(true);
    seq.splice(last, 1); seq.push(true);
  }
  const deciding = 2 * setsToWin - 1;
  return seq.map((w, i) => {
    const isDec = i + 1 === deciding;
    const target = isDec ? 15 : 25;
    const lose = isDec ? 6 + Math.floor(rng() * 8) : 14 + Math.floor(rng() * 10);
    const winnerHome = w === homeWins;
    return winnerHome ? [target, lose] : [lose, target];
  });
}

export async function seedDemo(api: Api) {
  const rng = mulberry32(20261023);
  const today = todayISO();

  // 1) Inscrições abertas: bom para testar aprovação, sorteio e geração de partidas
  const copa = await api.createChampionship(demoChamp({
    name: 'Copa Bairro Esperança (Demonstração)',
    description: 'Torneio de futsal entre equipes do bairro. Exemplo para testar inscrições, aprovação, sorteio e resultados.',
    sport: 'futsal', category: 'Livre', city: 'Campinas', venue: 'Ginásio Municipal',
    startDate: addDays(today, 10), endDate: addDays(today, 40), regOpenDate: addDays(today, -5), regCloseDate: addDays(today, 8),
    regNotes: 'Cada equipe deve levar documento com foto dos atletas no primeiro jogo.',
    minTeams: 4, maxTeams: 8, minPlayers: 5, maxPlayers: 12,
    format: 'groups_knockout', groupCount: 2, qualifiersPerGroup: 2, thirdPlace: true,
    ...sportDefaults('futsal'),
    stats: { yellow: true, red: true, scorers: true, assists: true, suspensions: true },
  }));
  const teamInput = (i: number, n: number) => ({
    name: TEAMS[i], manager: MANAGERS[i % MANAGERS.length], email: `contato${i + 1}@exemplo.com.br`, phone: '', city: 'Campinas', shield: null,
    players: makePlayers(rng, n, POS_FUT),
  });
  for (let i = 0; i < 6; i++) await api.addTeam(copa.id, teamInput(i, 7 + (i % 3)));
  for (let i = 6; i < 8; i++) await api.submitRegistration(copa.regCode, teamInput(i, 8));

  // 2) Liga de vôlei em andamento: classificação com sets
  const volei = await api.createChampionship(demoChamp({
    name: 'Liga Vila Nova de Vôlei (Demonstração)',
    description: 'Liga amadora de vôlei misto, todos contra todos em turno único.',
    sport: 'volei', category: 'Misto', city: 'Belo Horizonte', venue: 'Quadra da Escola Vila Nova',
    startDate: addDays(today, -14), endDate: addDays(today, 35), regOpenDate: addDays(today, -40), regCloseDate: addDays(today, -20),
    minTeams: 4, maxTeams: 6, minPlayers: 6, maxPlayers: 12,
    format: 'league', legs: 1, thirdPlace: false,
    ...sportDefaults('volei'),
  }));
  for (let i = 0; i < 6; i++) {
    await api.addTeam(volei.id, { name: TEAMS[3 + (i % 7)] + (i >= 7 ? ' II' : ''), manager: MANAGERS[i], email: '', phone: '(31) 98888-77' + String(10 + i), city: 'Belo Horizonte', shield: null, players: makePlayers(rng, 8, POS_VOL) });
  }
  await api.runDraw(volei.id);
  let v = (await api.getView(volei.id))!;
  const done = v.matches.filter((m) => m.round <= 2);
  for (const m of done) {
    const sets = genSets(rng, v.champ.setsToWin, rng() < 0.5);
    await api.saveResult(m.id, { homeScore: null, awayScore: null, homePens: null, awayPens: null, sets, events: [] });
  }
  v = (await api.getView(volei.id))!;
  const sched = v.matches.filter((m) => m.status === 'scheduled');
  await api.autoSchedule(volei.id, { startDate: addDays(today, 1), startTime: '19:00', intervalMinutes: 90, perDay: 3, onlyUnscheduled: true });
  void sched;

  // 3) Relâmpago: mata-mata com folgas e estatísticas individuais
  const rel = await api.createChampionship(demoChamp({
    name: 'Torneio Relâmpago de Futsal (Demonstração)',
    description: 'Mata-mata em um fim de semana. Seis equipes: as duas melhores posições do sorteio avançam direto.',
    sport: 'futsal', category: 'Sub-17', city: 'Curitiba', venue: 'Arena Central',
    startDate: addDays(today, -2), endDate: addDays(today, 5), regOpenDate: addDays(today, -30), regCloseDate: addDays(today, -5),
    minTeams: 4, maxTeams: 8, minPlayers: 5, maxPlayers: 10,
    format: 'knockout', thirdPlace: true,
    ...sportDefaults('futsal'),
    stats: { yellow: true, red: true, scorers: true, assists: true, suspensions: true },
  }));
  const posts: Player[] = [];
  void posts;
  for (let i = 0; i < 6; i++) {
    await api.addTeam(rel.id, { name: TEAMS[(i + 4) % TEAMS.length], manager: MANAGERS[(i + 2) % MANAGERS.length], email: `relampago${i + 1}@exemplo.com.br`, phone: '', city: 'Curitiba', shield: null, players: makePlayers(rng, 7, POS_FUT) });
  }
  await api.runDraw(rel.id);
  v = (await api.getView(rel.id))!;
  const first = v.matches.filter((m) => m.round === 1 && m.homeId && m.awayId);
  const scores: Array<[number, number]> = [[4, 2], [1, 3]];
  for (let k = 0; k < first.length; k++) {
    const m = first[k];
    const [hs, as] = scores[k % scores.length];
    const events: MatchEvent[] = [];
    const pick = (teamId: string) => {
      const ps = v.players.filter((p) => p.teamId === teamId);
      return ps[Math.floor(rng() * ps.length)];
    };
    const addGoal = (teamId: string, minute: number) => {
      const scorer = pick(teamId);
      let assist = pick(teamId);
      if (assist.id === scorer.id) assist = v.players.filter((p) => p.teamId === teamId && p.id !== scorer.id)[0];
      events.push({ id: randomId(), type: 'goal', teamId, playerId: scorer.id, assistPlayerId: rng() < 0.6 ? assist.id : null, minute });
    };
    for (let g = 0; g < hs; g++) addGoal(m.homeId!, 3 + g * 7);
    for (let g = 0; g < as; g++) addGoal(m.awayId!, 6 + g * 8);
    events.push({ id: randomId(), type: 'yellow', teamId: m.homeId!, playerId: pick(m.homeId!).id, assistPlayerId: null, minute: 18 });
    if (k === 0) events.push({ id: randomId(), type: 'red', teamId: m.awayId!, playerId: pick(m.awayId!).id, assistPlayerId: null, minute: 31 });
    await api.saveResult(m.id, { homeScore: hs, awayScore: as, homePens: null, awayPens: null, sets: null, events });
  }
  await api.autoSchedule(rel.id, { startDate: addDays(today, 0), startTime: '14:00', intervalMinutes: 60, perDay: 4, onlyUnscheduled: true });
}

export async function ensureSeeded(api: Api) {
  if ((await api.repo.getMeta('seeded')) === '1') return;
  const existing = await api.listSummaries();
  if (existing.length === 0) await seedDemo(api);
  await api.repo.setMeta('seeded', '1');
}

export async function resetDemo(api: Api) {
  await api.wipe();
  await seedDemo(api);
  await api.repo.setMeta('seeded', '1');
  api.notify();
}
