import type { StoreName } from '../types';
import { STORES, type Repository } from './repository';
import { createMemoryRepository } from './memory';

const DB_NAME = 'tornevo-demo';
const DB_VERSION = 1;

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') return reject(new Error('IndexedDB indisponível'));
    let req: IDBOpenDBRequest;
    try { req = indexedDB.open(DB_NAME, DB_VERSION); } catch (e) { return reject(e); }
    const timer = setTimeout(() => reject(new Error('IndexedDB demorou a abrir')), 4000);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const s of STORES) {
        if (!db.objectStoreNames.contains(s)) {
          const os = db.createObjectStore(s, { keyPath: 'id' });
          if (s !== 'championships') os.createIndex('championshipId', 'championshipId');
        }
      }
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
    };
    req.onsuccess = () => { clearTimeout(timer); resolve(req.result); };
    req.onerror = () => { clearTimeout(timer); reject(req.error ?? new Error('Falha ao abrir IndexedDB')); };
    req.onblocked = () => { clearTimeout(timer); reject(new Error('IndexedDB bloqueado')); };
  });
}

const wrap = <T,>(r: IDBRequest<T>) => new Promise<T>((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const done = (tx: IDBTransaction) => new Promise<void>((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error); });

function build(db: IDBDatabase): Repository {
  return {
    mode: 'indexeddb',
    async list(s) { return wrap(db.transaction(s).objectStore(s).getAll()) as any; },
    async listByChampionship(s, id) { return wrap(db.transaction(s).objectStore(s).index('championshipId').getAll(id)) as any; },
    async get(s, id) { return wrap(db.transaction(s).objectStore(s).get(id)) as any; },
    async put(s, v) { const tx = db.transaction(s, 'readwrite'); tx.objectStore(s).put(v); await done(tx); },
    async putMany(s, vs) { const tx = db.transaction(s, 'readwrite'); vs.forEach((v) => tx.objectStore(s).put(v)); await done(tx); },
    async remove(s, id) { const tx = db.transaction(s, 'readwrite'); tx.objectStore(s).delete(id); await done(tx); },
    async removeMany(s, ids) { const tx = db.transaction(s, 'readwrite'); ids.forEach((id) => tx.objectStore(s).delete(id)); await done(tx); },
    async clear() {
      const names = [...STORES, 'meta'];
      const tx = db.transaction(names, 'readwrite');
      names.forEach((n) => tx.objectStore(n).clear());
      await done(tx);
    },
    async getMeta(k) { const r = await wrap(db.transaction('meta').objectStore('meta').get(k)); return r?.value; },
    async setMeta(k, value) { const tx = db.transaction('meta', 'readwrite'); tx.objectStore('meta').put({ key: k, value }); await done(tx); },
  };
}

/** Abre o IndexedDB; se o ambiente não permitir, usa memória (dados valem só até fechar a página). */
export async function openRepository(): Promise<Repository> {
  try {
    const repo = build(await openDb());
    await repo.setMeta('probe', String(Date.now()));
    return repo;
  } catch {
    return createMemoryRepository();
  }
}
